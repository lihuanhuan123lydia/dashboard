#!/usr/bin/env bash
# ============================================================
# 启动 dmdmnow 全部服务（手动方式，也用于调试）
# 用法: bash start_services.sh
# ============================================================
set -e
WORKSPACE="$HOME/.openclaw/workspace"
LOGDIR="$HOME/logs"
mkdir -p "$LOGDIR"

echo "=== 启动 dmdmnow 服务 ==="

# 8901 主面板（competitor-data）
pkill -f "http.server 8901" 2>/dev/null || true
nohup python3 -m http.server 8901 -d "$WORKSPACE/competitor-data/" > "$LOGDIR/8901.log" 2>&1 &
echo "  ✔ 8901 主面板 (competitor-data)"

# 8080 wolfbox
pkill -f "http.server 8080" 2>/dev/null || true
nohup python3 -m http.server 8080 -d "$WORKSPACE/wolfbox-dashboard/" > "$LOGDIR/8080.log" 2>&1 &
echo "  ✔ 8080 wolfbox"

# 7891 webhook
pkill -f "webhook_server.py" 2>/dev/null || true
nohup python3 "$WORKSPACE/competitor-data/webhook_server.py" > "$LOGDIR/7891.log" 2>&1 &
echo "  ✔ 7891 webhook"

# cloudflared 隧道
pkill -f "cloudflared tunnel" 2>/dev/null || true
sleep 1
nohup cloudflared tunnel --config "$HOME/.cloudflared/config.yml" run > "$LOGDIR/cloudflared.log" 2>&1 &
echo "  ✔ cloudflared 隧道"

sleep 2
echo ""
echo "=== 验证端口 ==="
ss -tlnp 2>/dev/null | grep -E ":8901|:8080|:7891|:20241" || echo "  (等待启动...)"
echo ""
echo "=== 验证隧道域名 ==="
curl -s -o /dev/null -w "dashboard: %{http_code}\n" https://dashboard.dmdmnow.com
curl -s -o /dev/null -w "webhook:   %{http_code}\n" https://webhook.dmdmnow.com
curl -s -o /dev/null -w "wolfbox:   %{http_code}\n" https://wolfbox.dmdmnow.com
