#!/usr/bin/env bash
# ============================================================
# dmdmnow 面板 一键迁移部署脚本
# 在【新机器】上运行：  bash setup.sh
# 作用：安装依赖 → 部署文件 → 重建软链 → 恢复 cron → 注册服务自动重启
# ============================================================
set -e

WORKSPACE="$HOME/.openclaw/workspace"
MIG_TOP="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo "════════════════════════════════════════════════"
echo "  dmdmnow 面板迁移部署"
echo "════════════════════════════════════════════════"

# ---------- 0. 确认 root/sudo ----------
if [ "$(id -u)" != "0" ]; then
  echo "[!] 建议用 sudo 运行（安装系统包需要 root）"
fi
SUDO=""
if [ "$(id -u)" != "0" ]; then SUDO="sudo"; fi

# ---------- 1. 安装依赖 ----------
echo ""
echo "[1/6] 安装依赖 (python3, pip, cloudflared)..."
$SUDO apt-get update -y >/dev/null 2>&1 || true
$SUDO apt-get install -y python3 python3-pip curl >/dev/null 2>&1 || true

# cloudflared
if ! command -v cloudflared >/dev/null 2>&1; then
  echo "  安装 cloudflared..."
  curl -sL https://pkg.cloudflare.com/cloudflare-main.gpg | $SUDO tee /usr/share/keyrings/cloudflare-main.gpg >/dev/null
  echo "deb [signed-by=/usr/share/keyrings/cloudflare-main.gpg] https://pkg.cloudflare.com/cloudflared $(lsb_release -cs) main" | $SUDO tee /etc/apt/sources.list.d/cloudflared.list >/dev/null
  $SUDO apt-get update -y >/dev/null 2>&1 || true
  $SUDO apt-get install -y cloudflared >/dev/null 2>&1 || true
fi
echo "  ✔ cloudflared: $(cloudflared --version 2>/dev/null | head -1)"

# python 依赖
$SUDO pip3 install flask requests >/dev/null 2>&1 || true
echo "  ✔ python 依赖"

# ---------- 2. 部署代码数据 ----------
echo ""
echo "[2/6] 部署代码与数据到 $WORKSPACE ..."
mkdir -p "$WORKSPACE"
cp -a "$MIG_TOP/1-代码数据"/competitor-data "$WORKSPACE/"
cp -a "$MIG_TOP/1-代码数据"/wolfbox-dashboard "$WORKSPACE/" 2>/dev/null || true
cp -a "$MIG_TOP/1-代码数据"/3w-dashboard "$WORKSPACE/" 2>/dev/null || true
cp -a "$MIG_TOP/1-代码数据"/3w-eu-dashboard "$WORKSPACE/" 2>/dev/null || true

# ---------- 3. 重建软链（因为路径在新机器变了） ----------
echo ""
echo "[3/6] 重建软链..."
cd "$WORKSPACE/competitor-data"
rm -f 3w 3w-eu
ln -sfn "$WORKSPACE/3w-dashboard" 3w
ln -sfn "$WORKSPACE/3w-eu-dashboard" 3w-eu
echo "  ✔ 3w -> $WORKSPACE/3w-dashboard"
echo "  ✔ 3w-eu -> $WORKSPACE/3w-eu-dashboard"

# ---------- 4. 部署 cloudflared 隧道的凭证 ----------
echo ""
echo "[4/6] 部署 cloudflared 隧道凭证..."
mkdir -p "$HOME/.cloudflared"
cp -a "$MIG_TOP/2-配置/cloudflared"/config.yml "$HOME/.cloudflared/"
cp -a "$MIG_TOP/2-配置/cloudflared"/dmdmnow-tunnel.json "$HOME/.cloudflared/"
chmod 600 "$HOME/.cloudflared/dmdmnow-tunnel.json"
echo "  ✔ 隧道凭证已部署 (tunnel ID: $(grep -E 'tunnel:' $HOME/.cloudflared/config.yml | awk '{print $2}'))"

# ---------- 5. 恢复 crontab ----------
echo ""
echo "[5/6] 恢复 crontab 定时任务..."
# 用新路径替换旧路径
if [ -f "$MIG_TOP/4-crontab.txt" ]; then
  sed "s|/home/ecs-user/.openclaw/workspace|$WORKSPACE|g" "$MIG_TOP/4-crontab.txt" > /tmp/dmdmnow_cron_new.txt
  crontab /tmp/dmdmnow_cron_new.txt
  echo "  ✔ crontab 已恢复 ($(wc -l < /tmp/dmdmnow_cron_new.txt) 行)"
fi

# ---------- 6. 注册 systemd 服务（自动重启，根治 Error 1033） ----------
echo ""
echo "[6/6] 注册 systemd 服务（自动重启）..."
DEPLOY="$WORKSPACE/3-脚本"

# cloudflared
if [ -f "$DEPLOY/cloudflared.service" ]; then
  $SUDO cp "$DEPLOY/cloudflared.service" /etc/systemd/system/
  $SUDO systemctl daemon-reload
  $SUDO systemctl enable cloudflared >/dev/null 2>&1 || true
  echo "  ✔ cloudflared 已注册为 systemd 服务"
fi

# 面板服务 (8901/8080/7891)
if [ -f "$DEPLOY/dmdmnow-services.service" ]; then
  $SUDO cp "$DEPLOY/dmdmnow-services.service" /etc/systemd/system/
  $SUDO systemctl daemon-reload
  $SUDO systemctl enable dmdmnow-services >/dev/null 2>&1 || true
  echo "  ✔ 面板服务已注册"
fi

echo ""
echo "════════════════════════════════════════════════"
echo "  部署完成！下一步："
echo "  1. bash start_services.sh   # 启动全部服务"
echo "  2. curl https://dashboard.dmdmnow.com  # 验证"
echo "════════════════════════════════════════════════"
