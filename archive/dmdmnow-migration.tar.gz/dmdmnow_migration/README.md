# dmdmnow 面板 —— 一键迁移包

把本包发给新机器，在新机器上运行 `3-脚本/setup.sh` 即可一次性恢复全部功能。

## 包含内容

```
dmdmnow-migration/
├── 1-代码数据/
│   ├── competitor-data/    主面板 + 全部抓取/同步/webhook 脚本
│   ├── wolfbox-dashboard/  wolfbox.dmdmnow.com 站点
│   ├── 3w-dashboard/       3W 面板（competitor-data 软链指向）
│   └── 3w-eu-dashboard/    3W EU 面板
├── 2-配置/
│   └── cloudflared/
│       ├── config.yml              tunnel 路由
│       └── dmdmnow-tunnel.json     🔴 tunnel 凭证（关键！接管域名用）
├── 3-脚本/
│   ├── setup.sh                    一键部署（安装依赖+软链+cron+systemd）
│   ├── start_services.sh           启动 8901/8080/7891 + cloudflared
│   └── *.service                   systemd 服务文件（自动重启）
├── 4-crontab.txt                   定时任务
├── 5-密钥说明.md                   各密钥用途
└── 6-迁移指南.md                   详细架构说明
```

## 新机器部署步骤（3 步）

```bash
# 1. 解压
tar -xzf dmdmnow-migration.tar.gz
cd dmdmnow-migration

# 2. 一键部署（建议 sudo 运行）
sudo bash 3-脚本/setup.sh

# 3. 启动并验证
bash 3-脚本/start_services.sh
curl https://dashboard.dmdmnow.com   # 应返回 200
```

## ⚠️ 关键注意事项

1. **cloudflared 已配置为 systemd 服务 + Restart=always**——这是根治「Error 1033 掉线」的关键，新机器重启后隧道会自动拉起。
2. **tunnel 凭证 `dmdmnow-tunnel.json` 千万不能丢**——没有它新机器无法接管域名。
3. 迁移时 Cloudflare DNS 无需改动：新机器 cloudflared 连上同一 tunnel ID 后，域名自动指向新机器。
4. 面板数据文件（analysis_data.json 等）已含当前最新数据，直接沿用。
5. 若新机器用户名不是 `ecs-user`，请修改 setup.sh / systemd 文件（把 `ecs-user` 换成你的用户名）。
