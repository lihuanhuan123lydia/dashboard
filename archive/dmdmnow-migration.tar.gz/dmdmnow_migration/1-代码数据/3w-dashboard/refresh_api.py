#!/usr/bin/env python3
"""Simple HTTP endpoint to trigger dashboard refresh"""
import http.server
import json
import subprocess
import os

class RefreshHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/refresh':
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
            # Run sync
            try:
                result = subprocess.run(
                    ['bash', '/home/ecs-user/.openclaw/workspace/3w-dashboard/sync_3w.sh'],
                    capture_output=True, text=True, timeout=120
                )
                response = {
                    "status": "ok" if result.returncode == 0 else "error",
                    "output": result.stdout[-500:],
                    "error": result.stderr[-500:] if result.stderr else ""
                }
            except Exception as e:
                response = {"status": "error", "error": str(e)}
            
            self.wfile.write(json.dumps(response, ensure_ascii=False).encode())
        else:
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b'{"status":"not_found"}')
    
    def log_message(self, format, *args):
        pass  # Suppress logs

if __name__ == '__main__':
    port = 8920
    server = http.server.HTTPServer(('127.0.0.1', port), RefreshHandler)
    print(f"Refresh API on port {port}")
    server.serve_forever()
