#!/bin/bash
# 3W 脚垫车型需求 数据同步脚本
# 跳过表格标准化（保留用户手动修改的开发状态）
# 直接读取当前表格 → 合并开发进度 → 更新面板

BASE="/home/ecs-user/.openclaw/workspace"
LOG="$BASE/3w-dashboard/sync.log"
echo "===== $(date) =====" >> "$LOG"

cd "$BASE/3w-dashboard"
python3 << 'PYEOF'
import json, requests, re, math
from collections import Counter, defaultdict
from time import sleep
from datetime import datetime, timedelta

APP_ID = "cli_a95e614746395cbd"
APP_SECRET = "ZTPbyJlJNK0utcjkqgTazh8JDnLFhK4X"
SP = "NV6Gsl1lwhBw7RtYPTAcpQQenjq"
BITABLE_TOKEN = "Oip3bNqqHaQeves6xIAc2iHXnnW"
TABLE_ID = "tbl3bbHPe7EeIV1D"

def get_token():
    r = requests.post("https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
        json={"app_id": APP_ID, "app_secret": APP_SECRET}, timeout=10)
    return r.json()["tenant_access_token"]

def txt(v):
    if v is None: return ""
    if isinstance(v, list):
        for x in v:
            if isinstance(x, dict) and "text" in x: return x.get("text","")
        return ""
    return str(v).strip()

# === Read main sheet directly (preserves user's manual edits) ===
token = get_token()
r = requests.get(f"https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SP}/values/0iCDMN!A:E",
    headers={"Authorization": f"Bearer {token}"}, timeout=30)
rows = r.json()["data"]["valueRange"]["values"]
print(f"Read {len(rows)} rows from main sheet")

models = []
for row in rows[1:]:
    if len(row) < 3: continue
    make = str(row[0]).strip() if row[0] else ""
    model = str(row[1]).strip() if row[1] else ""
    if not make or not model: continue
    # Clean naming issues
    model = re.sub(r'\b1500\s+1500\b', '1500', model)
    model = re.sub(r'\b1500\s+1500\b', '1500', model)
    try: count = int(float(str(row[2])))
    except: count = 0
    if count < 1: continue
    dev = str(row[3]).strip() if len(row) > 3 and row[3] else ""
    notes = str(row[4]).strip() if len(row) > 4 and row[4] else ""
    models.append({"make": make, "model": model, "people_count": count, "dev_status": dev, "notes": notes})

models.sort(key=lambda x: -x["people_count"])
for i, m in enumerate(models): m["rank"] = i + 1

# === Read development progress from bitable (only updates notes, not dev_status) ===
token = get_token()
dev_records = []
page_token = ""
while True:
    url = f"https://open.feishu.cn/open-apis/bitable/v1/apps/{BITABLE_TOKEN}/tables/{TABLE_ID}/records?page_size=100"
    if page_token: url += f"&page_token={page_token}"
    resp = requests.get(url, headers={"Authorization": f"Bearer {token}"}, timeout=15)
    data = resp.json()
    dev_records.extend(data["data"]["items"])
    if not data["data"].get("has_more"): break
    page_token = data["data"]["page_token"]

dev_data = []
for item in dev_records:
    f = item["fields"]
    brand = txt(f.get("品牌","")).strip()
    model = txt(f.get("车型","")).strip()
    year = txt(f.get("年份","")).strip()
    status = txt(f.get("整体状态","")).strip()
    node = txt(f.get("当前节点","")).strip()
    priority = txt(f.get("优先级","")).strip()
    notes = txt(f.get("产品特殊备注","")).strip()
    mold = txt(f.get("模具号","")).strip()
    make_map = {"FORD":"Ford","CHEVROLET":"Chevrolet","TOYOTA":"Toyota","GMC":"GMC",
        "HONDA":"Honda","DODGE":"Dodge","NISSAN":"Nissan","KIA":"Kia","HYUNDAI":"Hyundai",
        "JEEP":"Jeep","SUBARU":"Subaru","VW":"Volkswagen","MAZDA":"Mazda","BUICK":"Buick",
        "BMW":"BMW","MERCEDES":"Mercedes-Benz","AUDI":"Audi","LEXUS":"Lexus",
        "CADILLAC":"Cadillac","LINCOLN":"Lincoln","RAM":"Ram","CHRYSLER":"Chrysler",
        "ACURA":"Acura","INFINITI":"Infiniti","VOLVO":"Volvo","TESLA":"Tesla",
        "CHERY":"Chery","BYD":"BYD","PEUGEOT":"Peugeot","SKODA":"Skoda",
        "MINI":"Mini","LAND ROVER":"Land Rover"}
    make = make_map.get(brand.upper(), brand.title() if brand else "")
    model = model.strip().title()
    dev_data.append({"make":make,"model":model,"year":year,"status":status,"node":node,
                     "priority":priority,"notes":notes,"mold":mold})

# Update notes with dev progress (preserves user's dev_status edits)
for m in models:
    # 已上线/在售车型不再拼开发进度备注（2026-08-10 李缓要求）
    if ('上线' in m["dev_status"]) or ('在售' in m["dev_status"]):
        continue
    for dev in dev_data:
        if dev["make"].lower() != m["make"].lower(): continue
        dm = dev["model"].lower()
        rm = m["model"].lower()
        if dm == rm: pass
        else:
            # Word boundary: "expedition" should NOT match "expedition max"
            pat = r'\b' + re.escape(dm) + r'\b'
            if not re.search(pat, rm): continue
            remainder = re.sub(pat, '', rm).strip()
            variant_kw = ['max','el','xl','sport','limited','platinum','hybrid','ev',
                'sel','se','le','xle','xse','lx','ex','touring','awd','4wd','4x4',
                'crew cab','quad cab','crewmax','slt','sle','ls','lt','ltz','gt','rt',
                'st','xt','sr5','trd','xlt','lariat','king ranch','tremor','raptor',
                'denali','at4','elevation','z71','zr2','rst','premium','trail boss']
            if remainder and remainder.split()[0].lower() in variant_kw:
                continue  # Don't match base model to variant
        parts = []
        if dev["status"]: parts.append(dev["status"])
        if dev["node"]: parts.append(f"节点:{dev['node']}")
        if dev["priority"]: parts.append(dev["priority"])
        if dev["year"]: parts.append(f"年份:{dev['year']}")
        if dev["notes"]: parts.append(dev["notes"])
        if dev["mold"]: parts.append(f"模具:{dev['mold']}")
        new_notes = " | ".join(parts)
        if m["notes"] and m["notes"] != new_notes:
            if m["notes"] not in new_notes and new_notes not in m["notes"]:
                new_notes = f"{m['notes']} | {new_notes}"
        m["notes"] = new_notes
        break

# === Build 2027 data ===
r2 = requests.get(f"https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SP}/values/1sCyzd!A:D",
    headers={"Authorization": f"Bearer {token}"}, timeout=60)
sub_rows = r2.json()["data"]["valueRange"]["values"]

def norm_model(m):
    m = m.strip().upper()
    m = re.sub(r'^2027\s+', '', m)
    m = re.sub(r'\bTELLURIDE\b', 'Telluride', m)
    m = re.sub(r'\b(SX|SX PRESTIGE XPRO|X-LINE|HEV|HYBRID|SPORT)\b', '', m)
    m = re.sub(r'\s*-\s*', ' ', m)
    m = re.sub(r'\s+', ' ', m).strip()
    if 'Telluride' in m and m != 'Telluride': m = 'Telluride'
    m = m.title()
    return m.replace("Ev", "EV").replace("Bolt ", "Bolt ")

MAKE_ALIASES = {'FORD':'Ford','CHEVROLET':'Chevrolet','TOYOTA':'Toyota','GMC':'GMC',
    'HONDA':'Honda','DODGE':'Dodge','NISSAN':'Nissan','KIA':'Kia','HYUNDAI':'Hyundai',
    'JEEP':'Jeep','SUBARU':'Subaru','VW':'Volkswagen','MAZDA':'Mazda','BUICK':'Buick',
    'BMW':'BMW','MERCEDES':'Mercedes-Benz','MERCEDES-BENZ':'Mercedes-Benz','AUDI':'Audi',
    'LEXUS':'Lexus','CADILLAC':'Cadillac','LINCOLN':'Lincoln','RAM':'Ram','CHRYSLER':'Chrysler',
    'ACURA':'Acura','INFINITI':'Infiniti','VOLVO':'Volvo','TESLA':'Tesla','CHERY':'Chery',
    'BYD':'BYD','PEUGEOT':'Peugeot','SKODA':'Skoda','MINI':'Mini','LAND ROVER':'Land Rover',
    'JAGUAR':'Jaguar','GENESIS':'Genesis','MASERATI':'Maserati','PORSCHE':'Porsche',
    'MITSUBISHI':'Mitsubishi','SCION':'Scion','FIAT':'Fiat','SUZUKI':'Suzuki',
    'ISUZU':'Isuzu','PONTIAC':'Pontiac','SATURN':'Saturn','OLDSMOBILE':'Oldsmobile',
    'MERCURY':'Mercury'}

y27 = {}
for row in sub_rows[1:]:
    if len(row) < 4: continue
    mk = str(row[0]).strip() if row[0] else ''
    md = str(row[1]).strip() if row[1] else ''
    yr = str(row[3]).strip() if row[3] else ''
    tr = str(row[2]).strip() if len(row) > 2 and row[2] else ''
    if not mk or not md or not yr: continue
    try:
        if int(float(yr)) != 2027: continue
    except: continue
    make = MAKE_ALIASES.get(mk.strip().upper(), mk.strip().title())
    model = norm_model(md)
    key = f'{make}|{model}'
    if key not in y27:
        y27[key] = {'make': make, 'model': model, 'count': 0, 'trims': set()}
    y27[key]['count'] += 1
    if tr: y27[key]['trims'].add(tr)

y27_data = sorted(y27.values(), key=lambda x: -x['count'])
for item in y27_data:
    item['trims'] = list(dict.fromkeys(item['trims']))

# === Define result dict ===
result = {
    "updated_at": datetime.now().strftime("%Y/%m/%d"),
    "total_models": len(models),
    "total_people": sum(m["people_count"] for m in models),
    "total_makes": len(set(m["make"] for m in models)),
    "models": models[:500],
    "year_2027": {
        "total": sum(item['count'] for item in y27_data),
        "models": len(y27_data),
        "makes": len(set(item['make'] for item in y27_data)),
        "data": y27_data
    }
}

# === Trending models detection (hot demand surge) ===

# Read raw submissions with timestamps for trending analysis
r3 = requests.get(f"https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SP}/values/1sCyzd!A1:I25010",
    headers={"Authorization": f"Bearer {token}"}, timeout=120)
sub_rows_full = r3.json()["data"]["valueRange"]["values"]
print(f"Read {len(sub_rows_full)} rows for trending analysis")

def excel_to_date(val):
    try:
        return datetime(1899, 12, 30) + timedelta(days=int(float(val)))
    except:
        return None

def norm_trending_model(m):
    """Normalize raw model name for trending grouping"""
    m = m.strip().upper()
    m = re.sub(r'^(20\d{2})\s+', '', m)
    m = re.sub(r'^(20\d{2}[-–]\d{2,4})\s+', '', m)
    m = re.sub(r'\b(SR5|TRD PRO|TRD OFF-ROAD|TRD|XLE|XSE|LE|SE|LTZ|LT|LS|RS|RT|ST|XT|GT|SLT|SLE|SX)\b', '', m)
    m = re.sub(r'\b(PLATINUM|LIMITED|LARIAT|KING RANCH|TREMOR|RAPTOR|XL|XLT|SPORT|DENALI|AT4|ELEVATION|Z71|ZR2|RST|PREMIUM|TRAIL BOSS)\b', '', m)
    m = re.sub(r'\b(CREW CAB|QUAD CAB|EXT CAB|REGULAR CAB|CREWMAX|DOUBLE CAB|ACCESS CAB|CAB)\b', '', m)
    m = re.sub(r'\b(4WD|4X4|AWD|EV|HEV|HYBRID|SEL|LX|EX|XPRO|XLINE|X LINE)\b', '', m)
    m = re.sub(r'\bF\s*-?\s*150\b', 'F-150', m)
    m = re.sub(r'\bF\s*-?\s*250\b', 'F-250', m)
    m = re.sub(r'\bF\s*-?\s*350\b', 'F-350', m)
    m = re.sub(r'\bSIERRA\s*1500\b', 'Sierra 1500', m)
    m = re.sub(r'\bSIERRA\s*2500\b', 'Sierra 2500', m)
    m = re.sub(r'\bSILVERADO\s*1500\b', 'Silverado 1500', m)
    m = re.sub(r'\bSILVERADO\s*2500\b', 'Silverado 2500', m)
    m = re.sub(r'\bRAM\s*1500\b', 'Ram 1500', m)
    m = re.sub(r'\bRAM\s*2500\b', 'Ram 2500', m)
    m = re.sub(r'\bRAM\s*3500\b', 'Ram 3500', m)
    m = re.sub(r'\bRAV4?\b', 'RAV4', m)
    m = re.sub(r'\bRAV\s+4\b', 'RAV4', m)
    m = re.sub(r'\bCX[\s-]*(\d+)\b', r'CX-\1', m)
    m = re.sub(r'\s+', ' ', m).strip()
    m = re.sub(r'\s*-\s*', '-', m)
    m = m.title()
    m = re.sub(r'\bF-150\b', 'F-150', m)
    m = re.sub(r'\bF-250\b', 'F-250', m)
    m = re.sub(r'\bF-350\b', 'F-350', m)
    m = re.sub(r'\bRav4\b', 'RAV4', m)
    m = re.sub(r'\bCx-(\d+)\b', r'CX-\1', m)
    m = re.sub(r'\bEv\b', 'EV', m)
    m = re.sub(r'\bHrv\b', 'HRV', m)
    m = re.sub(r'\bCrv\b', 'CRV', m)
    m = re.sub(r'\bSuv\b', 'SUV', m)
    m = re.sub(r'\bHd\b', 'HD', m)
    m = re.sub(r'\bXl\b', 'XL', m)
    return m

# Brand extraction: handle non-standard Make column entries
# e.g. "Chrysler Pacifica Limited" -> extract brand "CHRYSLER"
BRAND_KEYS = sorted([
    'FORD','CHEVROLET','TOYOTA','GMC','HONDA','DODGE','NISSAN','KIA','HYUNDAI',
    'JEEP','SUBARU','VOLKSWAGEN','VW','MAZDA','BUICK','BMW','MERCEDES-BENZ','MERCEDES',
    'AUDI','LEXUS','CADILLAC','LINCOLN','RAM','CHRYSLER','ACURA','INFINITI','VOLVO',
    'TESLA','CHERY','BYD','PEUGEOT','SKODA','MINI','LAND ROVER','JAGUAR','GENESIS',
    'MASERATI','PORSCHE','MITSUBISHI','SCION','FIAT','SUZUKI','ISUZU','PONTIAC',
    'SATURN','OLDSMOBILE','MERCURY','DATSUN','OPEL','SAAB','HUMMER','GEO','DAEWOO','ROVER'
], key=len, reverse=True)

def extract_make(raw):
    r = raw.strip().upper()
    for brand in BRAND_KEYS:
        if r.startswith(brand):
            return brand
    return r

# Collect submissions with dates
raw_subs = []
trending_details = defaultdict(lambda: {'years': defaultdict(int), 'trims': defaultdict(int)})

for row in sub_rows_full[1:]:
    if len(row) < 9: continue
    mk_raw = str(row[0]).strip() if row[0] else ''
    md = str(row[1]).strip() if row[1] else ''
    st = row[8]
    if not mk_raw or not md or not st: continue
    dt = excel_to_date(st)
    if not dt: continue
    # Extract clean brand from potentially messy Make column
    brand_key = extract_make(mk_raw)
    make = MAKE_ALIASES.get(brand_key, brand_key.title())
    model = norm_trending_model(md)
    if not model: continue
    raw_subs.append({'make': make, 'model': model, 'date': dt})
    # Collect year and trim for detail view
    yr = str(row[3]).strip() if len(row) > 3 and row[3] else ''
    trim = str(row[2]).strip() if len(row) > 2 and row[2] else ''
    key = f'{make}|{model}'
    if yr: trending_details[key]['years'][yr] += 1
    if trim: trending_details[key]['trims'][trim] += 1

if raw_subs:
    max_dt = max(s['date'] for s in raw_subs)
    cutoff_14d = max_dt - timedelta(days=14)
    cutoff_7d = max_dt - timedelta(days=7)
    
    trend_groups = defaultdict(list)
    for s in raw_subs:
        key = f'{s["make"]}|{s["model"]}'
        trend_groups[key].append(s['date'])
    
    HISTORY_START = datetime(2024, 1, 1)
    trending = []
    
    for key, dates in trend_groups.items():
        make, model = key.split('|', 1)
        recent_14d = sum(1 for d in dates if cutoff_14d <= d <= max_dt)
        prev_7d = sum(1 for d in dates if cutoff_14d <= d < cutoff_7d)
        hist_dates = [d for d in dates if d < cutoff_14d]
        total_hist = len(hist_dates)
        hist_days = max(1, (cutoff_14d - HISTORY_START).days)
        hist_avg = total_hist / hist_days
        if recent_14d < 3 or hist_avg < 0.001:
            continue
        spike_ratio = (recent_14d / 14) / max(0.001, hist_avg)
        growth_ratio = recent_14d / max(1, prev_7d)
        score = spike_ratio * growth_ratio * math.log(recent_14d + 1)
        if spike_ratio < 2.0:
            continue
        # Check if already launched
        is_launched = False
        for m in models:
            if m['make'].lower() == make.lower() and m['model'].lower() == model.lower():
                s = (m.get('dev_status','') + ' ' + m.get('notes','')).lower()
                if any(kw in s for kw in ['已上线','可售','在售','已上市']):
                    is_launched = True
                break
        if not is_launched:
            # Collect year/trim distribution for detail view
            det = trending_details.get(key, {})
            years_sorted = sorted(det.get('years', {}).items(), key=lambda x: -x[1])
            trims_sorted = sorted(det.get('trims', {}).items(), key=lambda x: -x[1])
            total_y = sum(c for _, c in years_sorted)
            trending.append({
                'make': make, 'model': model,
                'recent_14d': recent_14d, 'prev_7d': prev_7d,
                'total_submissions': total_hist + recent_14d,
                'spike_ratio': round(spike_ratio, 1),
                'growth_ratio': round(growth_ratio, 1),
                'trending_score': round(score, 1),
                'top_years': [{'year': y, 'count': c, 'pct': round(c/total_y*100)} for y, c in years_sorted[:5]] if total_y > 0 else [],
                'top_trims': [{'trim': t, 'count': c} for t, c in trims_sorted[:5]]
            })
    trending.sort(key=lambda x: -x['trending_score'])
    result['trending_models'] = trending[:20]
    print(f"Trending models: {len(trending)} found, top 20 saved")
else:
    result['trending_models'] = []
    print("No raw submission data with timestamps available for trending")

# === Year distribution for ALL models (detail modal: 点击车型弹年份占比) ===
trend_lookup = {k.lower(): k for k in trending_details}
def match_trend_key(m):
    mk = m['make'].lower()
    md = m['model'].lower()
    exact = trend_lookup.get(f"{mk}|{md}")
    if exact: return exact
    # Fallback: same make + word-boundary containment, prefer longest key (most specific)
    best = None
    for kl, k in trend_lookup.items():
        km, kd = kl.split('|', 1)
        if km != mk: continue
        if re.search(r'\b' + re.escape(kd) + r'\b', md) or re.search(r'\b' + re.escape(md) + r'\b', kd):
            if best is None or len(kd) > len(best[1].split('|', 1)[1]):
                best = (kl, k)
    return best[1] if best else None

matched = 0
for m in models:
    key = match_trend_key(m)
    if not key:
        m['years'] = []
        m['trims'] = []
        m['total_subs'] = 0
        continue
    det = trending_details[key]
    yrs = sorted(det.get('years', {}).items(), key=lambda x: -x[1])
    trims = sorted(det.get('trims', {}).items(), key=lambda x: -x[1])
    total_y = sum(c for _, c in yrs)
    m['years'] = [{'year': y, 'count': c, 'pct': round(c/total_y*100)} for y, c in yrs[:10]] if total_y else []
    m['trims'] = [{'trim': t, 'count': c} for t, c in trims[:6]]
    m['total_subs'] = total_y
    if total_y: matched += 1
print(f"Year distribution: {matched}/{len(models)} models matched")

# === Add competitor launch data ===
import sqlite3 as sq3
MAT_TYPES = ['Car Mat','Car Mat Accessory','Floor Mats','Bed Liners','Cargo Mat','Trunk Mat','Seat Back','Seatback','Boot Liner','Tray']
MAT_KW = ['floor mat','cargo mat','trunk mat','seatback','seat back','boot liner','bed liner','cargo liner','tray mat','all-weather','thorex','rubber mat','custom mat','liner mat']
def is_mat(pt, ti):
    if pt and any(m.lower() in pt.lower() for m in MAT_TYPES if m): return True
    if ti and any(k in ti.lower() for k in MAT_KW): return True
    return False

try:
    conn = sq3.connect("/home/ecs-user/.openclaw/workspace/competitor-data/competitor_monitor.db")
    cur = conn.cursor()
    cur.execute("SELECT brand,product_title,published_at,product_type FROM variants WHERE brand IN ('Lasfit','TuxMat') AND product_title IS NOT NULL")
    db_rows = cur.fetchall()
    conn.close()
    
    def extract_ys(t):
        t2 = t.upper()
        rs = re.findall(r'(\d{4})\s*[\-–]\s*(\d{4})', t2)
        ss = re.findall(r'\b(20\d{2})\b', t2)
        return [int(y[1]) for y in rs] + [int(s) for s in ss]
    
    for m in models:
        yr = 0
        s = (m['dev_status'] + ' ' + m.get('notes','')).upper()
        mt = re.search(r'(\d{2})\s*款', s)
        if mt: yr = 2000 + int(mt.group(1))
        if not yr:
            mt = re.search(r'\b(202[4-9]|2030)\b', s)
            if mt: yr = max(int(y) for y in re.findall(r'\b(202[4-9]|2030)\b', s))
        
        mu = m['model'].upper().replace('-',' ').replace(' ','')
        res = {}
        best = {}
        for b, pt, pd, ptype in db_rows:
            if not pt or not is_mat(ptype, pt): continue
            if mu not in pt.upper().replace('-',' ').replace(' ','').replace('_',''): continue
            ys = extract_ys(pt)
            sc = 10 if yr and yr in ys else 5 if ys and yr and min(abs(y-yr) for y in ys) <= 2 else 1
            d = (pd or '')[:10]
            if d and (b not in best or sc > best[b][1]): best[b] = (d, sc)
        merged = {}
        for b,d in res.items():
            if b not in best or d: merged[b] = d
        for b,(d,_) in best.items():
            if d: merged[b] = d
        m['competitors'] = [{"brand":b,"date":d} for b,d in sorted(merged.items()) if d]
except Exception as e:
    print(f"Competitor data: {e}")

with open("/home/ecs-user/.openclaw/workspace/3w-dashboard/dashboard_data.json", "w") as f:
    json.dump(result, f, ensure_ascii=False, indent=2)

print("✅ Dashboard data updated (kept user's dev_status, merged dev progress)")
PYEOF

echo "✅ 面板数据已更新（保留用户手动编辑，合并了开发进度备注）" >> "$LOG"
