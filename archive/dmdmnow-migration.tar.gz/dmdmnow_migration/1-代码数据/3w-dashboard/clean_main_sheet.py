#!/usr/bin/env python3
"""
飞书主表清洗工具 — 站内-车型提交人数（0iCDMN）
- 拼写纠错（Chrylser → Chrysler）
- Make 列提取纯品牌（"Chrysler Pacifica Limited" → "Chrysler"）
- 错误品牌重定向（Chevrolet Pacifica → Chrysler Pacifica）
- 车型变体合并（Pacifica Hybrid + Pacifica → Pacifica）
- 疑似图片/URL 垃圾数据清理
"""

import json, requests, re, sys
from collections import defaultdict

APP_ID = "cli_a95e614746395cbd"
SP = "NV6Gsl1lwhBw7RtYPTAcpQQenjq"

# Read secret from sync script
with open('/home/ecs-user/.openclaw/workspace/3w-dashboard/sync_3w.sh') as _f:
    for line in _f:
        m = re.search(r'APP_SECRET\s*=\s*"([^"]+)"', line)
        if m:
            APP_SECRET = m.group(1)
            break

def get_token():
    r = requests.post("https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
        json={"app_id": APP_ID, "app_secret": APP_SECRET}, timeout=10)
    return r.json()["tenant_access_token"]

# ============ BRAND NORMALIZATION ============

# Map: incorrect brand → correct brand (standard Make column value)
BRAND_FIXES = {
    # Chrysler misspellings
    'CHRYLSER': 'Chrysler', 'CHRYSLTER': 'Chrysler', 'CHRYSLER': 'Chrysler',
    'CHRYSTLER': 'Chrysler', 'CRYSLER': 'Chrysler', 'CRYSTLER': 'Chrysler',
    'CHYSLER': 'Chrysler', 'CHYSER': 'Chrysler', 'CRYSER': 'Chrysler',
    'CHRYSER': 'Chrysler', 'CHRYLER': 'Chrysler',
    # Chevrolet misspellings
    'CHEVY': 'Chevrolet', 'CHEVEY': 'Chevrolet', 'SHEVROLET': 'Chevrolet',
    'CHEVROLET/GMC': 'Chevrolet', 'CHEVROLET / CHRYSLER': 'Chrysler',
    # GMC
    'GMC ACADIA': 'GMC',
    # Chrysler + model in Make
    'CHRYSLER PACIFICA': 'Chrysler',
    'CHRYSLER PACIFICA LIMITED': 'Chrysler',
    'CHRYSLER PACIFICA PHEV': 'Chrysler',
    '2026 CHRYSLER PACIFICA PINNACLE': 'Chrysler',
    # Ford
    'FORD EXPLORER ACTIVE': 'Ford',
    # Hyundai
    'HUNDAY': 'Hyundai', 'HYUNDIA': 'Hyundai',
    # Nissan
    'NISAN': 'Nissan', 'NISSIAN': 'Nissan', 'NISSON': 'Nissan',
    # Subaru
    'SABARU': 'Subaru', 'SUBURA': 'Subaru',
    # Mazda
    'MAZDA CX-9': 'Mazda',
    # Mercedes
    'BENZ': 'Mercedes-Benz', 'MERCEDES BENZ': 'Mercedes-Benz',
    'MERCEDESBENZ': 'Mercedes-Benz',
    # Alfa Romeo
    'ALFA ROMEO STELVIO 2020': 'Alfa Romeo', 'ALFAROMEO': 'Alfa Romeo',
    'ALFO ROMEO': 'Alfa Romeo', 'ALPHA ROMEO': 'Alfa Romeo',
    # Genesis
    'GENECIS': 'Genesis', 'GENESI': 'Genesis', 'GENESIS COUPE': 'Genesis',
    'GENESIS ELECTRIFIED G80': 'Genesis', 'GENISIS': 'Genesis', 'GÉNESIS': 'Genesis',
    # Infiniti
    'INFINITY': 'Infiniti',
    # Bentley
    'BENTLY': 'Bentley',
    # Cadillac
    'CADDILAC': 'Cadillac', 'CADILAC': 'Cadillac',
    # Mitsubishi
    'MIRSUBISHI': 'Mitsubishi', 'MISTUBISHI': 'Mitsubishi',
    'MITISUBISHI': 'Mitsubishi', 'MITSHUBISHI': 'Mitsubishi',
    # Hummer
    'HUMMER H2': 'Hummer', 'HUMMRT': 'Hummer',
    # Mini
    'MINI COOPER': 'Mini',
    # Land Rover
    'LANDROVER': 'Land Rover', 'RANGE ROVER': 'Land Rover', 'RANGEROVER': 'Land Rover',
    # Misc
    'FODGE': 'Dodge',
    'DURANGO': 'Dodge',
    'FRONTIER': 'Nissan',
    'NAVIGATOR': 'Lincoln',
    'OUTLANDER': 'Mitsubishi',
    'SILVERADO': 'Chevrolet',
    'TAHOE': 'Chevrolet',
    'TUNDRA': 'Toyota',
    'PACIFICA': 'Chrysler',
    'MIS': 'Chevrolet',
    'TO': 'Kia',
    'TOYATA': 'Toyota', 'TOYOYA': 'Toyota',
    'LESUX 500H': 'Lexus',
    'RANM': 'Ram',
    'MAKE': None,  # garbage
    # Ford
    '1994 CHEVY K1500': 'Chevrolet',
    '2014 MINI COOPER S 2 DOOR': 'Mini',
    '2014 MINI COOPER S 2 DR HATCHBACK': 'Mini',
    '2010 MERCURY GRAN MARQUIS': 'Mercury',
    '2025 GWM HAVAL H6GT PHEV': 'GWM',
    # Lucid
    'LUCID GRAVITY GT': 'Lucid', 'LUCID MOTORS': 'Lucid',
    # Polestar
    'POLESTAR 4': 'Polestar',
    # Ineos
    'INEOS GRENADIER': 'Ineos',
    # McLaren
    'MCLAREN 750S': 'McLaren', 'MCLAREN': 'McLaren',
    # Others with junk
    'BESTUNE T77': None,
    'CFMOTO U-FORCE 800 XL': None,
    'FORTE': None,
    'LAVANTE': None, 'LIS': None, 'KUCID': None,
    'LOOKING FOR FITTED': None,
    'SCION XB': 'Scion',
    'MG (IM)': 'MG',
    'GWM TANK 700': 'GWM',
    'GEELY COOLRAY': 'Geely',
    'SUBURBAN': 'Chevrolet',
    'FREIGHTLINER M2-106 (FRONT AND REAR)': 'Freightliner',
    'FREIGHTLINER TRUCKS': 'Freightliner',
    'INTERNATIONAL HARVESTER': 'International',
    '🐆 JAGUAR': 'Jaguar',
    'SAURN': 'Saturn',
    'SUZKI': 'Suzuki',
    'TELSA': 'Tesla',
    'MECURY': 'Mercury',
    'GEOMETRY': 'Geely',
    'MASARATI': 'Maserati',
    'MORGAN': 'Morgan',
    'MORGAN': 'Morgan',
    'NIO': 'Nio',
    'WORKHORSE': 'Workhorse',
    'THOR': 'Thor',
    'VINFAST': 'VinFast',
    'VOYAH': 'Voyah',
    'RENAULT': 'Renault',
    'OPEL': 'Opel',
    'LADA': 'Lada',
    'CITROEN': 'Citroen',
    'CUPRA': 'Cupra',
    'DONGFENG': 'Dongfeng',
    'GAC': 'GAC',
    'CHANGAN': 'Changan',
    'CHANGAN AUTOMOBILE': 'Changan',
    'VAUXHALL': 'Vauxhall',
    'SMART': 'Smart',
    'HINO': 'Hino',
    'KENWORTH': 'Kenworth',
    'FREIGHTLINER': 'Freightliner',
    'INTERNATIONAL': 'International',
    'KARMA': 'Karma',
    'FISKER': 'Fisker',
    'RIVIAN': 'Rivian',
    'LUCID': 'Lucid',
    'LUCID MOTORS': 'Lucid',
    'POLESTAR': 'Polestar',
    'INEOS': 'Ineos',
    'MG': 'MG',
    'GWM': 'GWM',
    'BYD': 'BYD',
    'CHERY': 'Chery',
    'PEUGEOT': 'Peugeot',
    'SKODA': 'Skoda',
    'DATSUN': 'Datsun',
    'SAAB': 'Saab',
    'HUMMER': 'Hummer',
    'GEO': 'Geo',
    'DAEWOO': 'Daewoo',
    'ROVER': 'Rover',
    'ASTON MARTIN': 'Aston Martin',
    'BENTLEY': 'Bentley',
    'MCLAREN': 'McLaren',
    'MORGAN': 'Morgan',
}

# Brands that should redirect their Pacifica entries
PACIFICA_REDIRECT_BRANDS = {'Chevrolet', 'Dodge', 'Ram', 'Jeep', 'GMC', 'Ford', 'Toyota', 'Honda', 'Nissan'}

def normalize_make(raw_make):
    """Normalize a Make value: fix spelling, extract brand from compound values"""
    if not raw_make or not raw_make.strip():
        return None
    raw = raw_make.strip()
    
    # Direct fix lookup
    upper = raw.upper().strip()
    if upper in BRAND_FIXES:
        return BRAND_FIXES[upper]
    
    # Check if it starts with a brand key (extract brand from compound)
    brand_keys_raw = [
        'FORD','CHEVROLET','TOYOTA','GMC','HONDA','DODGE','NISSAN','KIA','HYUNDAI',
        'JEEP','SUBARU','VOLKSWAGEN','VW','MAZDA','BUICK','BMW','MERCEDES-BENZ','MERCEDES',
        'AUDI','LEXUS','CADILLAC','LINCOLN','RAM','CHRYSLER','ACURA','INFINITI','VOLVO',
        'TESLA','CHERY','BYD','PEUGEOT','SKODA','MINI','LAND ROVER','JAGUAR','GENESIS',
        'MASERATI','PORSCHE','MITSUBISHI','SCION','FIAT','SUZUKI','ISUZU','PONTIAC',
        'SATURN','OLDSMOBILE','MERCURY','HUMMER','DATSUN','OPEL','SAAB','GEO','DAEWOO','ROVER',
        'ALFA ROMEO','ASTON MARTIN','BENTLEY','MCLAREN','MORGAN','LAMBORGHINI','FERRARI',
        'LOTUS','TESLA','RIVIAN','LUCID','POLESTAR','INEOS','MG','GWM','CHANGAN','CUPRA',
        'DONGFENG','FISKER','KARMA','NIO','VINFAST','VOYAH','RENAULT','OPEL','LADA',
        'CITROEN','SMART','HINO','KENWORTH','FREIGHTLINER','INTERNATIONAL','WORKHORSE',
        'THOR','VAUXHALL','SAAB','HOLDEN','PROTON','PERODUA','SSANGYONG',
    ]
    for bk in sorted(brand_keys_raw, key=len, reverse=True):
        if upper.startswith(bk):
            # Return the proper display name
            return BRAND_FIXES.get(bk, bk.title())
    
    # Check if it looks like an image URL or JSON
    if raw.startswith('{') or raw.startswith('[') or 'globo.sfo2' in upper.lower() or '.jpg' in upper.lower() or '.jpeg' in upper.lower() or '.png' in upper.lower():
        return None
    
    # Check if value has numbers / is mostly numeric
    if any(c.isdigit() for c in raw) and len(raw) < 10:
        return None
    
    return raw.title()


def normalize_model(raw):
    """Normalize model name: remove powertrain-only suffixes (same body = same mats)
    e.g. Pacifica Hybrid → Pacifica (OK to merge, same body)
         Yukon XL → Yukon XL (DON'T merge, different body/different mats)
    """
    if not raw or not raw.strip():
        return None
    
    m = raw.strip().upper()
    
    # Remove year prefixes
    m = re.sub(r'^20\d{2}\s+', '', m)
    
    # Only strip powertrain type suffixes (same body, different engine)
    # Hybrid/PHEV/Plug-in/EV: same chassis, same floor mats → merge
    m = re.sub(r'\b(HYBRID|PHEV|PLUG[- ]?IN|EV)\b', '', m)
    
    # Clean up
    m = re.sub(r'\s+', ' ', m).strip()
    m = m.title()
    
    return m


# ============ MAIN ============

def main(dry_run=True):
    token = get_token()
    
    # Read main sheet (A:E - 5 columns)
    r = requests.get(f"https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SP}/values/0iCDMN!A:E",
        headers={"Authorization": f"Bearer {token}"}, timeout=30)
    data = r.json()
    rows = data["data"]["valueRange"]["values"]
    print(f"\n📋 读取主表: {len(rows)} 行 (含表头)")
    
    # Read header
    header = rows[0] if rows else []
    data_rows = rows[1:] if len(rows) > 1 else []
    
    # Analyze each row
    changes = []  # (row_index, column, old_value, new_value, reason)
    deletions = []  # row_index to delete/clear
    merged_counts = defaultdict(int)  # (new_make, new_model) -> merge_count
    
    for i, row in enumerate(data_rows):
        row_num = i + 2  # 1-indexed position in sheet
        
        if len(row) < 1:
            continue
        
        raw_make = str(row[0]).strip() if row[0] else ''
        raw_model = str(row[1]).strip() if len(row) > 1 and row[1] else ''
        try: count = int(float(str(row[2]))) if len(row) > 2 and row[2] else 0
        except: count = 0
        dev = str(row[3]).strip() if len(row) > 3 and row[3] else ''
        notes = str(row[4]).strip() if len(row) > 4 and row[4] else ''
        
        if not raw_make and not raw_model:
            continue
        
        # 1. Normalize Make
        new_make = normalize_make(raw_make)
        
        # Garbage detection
        if new_make is None:
            reason = '🗑️ 疑似垃圾数据（图片链接、JSON等）'
            deletions.append((row_num, raw_make, raw_model, count, reason))
            continue
        
        # Pacifica redirect: if model is Pacifica and make is wrong brand
        if 'PACIFICA' in (raw_model + raw_make).upper():
            if new_make in PACIFICA_REDIRECT_BRANDS:
                old_make = new_make
                new_make = 'Chrysler'
                changes.append((row_num, 'A', raw_make, new_make, f'Pacifica 品牌纠正: {old_make} → Chrysler'))
            elif new_make not in ['Chrysler'] and 'PACIFICA' in raw_make.upper():
                old_make = new_make if new_make else raw_make
                new_make = 'Chrysler'
                changes.append((row_num, 'A', raw_make, new_make, f'Pacifica 品牌提取: {old_make} → Chrysler'))
        
        # Check if Make changed
        if new_make != raw_make.strip().title() and not any(c[1]=='A' and c[0]==row_num for c in changes):
            changes.append((row_num, 'A', raw_make, new_make, f'品牌修复: {raw_make} → {new_make}'))
        
        # 2. Normalize Model - merge variants
        if raw_model:
            base_model = normalize_model(raw_model)
            if base_model and base_model != raw_model.strip().title():
                changes.append((row_num, 'B', raw_model, base_model, f'车型归一: {raw_model} → {base_model}'))
        
        # 3. Track for dedup
        if count > 0:
            mk = new_make if new_make else raw_make.strip().title()
            md = base_model if base_model else raw_model.strip().title()
            merged_counts[(mk, md)] += count
    
    # Print report
    print(f"\n{'='*60}")
    print(f"📊 清洗分析报告")
    print(f"{'='*60}")
    
    if deletions:
        print(f"\n🗑️ 疑似垃圾数据 ({len(deletions)} 行):")
        for rn, old_mk, old_md, cnt, reason in deletions[:10]:
            print(f"  Row {rn}: Make=\"{old_mk}\" Model=\"{old_md}\" ({cnt}人) — {reason}")
        if len(deletions) > 10:
            print(f"  ... 还有 {len(deletions)-10} 行")
    else:
        print(f"\n🗑️ 未发现垃圾数据")
    
    if changes:
        print(f"\n🔄 建议修改 ({len(changes)} 处):")
        for rn, col, old, new, reason in changes[:30]:
            print(f"  Row {rn} Col {col}: \"{old}\" → \"{new}\"  ({reason})")
        if len(changes) > 30:
            print(f"  ... 还有 {len(changes)-30} 处修改")
    else:
        print(f"\n🔄 无需修改")
    
    # Show top merged entries
    if merged_counts:
        print(f"\n📈 合并后热门车型 (去重前 {len(set(merged_counts.keys()))} 个唯一车型组合):")
        for (mk, md), cnt in sorted(merged_counts.items(), key=lambda x: -x[1])[:10]:
            # Find how many source entries were merged
            src_entries = [r for r in data_rows if len(r)>=3 and 
                          normalize_make(str(r[0]).strip() if r[0] else '') == mk]
            src_count = len(src_entries)
            print(f"  {mk} {md}: {cnt}人 ({src_count} 个原始条目)")
    
    total_rows = len(data_rows)
    clean_rows = total_rows - len(deletions)
    print(f"\n📊 汇总:")
    print(f"  总行数: {total_rows}")
    print(f"  垃圾行: {len(deletions)}")
    print(f"  需修改: {len(changes)}")
    print(f"  清洗后: {clean_rows} 行")
    
    if dry_run:
        print(f"\n⚠️  当前为 DRY RUN 模式，未实际写入飞书表")
        print(f"✅ 如需执行清洗，请添加 --apply 参数运行: python3 clean_main_sheet.py --apply")
    else:
        # Apply changes
        print(f"\n🔄 开始执行清洗...")
        
        # Build updated rows
        updated_rows = []
        for i, row in enumerate(data_rows):
            row_num = i + 2
            
            # Check if this row is to be deleted
            deleted = any(d[0] == row_num for d in deletions)
            if deleted:
                continue
            
            # Start with the original row values (up to 5 columns)
            new_row = list(row[:5]) if row else [''] * 5
            while len(new_row) < 5:
                new_row.append('')
            
            # Apply changes
            for rn, col, old, new, reason in changes:
                if rn == row_num:
                    col_idx = ord(col) - ord('A')
                    if col_idx < len(new_row):
                        new_row[col_idx] = new
            
            updated_rows.append(new_row)
        
        # Write back: first clear the sheet, then write new data
        sheet_id = '0iCDMN'
        range_str = f'{sheet_id}!A1:E{len(updated_rows)+1}'
        
        # Build the full data (header + cleaned rows)
        write_data = [header] + updated_rows
        
        from urllib.parse import quote
        
        # Write via Feishu API 需要先获取 spreadsheet token 信息
        # 获取 sheets metadata
        import urllib.parse
        
        # 使用 update range API
        payload = {
            "valueRange": {
                "range": range_str,
                "values": write_data
            }
        }
        
        # Write full cleaned dataset via batch API (split into chunks)
        batch_url = f"https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SP}/values_batch_update"
        
        # Build the full cleaned data (header + cleaned rows)
        all_data = [header] + updated_rows
        total_rows = len(all_data)
        
        # Split into chunks of 500 rows per range
        chunk_size = 500
        value_ranges = []
        for chunk_start in range(0, total_rows, chunk_size):
            chunk_end = min(chunk_start + chunk_size, total_rows)
            chunk_data = all_data[chunk_start:chunk_end]
            start_row = chunk_start + 1  # 1-based
            end_row = chunk_end
            cell_range = f"{sheet_id}!A{start_row}:E{end_row}"
            value_ranges.append({
                "range": cell_range,
                "values": chunk_data
            })
        
        # Also clear remaining rows (old data beyond cleaned data)
        if total_rows < 7000:
            remaining_start = total_rows + 1
            for rs in range(remaining_start, 7001, chunk_size):
                re_end = min(rs + chunk_size - 1, 7000)
                clear_rows = re_end - rs + 1
                value_ranges.append({
                    "range": f"{sheet_id}!A{rs}:E{re_end}",
                    "values": [[''] * 5 for _ in range(clear_rows)]
                })
        
        # Send batch update
        print(f"  准备写入 {total_rows} 行 (含表头) + {max(0, 7000-total_rows)} 行清除 (共 {len(value_ranges)} 个range)")
        
        br = requests.post(batch_url,
            headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
            params={"valueInputOption": "USER_ENTERED"},
            json={"valueRanges": value_ranges}, timeout=300)
        result = br.json()
        
        if result.get('code') == 0:
            print(f"  ✅ 写入成功! {total_rows} 行数据")
            print(f"\n✅ 清洗完成！")
            return True
        else:
            print(f"  ❌ 写入失败: {result.get('msg', '')}")
            return False
    
    return True

if __name__ == '__main__':
    dry_run = '--apply' not in sys.argv
    main(dry_run=dry_run)
