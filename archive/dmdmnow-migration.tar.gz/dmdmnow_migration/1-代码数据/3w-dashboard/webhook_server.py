#!/usr/bin/env python3
"""Webhook 服务器 - 调用后自动从飞书拉取数据更新面板"""
import subprocess, json, os
from flask import Flask, jsonify, request
from datetime import datetime

app = Flask(__name__)
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
FETCH_SCRIPT = os.path.join(SCRIPT_DIR, "feishu_fetch.py")

@app.route("/")
def index():
    return jsonify({
        "service": "WOLFBOX 数据同步 Webhook",
        "endpoints": {
            "/": "本页",
            "/webhook": "触发数据同步 (GET/POST)",
            "/status": "查看面板状态"
        }
    })

@app.route("/webhook", methods=["GET", "POST"])
def webhook():
    """触发数据同步"""
    try:
        result = subprocess.run(
            ["python3", FETCH_SCRIPT],
            capture_output=True, text=True, timeout=30,
            cwd=SCRIPT_DIR
        )
        if result.returncode == 0:
            return jsonify({"status": "ok", "message": "数据同步成功", "output": result.stdout.strip()})
        else:
            return jsonify({"status": "error", "message": result.stderr.strip()})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)})

@app.route("/refresh-3w", methods=["GET","POST"])
def refresh_3w():
    """触发3W面板刷新"""
    try:
        result = subprocess.run(
            ["bash", "/home/ecs-user/.openclaw/workspace/3w-dashboard/sync_3w.sh"],
            capture_output=True, text=True, timeout=120
        )
        resp = jsonify({"status": "ok", "message": "3W面板刷新成功"}) if result.returncode == 0 else jsonify({"status": "error", "message": result.stderr[-200:]})
        resp.headers["Access-Control-Allow-Origin"] = "*"
        return resp
    except Exception as e:
        resp = jsonify({"status": "error", "message": str(e)})
        resp.headers["Access-Control-Allow-Origin"] = "*"
        return resp

@app.route("/status")
def status():
    """查看当前面板数据状态"""
    json_file = os.path.join(SCRIPT_DIR, "analysis_data.json")
    if os.path.exists(json_file):
        with open(json_file) as f:
            data = json.load(f)
        return jsonify({
            "vehicle_count": len(data.get("vehicle_data", [])),
            "new_product_count": len(data.get("new_product_data", [])),
            "updated_at": data.get("updated_at", "未知"),
            "file_size": os.path.getsize(json_file)
        })
    return jsonify({"status": "no_data"})

if __name__ == "__main__":
    print(f"🚀 Webhook 服务器启动: http://0.0.0.0:7891")
    print(f"   触发同步: http://localhost:7891/webhook")
    app.run(host="0.0.0.0", port=7891)
