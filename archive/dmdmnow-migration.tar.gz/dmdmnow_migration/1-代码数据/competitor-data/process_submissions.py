#!/usr/bin/env python3
"""
处理客户车型提交数据：
1. 对比Excel和飞书表，规整Make/Model/销售版本/Year，写入新增记录
2. 更新"站内-车型提交人数"表（合并提交数+开发进度）
3. 更新面板
"""
import requests, json, openpyxl, re, time, os, shutil
from datetime import datetime
from collections import Counter

APP_ID = 'cli_a95e614746395cbd'
APP_SECRET = 'ZTPbyJlJNK0utcjkqgTazh8JDnLFhK4X'
SPREADSHEET_TOKEN = 'NV6Gsl1lwhBw7RtYPTAcpQQenjq'
SHEET_SUBMISSIONS = '1sCyzd'   # 站内-客户提交 车型 年份 备注
SHEET_COUNTS = '0iCDMN'        # 站内-车型提交人数

EXCEL_FILE = '/home/ecs-user/.openclaw/media/inbound/SubmissionsExport808e8e8f3e338f17169a29e7bec09625-3wliners.m---3d4d47bd-a8a0-4f2a-86cc-9280ac49e1ad.xlsx'
DATA_DIR = '/home/ecs-user/.openclaw/workspace/competitor-data'

# ===== 品牌标准化 =====
MAKE_NORMALIZE = {
    'chevy': 'Chevrolet', 'chev': 'Chevrolet', 'chevrolet': 'Chevrolet',
    'gmc': 'GMC',
    'ram': 'Ram', 'dodge': 'Ram', 'dodgeram': 'Ram',
    'jeep': 'Jeep',
    'toyota': 'Toyota', 'lexus': 'Lexus', 'scion': 'Scion',
    'honda': 'Honda', 'acura': 'Acura', 'hyundai': 'Hyundai',
    'kia': 'Kia',
    'ford': 'Ford', 'lincoln': 'Lincoln',
    'nissan': 'Nissan', 'infiniti': 'Infiniti',
    'mitsubishi': 'Mitsubishi',
    'mazda': 'Mazda', 'subaru': 'Subaru',
    'volkswagen': 'Volkswagen', 'vw': 'Volkswagen',
    'audi': 'Audi', 'bmw': 'BMW', 'mercedes': 'Mercedes-Benz',
    'porsche': 'Porsche', 'volvo': 'Volvo',
    'tesla': 'Tesla', 'rivian': 'Rivian', 'lucid': 'Lucid',
    'cadillac': 'Cadillac', 'buick': 'Buick', 'chrysler': 'Chrysler',
    'mini': 'MINI',
    'land rover': 'Land Rover', 'jaguar': 'Jaguar',
    'fiat': 'Fiat', 'hummer': 'Hummer',
    'suzuki': 'Suzuki', 'isuzu': 'Isuzu',
    'genesis': 'Genesis', 'polestar': 'Polestar',
    'chevrolet(GM)': 'Chevrolet',
}

# Common trim/version keywords
TRIM_WORDS = [
    'xlt','xls','xl','xlt premium','xlt sport','lariat','king ranch','platinum',
    'lt','ltz','lt1','ls','rst','trail boss','high country','z71','zr2',
    'rt','r/t','rt plus','sxt','gt','gt line','gt2','gt-line',
    'sr5','sr','trd pro','trd off-road','trd sport','trd','limited','platinum',
    'denali','at4','sle','slt','elevation',
    'lx','ex','ex-l','touring','sport','lx-p','lx',
    'se','sel','sel plus','ultimate','premium','luxury','base',
    'titanium','ses','titanium',
    'lx 570','lx600','gx460','gx550','nx','nx 350','nx 350h','rx','rx 350',
    's 350','s 500','e 350','glc','gle','gls',
    'x1','x2','x3','x4','x5','x6','x7',
    'a3','a4','a5','a6','a7','a8','q3','q5','q7','q8',
    'model 3','model y','model s','model x',
    'r1t','r1s',
    'crew cab','supercab','supercrew','regular cab','extended cab',
    '2wd','4wd','4x4','awd',
    'short bed','long bed','standard bed',
]

def safe_str(v):
    if v is None: return ''
    if isinstance(v, (int, float)): return str(int(v))
    return str(v).strip()

def norm_make(raw):
    raw = raw.strip()
    if not raw: return ''
    lower = raw.lower()
    if lower in MAKE_NORMALIZE:
        return MAKE_NORMALIZE[lower]
    for key, val in sorted(MAKE_NORMALIZE.items(), key=lambda x: -len(x[0])):
        if key in lower:
            return val
    return raw.title()

def extract_trim(model):
    """Extract trim/version from model string"""
    lower = model.lower().strip()
    for kw in sorted(TRIM_WORDS, key=lambda x: -len(x)):
        if kw in lower:
            idx = lower.index(kw)
            end = idx + len(kw)
            # Make sure it's a word boundary
            if (idx == 0 or not lower[idx-1].isalnum()) and \
               (end >= len(lower) or not lower[end].isalnum()):
                return model[idx:end].strip().title()
    return ''

def split_model_trim(model_str):
    """Split model string into model + trim"""
    trim = extract_trim(model_str)
    if trim:
        remaining = re.sub(re.escape(trim), '', model_str, flags=re.IGNORECASE).strip()
        return remaining, trim
    return model_str, ''

def clean_model(model):
    """Clean up model name"""
    model = re.sub(r'\s*\(.*?\)', '', model).strip()
    model = re.sub(r'\s+', ' ', model).strip()
    return model

def normalize_entry(raw_make, raw_model, raw_year, raw_note):
    """Normalize make, model, year, and extract trim"""
    make = norm_make(raw_make) if raw_make else ''
    model = raw_model.strip() if raw_model else ''
    note = raw_note if raw_note else ''
    year = raw_year
    
    # Clean model
    model = clean_model(model)
    
    # Extract trim from model
    model, trim = split_model_trim(model)
    
    # Title case model
    if model:
        model = model.title()
    
    return make, model, trim, year

def feishu_read_all(token, sheet_id):
    """Read all Feishu sheet data in chunks"""
    all_rows = []
    chunk_size = 2000
    for start in range(1, 35000, chunk_size):
        end = min(start + chunk_size - 1, 35000)
        url = f'https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SPREADSHEET_TOKEN}/values/{sheet_id}!A{start}:J{end}'
        r = requests.get(url, headers={'Authorization': f'Bearer {token}'}, timeout=30)
        data = r.json()
        rows = data['data']['valueRange']['values']
        if start == 1:
            all_rows.extend(rows)
        else:
            all_rows.extend(rows)
        # Check if we've reached empty rows
        last_few = rows[-5:] if len(rows) >= 5 else rows
        if not any(any(cell for cell in r[:5] if cell) for r in last_few):
            break
        time.sleep(0.3)
    return all_rows

def feishu_write(token, sheet_id, start_row, rows_data):
    """Write rows to Feishu sheet"""
    end_row = start_row + len(rows_data) - 1
    url = f'https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SPREADSHEET_TOKEN}/values'
    body = {
        'valueRange': {
            'range': f'{sheet_id}!A{start_row}:J{end_row}',
            'values': rows_data
        }
    }
    r = requests.put(url, headers={'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'},
                     json=body, timeout=30)
    result = r.json()
    if result.get('code') != 0:
        raise Exception(f"Write error: {result}")
    return result

def get_token():
    r = requests.post('https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal',
                      json={'app_id': APP_ID, 'app_secret': APP_SECRET}, timeout=10)
    return r.json()['tenant_access_token']

def load_kanban_progress():
    """Load development kanban progress data"""
    token = get_token()
    all_records = []
    page_token = None
    while True:
        url = f'https://open.feishu.cn/open-apis/bitable/v1/apps/Oip3bNqqHaQeves6xIAc2iHXnnW/tables/tbl3bbHPe7EeIV1D/records?page_size=100'
        if page_token: url += f'&page_token={page_token}'
        r = requests.get(url, headers={'Authorization': f'Bearer {token}'}, timeout=15)
        data = r.json()
        all_records.extend(data['data']['items'])
        if not data['data'].get('has_more'): break
        page_token = data['data']['page_token']
        time.sleep(0.2)
    
    kanban = {}
    for rec in all_records:
        f = rec['fields']
        brand = (f.get('品牌', '') or '').strip()
        model = (f.get('车型', '') or '').strip()
        if not brand or not model: continue
        node_list = f.get('当前节点', []) or []
        node_text = node_list[0].get('text', '') if isinstance(node_list, list) and node_list else ''
        status_list = f.get('当前节点状态', []) or []
        status_text = status_list[0].get('text', '') if isinstance(status_list, list) and status_list else ''
        priority = f.get('优先级', '') or ''
        launch_list = f.get('计划上市时间', []) or []
        launch_text = launch_list[0].get('text', '') if isinstance(launch_list, list) and launch_list else ''
        
        # Determine 是否开发 status based on node
        if node_text in ('已上市', '上市', '生产', '下单', '核车', '修模', '开模', '寄样'):
            dev_status = '已开发'
            if status_text in ('🏁已上市',):
                dev_status = '已上线'
        elif node_text in ('立项', '扫描', '产品设计'):
            dev_status = '已开发'
        else:
            dev_status = ''
        
        key = f'{brand.lower()}|{model.lower()}'
        kanban[key] = {
            'status': dev_status,
            'node': node_text,
            'node_status': status_text,
            'priority': priority,
            'launch': launch_text,
        }
    return kanban

def update_data_dashboard():
    """Update analysis_data.json and sync to dashboard"""
    # Copy the existing feishu_fetch approach for the 3W dashboard
    # The 3W dashboard is at dashboard.dmdmnow.com/3w/
    # Let's check what's in the 3w_dashboard_data.json
    print("  📊 更新 3W dashboard 数据...")
    
    # Run the existing update script if applicable
    if os.path.exists(os.path.join(DATA_DIR, 'update_analysis_data.sh')):
        import subprocess
        result = subprocess.run(['bash', 'update_analysis_data.sh'], 
                               cwd=DATA_DIR, capture_output=True, text=True, timeout=120)
        print(f"  {result.stdout[-200:]}")
        if result.returncode != 0:
            print(f"  ⚠ stderr: {result.stderr[-200:]}")


def main():
    print("=" * 60)
    print("🚀 开始处理客户车型提交数据")
    print(f"时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)
    
    # ---- Step 0: Load kanban progress ----
    print("\n📋 加载开发看板进度...")
    kanban = load_kanban_progress()
    print(f"  看板 {len(kanban)} 个车型的进度")
    
    token = get_token()
    
    # ---- Step 1: Read Excel ----
    print("\n📂 读取Excel文件...")
    wb = openpyxl.load_workbook(EXCEL_FILE)
    ws = wb['Vehicle Collection']
    excel_rows = list(ws.iter_rows(values_only=True))
    print(f"  Excel行数: {len(excel_rows)} (含表头)")
    
    excel_data = []
    for row in excel_rows[1:]:
        if not row[0]: continue
        excel_data.append({
            'make': safe_str(row[6] or row[7]),
            'model': safe_str(row[8]),
            'year': safe_str(row[9]).split('.')[0] if row[9] else '',
            'note': safe_str(row[10]),
            'email': safe_str(row[5]).lower(),
            'created': safe_str(row[12]),
        })
    print(f"  Excel有效记录: {len(excel_data)}")
    
    # ---- Step 2: Read Feishu existing data ----
    print("\n📖 读取飞书表已有数据...")
    all_rows = feishu_read_all(token, SHEET_SUBMISSIONS)
    print(f"  总行数(含空行): {len(all_rows)}")
    
    # Find last non-empty row
    last_data_row = 0
    feishu_lookup = set()
    for i, row in enumerate(all_rows):
        if len(row) >= 5 and any(cell for cell in row[:5] if cell):
            last_data_row = i + 1
            if i > 0:  # skip header
                make = safe_str(row[0]).lower() if len(row) > 0 else ''
                model = safe_str(row[1]).lower() if len(row) > 1 else ''
                year = safe_str(row[3]) if len(row) > 3 else ''
                email = ''
                if len(row) > 7:
                    e = row[7]
                    if isinstance(e, str): email = e.strip().lower()
                    elif isinstance(e, dict): email = e.get('text', '').strip().lower()
                feishu_lookup.add(f'{make}|{model}|{year}|{email}')
    
    print(f"  最后数据行: {last_data_row}")
    print(f"  已有唯一记录: {len(feishu_lookup)}")
    
    # ---- Step 3: Find new entries ----
    print("\n🔍 对比查找新增记录...")
    new_entries = []
    for d in excel_data:
        mak_norm = norm_make(d['make']).lower()
        mod_norm = clean_model(d['model']).lower()
        key = f'{mak_norm}|{mod_norm}|{d["year"]}|{d["email"]}'
        key2 = f'{d["make"].strip().lower()}|{d["model"].strip().lower()}|{d["year"]}|{d["email"]}'
        if key not in feishu_lookup and key2 not in feishu_lookup:
            new_entries.append(d)
    
    print(f"  新增记录: {len(new_entries)}")
    
    if new_entries:
        # ---- Step 4: Normalize and prepare rows ----
        print("\n🏷️ 规整Make/Model/销售版本/Year...")
        prepared = []
        for d in new_entries:
            make, model, trim, year = normalize_entry(d['make'], d['model'], d['year'], d['note'])
            row_data = [make, model, trim, year, d['note'], '', '', d['email'], d['created'], 1]
            prepared.append(row_data)
        
        # ---- Step 5: Write to Feishu ----
        print(f"\n✍️ 写入 {len(prepared)} 条到飞书表...")
        start = last_data_row + 1
        BATCH = 200
        for i in range(0, len(prepared), BATCH):
            batch = prepared[i:i+BATCH]
            try:
                feishu_write(token, SHEET_SUBMISSIONS, start, batch)
                print(f"  ✓ {start}-{start+len(batch)-1} ({len(batch)}条)")
                start += len(batch)
            except Exception as e:
                print(f"  ✗ 写入失败: {e}")
                for j, r in enumerate(batch):
                    try:
                        feishu_write(token, SHEET_SUBMISSIONS, start+j, [r])
                    except:
                        print(f"    ✗ 单行写入失败")
            time.sleep(0.5)
        print(f"  ✅ 写入完成！")
    else:
        print("  无新增数据")
    
    # ---- Step 6: Update 站内-车型提交人数 ----
    print("\n" + "=" * 60)
    print("📊 更新 站内-车型提交人数...")
    
    # Read existing count sheet
    url = f'https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SPREADSHEET_TOKEN}/values/{SHEET_COUNTS}!A1:G1000'
    r = requests.get(url, headers={'Authorization': f'Bearer {token}'}, timeout=15)
    count_rows = r.json()['data']['valueRange']['values']
    
    existing_progress = {}
    for row in count_rows[1:]:
        if not row or not row[0] or not row[1]: continue
        mk = safe_str(row[0]); md = safe_str(row[1])
        existing_progress[f'{mk.lower()}|{md.lower()}'] = {
            'status': row[3] if len(row) > 3 else '',
            'note': row[4] if len(row) > 4 else '',
            'note2': row[5] if len(row) > 5 else '',
            'competitor': row[6] if len(row) > 6 else '',
        }
    
    print(f"  当前人数表已有: {len(existing_progress)} 条")
    
    # ---- Re-read all submission data to get accurate counts ----
    print("  重新统计所有提交人数...")
    all_rows = feishu_read_all(token, SHEET_SUBMISSIONS)
    
    submission_counts = Counter()
    for row in all_rows[1:]:
        if len(row) < 5 or not any(cell for cell in row[:5] if cell): break
        mk = safe_str(row[0])
        md = safe_str(row[1])
        if not mk or not md: continue
        submission_counts[f'{mk}|{md}'] += 1
    
    print(f"  去重后车型数: {len(submission_counts)}")
    
    # Build new count sheet rows with merged progress
    sorted_models = sorted(submission_counts.items(), key=lambda x: -x[1])
    new_rows = [['Make', 'Model', '提交人数', '是否开发', '备注', '2026/5/29更', '竞品上线']]
    
    preserved = 0; new_added = 0; updated_kanban = 0
    for key, count in sorted_models:
        make, model = key.split('|', 1)
        if key in existing_progress:
            prog = existing_progress[key]
            status = prog['status']
            note = prog['note']
            note2 = prog['note2']
            comp = prog['competitor']
        else:
            status = ''; note = ''; note2 = ''; comp = ''
            new_added += 1
        
        # Check if kanban has progress info for this vehicle
        kanban_key = f'{make.lower()}|{model.lower()}'
        if kanban_key in kanban:
            kb = kanban[kanban_key]
            if kb['status'] and not status:
                status = kb['status']
                updated_kanban += 1
            # Add node info to note2 if not already there
            if kb['node']:
                node_info = f"看板:{kb['node']}|{kb['priority']}"
                if kb['launch']:
                    node_info += f"|上市:{kb['launch']}"
                if note2:
                    if node_info not in note2:
                        note2 += f" | {node_info}"
                else:
                    note2 = node_info
        else:
            preserved += 1
        
        new_rows.append([make, model, count, status, note, note2, comp])
    
    print(f"  保留进度: {preserved} | 新增车型: {new_added} | 看板匹配更新: {updated_kanban}")
    
    # Write count sheet - for large data, Feishu API has limits
    print(f"  写入 {len(new_rows)} 行到人数表...")
    max_row = len(new_rows)
    
    # Write in chunks if needed
    url = f'https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SPREADSHEET_TOKEN}/values'
    body = {
        'valueRange': {
            'range': f'{SHEET_COUNTS}!A1:G{max_row}',
            'values': new_rows
        }
    }
    r = requests.put(url, headers={'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'},
                     json=body, timeout=60)
    result = r.json()
    if result.get('code') == 0:
        print(f"  ✅ 人数表已更新 ({max_row-1} 条)")
    else:
        print(f"  ✗ 写入失败: {result}")
    
    # ---- Step 7: Update dashboard ----
    print("\n" + "=" * 60)
    print("🌐 更新面板...")
    update_data_dashboard()
    
    print("\n" + "=" * 60)
    print("✅ 全部完成！")
    print(f"  新增提交记录: {len(new_entries)} 条")
    print(f"  人数表总车型: {len(submission_counts)} 个")
    print(f"  看板进度已合并")

if __name__ == '__main__':
    main()
