#!/usr/bin/env python3
"""批量修复所有车型标准化：从 Model 提取销售版本"""
import requests, json, re, time, sys
from collections import Counter

with open('/tmp/_secret.txt') as f:
    SECRET = f.read().strip()

APP_ID = 'cli_a95e614746395cbd'
# Read from file to avoid redaction
with open('/tmp/_spreadsheet_token.txt') as f:
    SPREADSHEET_TOKEN = f.read().strip()
SHEET = '1sCyzd'

def txt(v):
    if v is None: return ''
    if isinstance(v, (int, float)): return str(int(v))
    if isinstance(v, list): return ''
    return str(v).strip()

def get_token():
    r = requests.post('https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal',
                      json={'app_id': APP_ID, 'app_secret': SECRET}, timeout=10)
    return r.json()['tenant_access_token']

# ===== FIX RULES: (make_lower, model_contains_lower, trim_lower) -> (new_model, trim_display) =====
FIX = []

def add(make, model_has, trim_word, new_model=None):
    FIX.append((make.lower(), model_has.lower(), trim_word.lower(), new_model or model_has, trim_word))

# === Ford ===
for t in ['XLT','XL','Lariat','Platinum','Limited','King Ranch','STX']:
    add('Ford','F-150',t); add('Ford','F150',t); add('Ford','F 150',t)
for t in ['XLT','XL','Lariat','Platinum','Limited','King Ranch']:
    add('Ford','F-250',t); add('Ford','F250',t)
    add('Ford','F-350',t); add('Ford','F350',t)
    add('Ford','F-450',t); add('Ford','F450',t)
for t in ['XLT','Limited','Platinum','King Ranch']:
    add('Ford','Expedition',t)
for t in ['XLT','Limited','Platinum','ST']:
    add('Ford','Explorer',t)
for t in ['SE','SEL','Titanium','ST-Line','S-Line']:
    add('Ford','Escape',t)
for t in ['XLT','Lariat']:
    add('Ford','Ranger',t)
    add('Ford','Maverick',t)
add('Ford','Mustang','GT'); add('Ford','Mustang','EcoBoost')
add('Ford','Ranger','Raptor')
add('Ford','Bronco','Sport')  # Bronco Sport is a model variant
for t in ['XLT','XL','Lariat','Platinum','Limited']:
    add('Ford','Super Duty',t)

# === Chevrolet ===
for m in ['Silverado 1500','Silverado 2500','Silverado 2500HD','Silverado 3500']:
    for t in ['LT','LTZ','LS','RST','Z71','Trail Boss','High Country','WT','Custom','Premier']:
        add('Chevrolet',m,t); add('Chevy',m,t)
for m in ['Tahoe','Suburban']:
    for t in ['LS','LT','LTZ','RST','Premier','High Country','Z71']:
        add('Chevrolet',m,t); add('Chevy',m,t)
for m in ['Traverse']:
    for t in ['LS','LT','LTZ','RST','Premier']:
        add('Chevrolet',m,t); add('Chevy',m,t)
for m in ['Equinox']:
    for t in ['LS','LT','Premier']:
        add('Chevrolet',m,t); add('Chevy',m,t)
for m in ['Colorado']:
    for t in ['LT','ZR2','Z71','Trail Boss']:
        add('Chevrolet',m,t); add('Chevy',m,t)
for m in ['Blazer']:
    for t in ['LT','LTZ','RST','Premier']:
        add('Chevrolet',m,t); add('Chevy',m,t)

# === GMC ===
for m in ['Sierra 1500','Sierra 2500','Sierra 2500HD','Sierra 3500']:
    for t in ['Denali','SLT','SLE','Elevation','AT4']:
        add('GMC',m,t)
for m in ['Yukon','Acadia','Terrain']:
    for t in ['Denali','SLT','SLE','Elevation','AT4']:
        add('GMC',m,t)
add('GMC','Yukon','XL','Yukon XL')

# === Ram/Dodge ===
for make in ['Ram','Dodge']:
    for m in ['1500','2500','3500']:
        for t in ['Big Horn','Laramie','Rebel','Limited','Longhorn','Tradesman','Sport']:
            add(make,m,t)
    add(make,'1500','GT','Ram 1500')
    add(make,'2500','Power Wagon','Ram 2500')
for t in ['R/T','GT','SXT','Citadel','Plus']:
    add('Dodge','Durango',t)
add('Dodge','Charger','R/T'); add('Dodge','Challenger','R/T')

# === Toyota ===
for m in ['Tundra','Tacoma']:
    for t in ['Limited','Platinum','SR5','1794','TRD Pro','TRD Sport','Capstone','TRD Off-Road','Trailhunter','SR']:
        add('Toyota',m,t)
for m in ['Highlander','Sienna']:
    for t in ['LE','XLE','Limited','Platinum']:
        add('Toyota',m,t)
for m in ['Camry','Corolla','RAV4']:
    for t in ['LE','XLE','SE','XSE']:
        add('Toyota',m,t)
for m in ['4Runner']:
    for t in ['SR5','Limited','TRD Pro','TRD Sport','TRD Off-Road','Premium']:
        add('Toyota',m,t)
add('Toyota','Grand Highlander','LE'); add('Toyota','Grand Highlander','XLE')
add('Toyota','Grand Highlander','Limited'); add('Toyota','Grand Highlander','Platinum')

# === Honda ===
for m in ['CR-V','CRV','CR V']:
    for t in ['LX','EX','EX-L','Touring','Sport','Elite']:
        add('Honda',m,t)
for m in ['Civic','Accord','Pilot','Odyssey']:
    for t in ['LX','EX','EX-L','Touring','Sport','Elite']:
        add('Honda',m,t)

# === Jeep ===
for t in ['Laredo','Limited','Trailhawk','Overland','Summit','Altitude','L']:
    add('Jeep','Grand Cherokee',t)
for t in ['Latitude','Limited','Trailhawk','Altitude','Sport','L']:
    add('Jeep','Cherokee',t)
for t in ['Sport','Sahara','Rubicon']:
    add('Jeep','Wrangler',t)
for t in ['Sport','Sahara','Rubicon','Overland']:
    add('Jeep','Gladiator',t)
add('Jeep','Wagoneer','L')

# === Nissan ===
for m in ['Frontier','Rogue','Pathfinder','Armada','Titan']:
    for t in ['S','SV','SL','Platinum','Pro-4X','Pro 4X']:
        add('Nissan',m,t)

# === Hyundai ===
for m in ['Tucson','Santa Fe','Palisade']:
    for t in ['SE','SEL','Limited','Calligraphy']:
        add('Hyundai',m,t)
for m in ['Sonata','Elantra','Kona']:
    for t in ['SE','SEL','Limited','Sport','N Line']:
        add('Hyundai',m,t)

# === Kia ===
for m in ['Telluride','Sorento','Sportage','Carnival']:
    for t in ['LX','S','EX','SX','Prestige','X-Line','X Line','Xline','SX Prestige']:
        add('Kia',m,t)

# === Chrysler ===
for t in ['Limited','Touring','Touring L','Touring L Plus','Pinnacle','Select','Plus','Launch Edition','L']:
    add('Chrysler','Pacifica',t)

# === Subaru ===
for m in ['Outback','Forester','Crosstrek','Ascent']:
    for t in ['Premium','Limited','Touring','Wilderness','Sport','Onyx']:
        add('Subaru',m,t)

# === Mazda ===
for m in ['CX-5','CX5','CX-9','CX9','CX-30','CX30','CX-90','CX90','Mazda3','Mazda 3','Mazda6','Mazda 6']:
    for t in ['Sport','Touring','Grand Touring','Signature','Premium','Turbo']:
        add('Mazda',m,t)

# === Lincoln ===
add('Lincoln','Navigator','L')
add('Lincoln','Aviator','Reserve')

# === Volkswagen ===
for m in ['Atlas','Tiguan','Jetta']:
    for t in ['S','SE','SEL']:
        add('Volkswagen',m,t)

# === Lexus ===
for m in ['RX','NX','GX','ES']:
    for t in ['Premium','Luxury','F Sport']:
        add('Lexus',m,t)

# === Audi ===
for m in ['Q5','Q3','Q7','A3','A4','A5','A6']:
    for t in ['Premium','Premium Plus','Prestige']:
        add('Audi',m,t)

# === BMW ===
for m in ['X3','X5','X1','X7']:
    for t in ['xDrive','sDrive']:
        add('BMW',m,t)

# ===== MAIN =====
def main():
    print("="*60)
    print("🚗 批量修复车型标准化")
    print("="*60)
    
    token = get_token()
    print("✅ Token OK")
    
    # Read all data
    print("\n📖 读取所有数据...")
    data_map = {}  # row_num -> (make, model, trim, year)
    for start in range(1, 36500, 2000):
        end = min(start + 1999, 36500)
        url = f'https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SPREADSHEET_TOKEN}/values/{SHEET}!A{start}:D{end}'
        r = requests.get(url, headers={'Authorization': f'Bearer {token}'}, timeout=30)
        data = r.json()
        if data.get('code') != 0:
            print(f'  ⚠ 读取失败行 {start}')
            time.sleep(0.5)
            continue
        rows = data['data']['valueRange']['values']
        for i, row in enumerate(rows):
            rn = start + i
            if len(row) >= 4:
                data_map[rn] = (txt(row[0]), txt(row[1]), txt(row[2]) if len(row) > 2 else '', txt(row[3]))
        time.sleep(0.3)
    
    print(f"  读取 {len(data_map)} 行")
    
    # Find fixes
    to_fix = {}
    for row_num, (make, model, cur_trim, year) in data_map.items():
        if not make or not model: continue
        ml = model.lower().strip()
        kl = make.lower().strip()
        
        for fix_make, fix_model, fix_trim, new_model, trim_display in FIX:
            if kl != fix_make: continue
            if fix_model not in ml: continue
            
            # Check if the trim word is in the model (after the base model)
            rest = ml.replace(fix_model, '', 1).strip(' -')
            if fix_trim in rest or rest in fix_trim:
                # Check if trim column already has this
                if not cur_trim or cur_trim.lower() != trim_display.lower():
                    # Determine final model name - preserve powertrain suffix
                    final_model = new_model
                    rest_upper = rest.upper()
                    if 'HYBRID' in rest_upper and 'HYBRID' not in final_model.upper():
                        # Hybrid stays in model name
                        final_model = new_model + ' Hybrid'
                    elif 'EV' in rest_upper and 'EV' not in final_model.upper():
                        # Check if EV is actually part of the model
                        ev_words = re.findall(r'\bEV\b', rest_upper)
                        if ev_words:
                            final_model = new_model + ' EV'
                    
                    to_fix[row_num] = (final_model, trim_display)
                    break
    
    # Summary
    fix_summary = Counter()
    for _, (nm, nt) in to_fix.items():
        fix_summary[f'{nm} → {nt}'] += 1
    
    print(f"\n🔍 发现 {len(to_fix)} 条需要修复")
    print(f"\n=== 修复明细 (Top 30) ===")
    for s, c in sorted(fix_summary.items(), key=lambda x: -x[1])[:30]:
        print(f'  {s:45s} × {c}')
    
    # Apply fixes
    if not to_fix:
        print("\n✅ 无需修复")
        return
    
    print(f"\n✍️ 写入 {len(to_fix)} 条到飞书...")
    items = sorted(to_fix.items())
    
    BATCH = 100
    for i in range(0, len(items), BATCH):
        batch = items[i:i+BATCH]
        for row_num, (new_model, new_trim) in batch:
            url = f'https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SPREADSHEET_TOKEN}/values'
            body = {'valueRange': {'range': f'{SHEET}!B{row_num}:C{row_num}', 'values': [[new_model, new_trim]]}}
            r = requests.put(url, headers={'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'},
                             json=body, timeout=15)
            if r.json().get('code') != 0:
                print(f'    ✗ 行{row_num}')
            time.sleep(0.08)
        print(f'  ✓ {min(i+BATCH, len(items))}/{len(to_fix)}')
    
    print(f"\n✅ 全部完成！修复 {len(to_fix)} 条")

if __name__ == '__main__':
    main()
