#!/bin/bash
# TuxMat 新品检查脚本
# 输出 JSON: {"has_new":true/false, "new_items":[...], "last_date":"...", "new_date":"..."}
# 更新 tuxmat_monitor_state.json

DIR="$(cd "$(dirname "$0")" && pwd)"
STATE_FILE="$DIR/tuxmat_monitor_state.json"

# 确保 state 文件存在
if [ ! -f "$STATE_FILE" ]; then
  echo '{"last_date":"2026-05-01","notified_at":null,"description":"last_date 记录已通知到的最后日期"}'
  echo '{"last_date":"2026-05-01","notified_at":null}' > "$STATE_FILE"
fi

# 获取最新数据
DATA=$(curl -s "https://dashboard.dmdmnow.com/new_products_data.js?_t=$(date +%s)")
JSON=$(echo "$DATA" | node -e "
let d = '';
process.stdin.on('data', c => d += c);
process.stdin.on('end', () => {
  const state = require('$STATE_FILE');
  const s = d.substring(d.indexOf('['), d.lastIndexOf(']')+1);
  const all = JSON.parse(s);
  const tuxmat = all.filter(p => p.b === 'TuxMat').sort((a,b) => a.d.localeCompare(b.d));
  const newItems = tuxmat.filter(p => p.d > state.last_date);
  const maxDate = tuxmat.length > 0 ? tuxmat.map(p=>p.d).sort().pop() : state.last_date;
  
  // Update state
  if (newItems.length > 0) {
    const maxNewDate = newItems.map(p=>p.d).sort().pop();
    state.last_date = maxNewDate;
    state.notified_at = new Date().toISOString();
    require('fs').writeFileSync('$STATE_FILE', JSON.stringify(state, null, 2));
  }
  
  console.log(JSON.stringify({ has_new: newItems.length > 0, count: newItems.length, new_items: newItems, last_date: state.last_date }));
});
")

echo "$JSON"
