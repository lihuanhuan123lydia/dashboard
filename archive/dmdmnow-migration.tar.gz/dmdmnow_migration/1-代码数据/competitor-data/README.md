# 竞品新品监控系统

## 品牌清单（2026-06-09）

| 品牌 | 是否扫描 | 是否有通知 | cron 时间 | 脚本 |
|------|----------|-----------|-----------|------|
| Lasfit | ✅ | ✅ | 每日 9:00 | `check_lasfit_new.sh` → `lasfit_notify.py` |
| TuxMat | ✅ | ✅ | 每日 9:05 | `check_tuxmat_new.sh` → `tuxmat_notify.py` |
| 3W | ✅ | ❌（自研品牌，无需通知） | — | — |
| Smartliner | ✅ | ❌ | — | — |

## 接入模板

新增监控品牌时，必须完成以下三件套：

### 1. 品牌配置
在 `competitor_monitor.py` 的 `SHOPIFY_BRANDS` 字典中添加域名。

### 2. 检查脚本
参考 `check_tuxmat_new.sh` 创建 `check_{brand}_new.sh`：
- 读 `new_products_data.js` 过滤该品牌
- 维护 `{brand}_monitor_state.json`（记录 `last_date`）
- 输出 JSON 到 `/tmp/{brand}_cron_result.json`

### 3. 通知脚本
参考 `tuxmat_notify.py` 创建 `{brand}_notify.py`：
- 读 `/tmp/{brand}_cron_result.json`
- 构建飞书消息卡片发送到群

### 4. crontab
在 crontab 添加：
```
{minute} {hour} * * * cd /path && bash check_{brand}_new.sh > /tmp/{brand}_cron_result.json 2>&1 && python3 {brand}_notify.py >> /tmp/{brand}_notify.log 2>&1
```

### 5. 更新 HEARTBEAT.md
在文件顶部记录品牌、cron 时间、通知目标群。
