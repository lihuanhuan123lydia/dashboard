#!/usr/bin/env python3
"""
Lasfit 新品通知脚本
- 读 check_lasfit_new.sh 产出的 /tmp/lasfit_cron_result.json
- 分类：脚垫类 vs 非脚垫
- 脚垫类 → 详细通知
- 非脚垫类 → 简单通知（品类 + 车型）
- 通过飞书 Bot API 发到「车型匹配&新品下单」群
"""
import json, os, sys, re, time, urllib.request, urllib.error

# ===== 配置 =====
GROUP_CHAT_ID = "oc_2afdd5b5db7e64c93b0066b85a87cc2a"
APP_ID = "cli_a95e614746395cbd"
APP_SECRET = "ZTPbyJlJNK0utcjkqgTazh8JDnLFhK4X"
RESULT_FILE = "/tmp/lasfit_cron_result.json"

# ===== 商品 URL 修复（数字ID -> handle） =====
HANDLE_CACHE_TTL = 6 * 3600  # 缓存 6 小时
_handle_cache = None
_handle_cache_ts = 0

def _fetch_products_json():
    """拉取 lasfit 产品列表（products.json 按创建时间倒序），建立 id -> handle 映射"""
    mapping = {}
    page_info = None
    # 拉取前 3 页（约 750 条），覆盖最新上架的产品
    for _ in range(3):
        url = "https://www.lasfit.com/products.json?limit=250"
        if page_info:
            url += "&page_info=" + page_info
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        props = json.loads(urllib.request.urlopen(req, timeout=20).read())
        prods = props.get("products", []) or []
        for p in prods:
            if p.get("id") and p.get("handle"):
                mapping[str(p["id"])] = p["handle"]
        page_info = props.get("page_info", "") or ""
        if not page_info:
            break
    return mapping

def get_handle_cache():
    global _handle_cache, _handle_cache_ts
    now = time.time()
    if _handle_cache is None or now - _handle_cache_ts > HANDLE_CACHE_TTL:
        try:
            _handle_cache = _fetch_products_json()
            _handle_cache_ts = now
        except Exception as e:
            print(f"⚠️ 拉取 handle 映射失败，使用原链接: {e}", file=sys.stderr)
            _handle_cache = _handle_cache or {}
            _handle_cache_ts = now
    return _handle_cache

def resolve_url(url):
    """把 /products/{数字ID}?variant=... 转成可访问的 handle 链接；失败则原样返回"""
    if not url:
        return url
    m = re.search(r'/products/(\d+)', url)
    if not m:
        return url
    pid = m.group(1)
    handle = get_handle_cache().get(pid)
    if not handle:
        return url
    # 保留原 URL 尾部参数（variant 等）
    qs = url.split('?', 1)[1] if '?' in url else ''
    new = f"https://www.lasfit.com/products/{handle}"
    if qs:
        new += "?" + qs
    return new

# ===== 品类分类 =====
FLOOR_MAT_KEYWORDS = [
    "floor mat", "floor-mat", "trunk mat", "cargo liner", "bed mat",
    "bed liner", "seat cover", "seat back", "cargo mat", "trunk liner",
    "all-weather mat", "tpe mat", "rubber mat", "carpet mat",
    "seat protector", "console cover", "dash mat", "sunshade"
]

# ===== 标题格式化 =====
PRODUCT_KEYWORDS = (r'floor|mats?\b|truck|bed|cargo|seat|seatback|trunk|liner|liners|cover|covers|'
                    r'tailgate|console|dash|sunshade|light|lights|led|headlight|headlights|bulb|bulbs|'
                    r'tray|pedal|pedals|step|steps|lift|running|mirror|mirrors|camera|'
                    r'sensor|tent|fridge|ramp|jack|protector|kit')
VEHICLE_RE = re.compile(
    r'(\d{4}[-–~]\d{4}|\d{4}\+?|\d{4})\s+'
    r'([A-Za-z][A-Za-z0-9\-]*(?:\s+[&A-Za-z0-9+\-\.\'"()/]+)*?)'
    r'(?=\s+(?:' + PRODUCT_KEYWORDS + r')\b)',
    re.I
)


def format_title(title):
    """把 Shopify 原标题转成「车型 | 配置」的完整展示格式
    例: Fit for 2021-2023 Ford F-150 & F-150 Lightning Truck Bed Mat or Tailgate Mat,
        Not Fit Drop-in Liners (5.5' / Bed & Tailgate Mat (not work surface))
    →   2021-2023 Ford F-150 & F-150 Lightning | 5.5' | Bed & Tailgate Mat
    """
    t = title.strip()
    if t.startswith("[") and t.endswith("]"):
        t = t[1:-1]
    t = re.sub(r'^fit\s*for\s*', '', t, flags=re.I).strip()

    # 1) 提取末尾括号作为配置信息（支持嵌套括号）
    config = ""
    m = re.search(r'\(([^()]*(?:\([^()]*\)[^()]*)*)\)\s*$', t)
    if m:
        config = m.group(1)
        t = t[:m.start()].strip()
    config = re.sub(r'\([^()]*\)', '', config).strip()  # 去掉嵌套注释如 (not work surface)
    if config.lower() in ("", "default title"):
        config = ""

    # 2) 提取车型（年份 + 品牌 + 车型，遇到产品关键词停止）
    m = VEHICLE_RE.search(t)
    vehicle = m.group(0).strip() if m else ""
    if not vehicle:
        # fallback: 主标题（括号前），去掉促销标记与 emoji，忽略配置信息
        main = re.split(r',\s*(?:not\s*fit|only\s*fit|don\'?t\s*fit|doesn\'?t\s*fit|fits?\s+only)',
                        t, flags=re.I, maxsplit=1)[0]
        main = re.sub(r'\(100%\s*off\)|🎁', '', main, flags=re.I)
        vehicle = re.sub(r'\s+', ' ', main).strip().rstrip(', ')[:70]
        config = ""

    # 3) 配置里「尺寸 / 类型」用 | 分隔（如 5.5' / Bed & Tailgate Mat）
    if config:
        segs = [s.strip() for s in re.split(r'/', config)]
        if len(segs) >= 2 and re.search(r'\d+(\.\d+)?[\'"]|ft\b|feet|inches', segs[0], re.I):
            config = " | ".join(segs)

    parts = [p for p in (vehicle, config) if p]
    return " | ".join(parts) if parts else title

def classify_item(title):
    tl = title.lower()
    for kw in FLOOR_MAT_KEYWORDS:
        if kw in tl:
            return "脚垫"
    return "非脚垫"

def extract_category(title):
    """从标题推断产品品类"""
    tl = title.lower()
    if any(k in tl for k in ["led", "bulb", "lighting", "light"]):
        return "LED 车灯/灯泡"
    if "bulb" in tl:
        return "车灯灯泡"
    return "汽车配件"

def extract_vehicle(title):
    """从标题提取车型信息（年份 + 品牌 + 车型）"""
    t = re.sub(r'^fit\s*for\s*', '', title, flags=re.I)
    m = VEHICLE_RE.search(t)
    if m:
        return m.group(0).strip()
    # 兜底：简单提取首段
    parts = t.split(" The ")[0].split(" (")[0]
    if parts and len(parts) > 5:
        return parts
    return ""

def get_tenant_token():
    """获取飞书 tenant_access_token"""
    url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
    data = json.dumps({
        "app_id": APP_ID,
        "app_secret": APP_SECRET
    }).encode()
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    resp = urllib.request.urlopen(req)
    result = json.loads(resp.read())
    if "tenant_access_token" not in result:
        print(f"❌ 获取 token 失败: {result}", file=sys.stderr)
        sys.exit(1)
    return result["tenant_access_token"]

def send_feishu_msg(token, content_json):
    """发送消息到群"""
    url = f"https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=chat_id"
    data = json.dumps({
        "receive_id": GROUP_CHAT_ID,
        "msg_type": "interactive",
        "content": json.dumps(content_json, ensure_ascii=False)
    }).encode()
    req = urllib.request.Request(url, data=data, headers={
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    })
    try:
        resp = urllib.request.urlopen(req)
        result = json.loads(resp.read())
        if result.get("code") != 0:
            print(f"❌ 发送失败: {result}", file=sys.stderr)
            return False
        return True
    except urllib.error.HTTPError as e:
        print(f"❌ HTTP 错误: {e.code} {e.read().decode()}", file=sys.stderr)
        return False

def build_card(new_items):
    """构建飞书消息卡片"""
    floor_mat_items = []
    other_items = []
    
    for item in new_items:
        title = item.get("t", "")
        if classify_item(title) == "脚垫":
            floor_mat_items.append(item)
        else:
            other_items.append(item)
    
    elements = []
    
    # 使用实际产品的上架日期范围
    dates = sorted(set(i.get("d","") for i in new_items if i.get("d")))
    date_range = f"{dates[0]} ~ {dates[-1]}" if len(dates) >= 2 else (dates[0] if len(dates) == 1 else time.strftime("%m/%d"))
    elements.append({"tag": "markdown", "content": f"**📅 {date_range} | Lasfit 新品**"})
    
    if floor_mat_items:
        lines = []
        for item in floor_mat_items:
            title = item.get("t","")
            price = item.get("p","")
            url = item.get("u","")
            short = format_title(title)
            d = item.get("d", "")
            url = resolve_url(url)
            lines.append(f"• [{short}]({url})  {f'${price:.2f}' if price else ''}  | {d}")
        elements.append({"tag": "markdown", "content": f"**🚗 脚垫类新品 ({len(floor_mat_items)})**\n" + '\n'.join(lines)})
    
    if other_items:
        lines = []
        for item in other_items:
            title = item.get("t","")
            price = item.get("p","")
            url = item.get("u","")
            category = extract_category(title)
            vehicle = extract_vehicle(title)
            # 非脚垫类：展示完整格式化标题，前 60 字控制长度
            display = format_title(title)
            if len(display) > 60:
                display = display[:60].rstrip() + "…"
            price_str = f"${price:.2f}" if price else ""
            d = item.get("d", "")
            url = resolve_url(url)
            if display:
                lines.append(f"• [{display}]({url})  {price_str}  | {d}")
            elif vehicle:
                lines.append(f"• {category} | {vehicle} | {price_str}  | {d}")
            else:
                lines.append(f"• {category} | {price_str}  | {d}")
        elements.append({"tag": "markdown", "content": f"**🔌 其他品类新品 ({len(other_items)})**\n" + '\n'.join(lines)})
    
    elements.append({"tag": "hr"})
    elements.append({"tag": "note", "element": {"tag": "plain_text", "content": f"共 {len(new_items)} 条新品 · 每日 9:00 自动检测"}})
    
    return {
        "config": {"wide_screen_mode": True},
        "header": {"title": {"tag": "plain_text", "content": "🆕 Lasfit 新品上架"}, "template": "blue"},
        "elements": elements
    }

def main():
    # 读取结果文件
    if not os.path.exists(RESULT_FILE):
        print(f"❌ 结果文件不存在: {RESULT_FILE}", file=sys.stderr)
        sys.exit(1)
    
    with open(RESULT_FILE) as f:
        data = json.load(f)
    
    if not data.get("has_new"):
        print("ℹ️ 无新品，跳过通知")
        return
    
    new_items = data.get("new_items", [])
    if not new_items:
        print("ℹ️ 新品列表为空，跳过通知")
        return
    
    print(f"ℹ️ 发现 {len(new_items)} 条新品")
    for item in new_items:
        classification = classify_item(item.get("t", ""))
        print(f"   [{classification}] {item.get('t', '')[:60]}")
    
    # 获取 token 并发送
    token = get_tenant_token()
    card = build_card(new_items)
    success = send_feishu_msg(token, card)
    
    if success:
        print("✅ 通知已发送到群")
    else:
        print("❌ 通知发送失败", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
