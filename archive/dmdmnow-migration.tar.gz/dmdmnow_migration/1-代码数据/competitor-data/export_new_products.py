#!/usr/bin/env python3
"""Export new products from SQLite to JS for dashboard - tracking from 2026-01-01 to latest month"""
import sqlite3, json
from datetime import datetime
from pathlib import Path

DB_PATH = Path(__file__).parent / "competitor_monitor.db"
JS_OUT = Path(__file__).parent / "new_products_data.js"

SHOPIFY_BRANDS = {"3W": "3wliners.com", "Lasfit": "lasfit.com", "TuxMat": "tuxmat.com"}

conn = sqlite3.connect(str(DB_PATH))
c = conn.cursor()

# 跟踪记录数据：从 2026 年 1 月起持续到最新月份（全部品牌）
cutoff = '2026-01-01'

rows = []
for brand_name in ['3W', 'TuxMat', 'Lasfit']:
    c.execute('''
        SELECT brand, product_title, variant_title, price, variant_created_at, 
               variant_id, product_id, sku, product_type
        FROM variants 
        WHERE brand=? AND variant_created_at >= ?
        ORDER BY variant_created_at DESC
    ''', (brand_name, cutoff))
    rows.extend(c.fetchall())

conn.close()

products = []
seen = set()
for r in rows:
    brand = r[0]
    pt = r[1]
    vt = r[2]
    
    if brand in ['TuxMat']:
        pass  # TuxMat only sells floor mats, include all
    else:
        keywords = ['floor', 'mat', 'liner', 'cargo', 'trunk', 'bed', 'seat', 'tpe']
        if not any(k in pt.lower() or k in vt.lower() for k in keywords):
            continue
    
    key = f"{brand}|{pt}|{vt}"
    if key in seen:
        continue
    seen.add(key)
    
    url = f"https://{SHOPIFY_BRANDS.get(brand, '')}/products/{r[6]}?variant={r[5]}" if brand in SHOPIFY_BRANDS else ''
    
    products.append({
        "b": brand,
        "t": f"{pt} ({vt})" if vt else pt,
        "p": r[3],
        "d": r[4][:10] if r[4] else '',
        "u": url,
    })

js = f"// Auto-generated {datetime.now().isoformat()}\nvar NEW_PRODUCTS = {json.dumps(products, ensure_ascii=False, indent=1)};\n"
JS_OUT.write_text(js)
print(f"Exported {len(products)} recent products (since {cutoff}) to {JS_OUT.name}")
