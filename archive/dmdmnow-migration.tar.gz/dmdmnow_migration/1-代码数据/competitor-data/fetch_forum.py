#!/usr/bin/env python3
"""
论坛 & 电商活跃度爬虫 (v2 - 实用版)
数据源:
  1) Amazon 产品数量 (搜索 {model} floor mats) — 衡量后市场购买意愿
  2) 垂直论坛爬虫 (F150gen14, TacomaWorld, Bronco6G 等) — 专注讨论热度
  3) Google 搜索结果数 (site:reddit.com {model}) — 替代 Reddit API

输出: forum_data.json
"""

import json
import os
import sys
import time
import re
import requests
from datetime import datetime
from lxml import html

DATA_DIR = os.path.dirname(os.path.abspath(__file__))
US_SALES_PATH = os.path.join(DATA_DIR, "us_sales_data.json")
FORUM_OUTPUT = os.path.join(DATA_DIR, "forum_data.json")

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Accept-Language": "en-US,en;q=0.9",
}


def load_sales_data():
    with open(US_SALES_PATH) as f:
        data = json.load(f)
    return [s["model"] for s in data.get("sales", [])]


def amazon_product_count(model):
    """
    爬 Amazon 搜索 {model} floor mats 的结果数
    返回: (product_count, avg_rating, has_results)
    """
    try:
        query = f"{model} floor mats".replace(" ", "+")
        url = f"https://www.amazon.com/s?k={query}"
        resp = requests.get(url, timeout=15, headers=HEADERS)
        if resp.status_code == 200:
            # 尝试提取结果数
            count_match = re.search(r'([\d,]+)\s*(?:results|result)', resp.text[:10000])
            count = int(count_match.group(1).replace(",", "")) if count_match else 0
            # 取上限，Amazon 最多显示 ~400
            count = min(count, 400)
            # 检查是否有商品（没有则 count=0）
            has_items = 'data-asin' in resp.text[:20000]
            if not has_items and count == 0:
                return 0, 0, False
            return count, 0, has_items
        return 0, 0, False
    except Exception as e:
        print(f"    ⚠ Amazon: {e}")
        return 0, 0, False


# 垂直论坛配置
VERTICAL_FORUMS = [
    {
        "name": "F150gen14",
        "url": "https://www.f150gen14.com/forum/search/{query}/?t=post&o=date",
        "models": ["F-150", "F-Series", "Ford F"],
        "parser": "generic",
    },
    {
        "name": "TacomaWorld",
        "url": "https://www.tacomaworld.com/search/{query}/",
        "models": ["Tacoma", "Tundra"],
        "parser": "generic",
    },
    {
        "name": "Bronco6G",
        "url": "https://www.bronco6g.com/forum/search/{query}/",
        "models": ["Bronco", "Ford Bronco"],
        "parser": "generic",
    },
    {
        "name": "MaverickTruckClub",
        "url": "https://www.mavericktruckclub.com/forum/search/{query}/",
        "models": ["Maverick", "Ford Maverick"],
        "parser": "generic",
    },
    {
        "name": "4RunnerForum",
        "url": "https://www.4runners.com/search?q={query}",
        "models": ["4Runner", "Toyota 4Runner"],
        "parser": "generic",
    },
    {
        "name": "WagoneerForums",
        "url": "https://wagoneerforums.org/search?q={query}",
        "models": ["Grand Wagoneer", "Wagoneer"],
        "parser": "generic",
    },
]

# Reddit 公共子版块（通过 Google site: 查询替代直接 API 调用）
REDDIT_SUBS = ["cars", "askcarsales", "cartalk", "whatcarshouldIbuy", "auto"]


def count_google_mentions(model, site=None):
    """
    通过 Google 估算某个模型在 Reddit / 全网的热度
    使用 HTML 解析（免费，无需 API Key）
    返回: 估算结果数
    """
    try:
        if site:
            query = f"site:{site} \"{model}\""
        else:
            query = f"\"{model}\" accessories OR \"floor mats\" OR \"cargo liner\""

        url = f"https://www.google.com/search?q={requests.utils.quote(query)}&hl=en"
        resp = requests.get(url, timeout=15, headers=HEADERS)
        if resp.status_code == 200:
            # 提取结果数
            text = resp.text[:30000]
            patterns = [
                r'About ([\d,]+) results',
                r'of approximately ([\d,]+) results',
                r'resultStats["\']\s*[:=]\s*["\']([\d,]+)',
                r'aria-label="[^"]*([\d,]+)\s*results[^"]*"',
            ]
            for p in patterns:
                m = re.search(p, text)
                if m:
                    count = int(m.group(1).replace(",", ""))
                    return min(count, 1000)
            # 未找到精确计数，估算
            mentions = text.lower().count(model.lower().split(" ")[0])
            return min(mentions, 200)
        return 0
    except Exception:
        return 0


def scrape_forum(model, forum):
    """爬取单个垂直论坛"""
    try:
        query = model.replace(" ", "+")
        url = forum["url"].replace("{query}", query)
        resp = requests.get(url, timeout=15, headers=HEADERS)
        if resp.status_code == 200:
            tree = html.fromstring(resp.content)
            text = resp.text
            # 统计提及次数
            first_word = model.split(" ")[0]
            mentions = len(re.findall(re.escape(first_word), text, re.IGNORECASE))
            mentions = min(mentions, 200)
            return {"status": "ok", "mentions": mentions, "url_ok": True}
        return {"status": f"HTTP {resp.status_code}", "mentions": 0, "url_ok": False}
    except Exception as e:
        return {"status": f"error: {e}", "mentions": 0, "url_ok": False}


def main():
    print(f"🚀 论坛/电商爬虫启动 — {datetime.now().isoformat()}")
    print("-" * 60)

    models = load_sales_data()
    print(f"📦 加载 {len(models)} 个车型")

    output = {}
    for i, model in enumerate(models):
        print(f"\n[{i + 1}/{len(models)}] {model}")

        # === Amazon 产品数 ===
        amz_count, _, _ = amazon_product_count(model)
        print(f"   🛒 Amazon '{model} floor mats': {amz_count}+ 商品")

        # === Google 搜索热度 ===
        web_mentions = count_google_mentions(model)
        reddit_mentions = count_google_mentions(model, site="reddit.com")
        print(f"   🔍 Google: {web_mentions} web mentions, {reddit_mentions} Reddit mentions")

        # === 垂直论坛 ===
        forum_results = {}
        total_forum_mentions = 0
        for forum in VERTICAL_FORUMS:
            if any(filt.lower() in model.lower() for filt in forum["models"]):
                result = scrape_forum(model, forum)
                forum_results[forum["name"]] = result
                total_forum_mentions += result.get("mentions", 0)
                status_icon = "✓" if result.get("url_ok") else "✗"
                print(f"   📄 {forum['name']}: {status_icon} ({result.get('mentions', 0)} mentions)")

        output[model] = {
            "amazon_product_count": amz_count,
            "web_mentions": web_mentions,
            "reddit_mentions": reddit_mentions,
            "forum_mentions": total_forum_mentions,
            "forum_details": forum_results,
            "raw_activity_score": amz_count + web_mentions + total_forum_mentions,
        }

        # 每 10 个模型保存中间结果
        if (i + 1) % 10 == 0:
            partial = {
                "source": "Amazon + Google + Vertical Forums",
                "scraped_at": datetime.now().isoformat(),
                "total_models": len(output),
                "in_progress": True,
                "activity": dict(output),
            }
            with open(FORUM_OUTPUT + ".partial", "w") as f:
                json.dump(partial, f, ensure_ascii=False, indent=2)
            print(f"\n   📝 中间保存 ({i + 1}/{len(models)})")

        # Google 查询间隔
        time.sleep(2)

    # 计算活跃度变化率（与均值对比）
    values = [output[m].get("raw_activity_score", 0) for m in output]
    avg_score = sum(values) / len(values) if values else 1
    for model in output:
        score = output[model]["raw_activity_score"]
        if avg_score > 0:
            output[model]["activity_score_pct"] = round((score / avg_score - 1) * 100, 2)
        else:
            output[model]["activity_score_pct"] = 0

    # 保存最终结果
    final = {
        "source": "Amazon + Google + Vertical Forums",
        "scraped_at": datetime.now().isoformat(),
        "total_models": len(output),
        "activity": output,
    }
    with open(FORUM_OUTPUT, "w") as f:
        json.dump(final, f, ensure_ascii=False, indent=2)
    print(f"\n✅ 写入 {FORUM_OUTPUT}")

    # Top 10
    sorted_active = sorted(
        [m for m in output if output[m].get("raw_activity_score", 0) > 0],
        key=lambda m: output[m].get("activity_score_pct", 0),
        reverse=True,
    )
    print(f"\n🔥 后市场活跃度上升 Top 10:")
    for m in sorted_active[:10]:
        d = output[m]
        print(f"   {m:35s} Amazon={d['amazon_product_count']:>3}  Web={d['web_mentions']:>4}  Forum={d['forum_mentions']:>3}  Score={d['activity_score_pct']:>+8.2f}%")


if __name__ == "__main__":
    main()
