#!/usr/bin/env python3
"""标准化学员：提取销售版本 + 归一化品牌/车型/年份 → 写回飞书"""
import requests, json, re, time
from collections import defaultdict

APP_ID = "cli_a95e614746395cbd"
APP_SECRET = "ZTPbyJlJNK0utcjkqgTazh8JDnLFhK4X"
SP = "NV6Gsl1lwhBw7RtYPTAcpQQenjq"
SUB_SHEET = "1sCyzd"  # 站内-客户提交 车型 年份 备注
MAIN_SHEET = "0iCDMN"  # 站内-车型提交人数

def get_token():
    r = requests.post("https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
        json={"app_id": APP_ID, "app_secret": APP_SECRET}, timeout=10)
    return r.json()["tenant_access_token"]

def safe(v):
    if v is None: return ""
    return str(v).strip()

# === READ SUBMISSIONS ===
print("Reading submissions...")
token = get_token()
r = requests.get(f"https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SP}/values/{SUB_SHEET}!A:I",
    headers={"Authorization": f"Bearer {token}"}, timeout=120)
d = r.json()
rows = d["data"]["valueRange"]["values"]
print(f"  {len(rows)} rows")

# === TRIM EXTRACTION + MODEL NORMALIZATION ===

# Known trims by brand (word-boundary matching)
TRIM_MAP = {
    "Ford": ["XLT","XL","XLS","LARIAT","PLATINUM","KING RANCH","LIMITED","TREMOR","RAPTOR","STX","FX4"],
    "Chevrolet": ["LTZ","LT","LS","Z71","ZR2","RST","HIGH COUNTRY","PREMIER","TRAIL BOSS","CUSTOM","WT","RS","SS"],
    "GMC": ["DENALI","AT4","AT4X","ELEVATION","SLT","SLE","PRO"],
    "Toyota": ["SR5","TRD PRO","TRD","XLE","XSE","SE","LE","CAPSTONE","NIGHTSHADE","PLATINUM","LIMITED"],
    "Honda": ["EX-L","EXL","EX","LX","TOURING","ELITE","SPORT","HYBRID"],
    "Nissan": ["SV","SL","S","PRO-4X","PRO 4X","PRO4X","PLATINUM","LE","SR"],
    "Hyundai": ["SEL","SE","LIMITED","NIGHT","HYBRID","N Line"],
    "Kia": ["EX","S","LX","GT Line","GT"],
    "Ram": ["LARAMIE","LONE STAR","BIG HORN","REBEL","TRX","LONGHORN","TRADESMAN"],
    "Subaru": ["WILDERNESS","ONYX","PREMIUM","BASE","LIMITED","SPORT","TOURING"],
    "Volkswagen": ["GTI","GTE","R-LINE","R","TDI","SEL","SE","ALLTRACK","SPORTWAGEN"],
    "Dodge": ["GT","R/T","SLT","SXT","HELLCAT","SCAT PACK"],
    "Jeep": ["SAHARA","RUBICON","WILLYS","ALTITUDE","LATITUDE","LIMITED","TRAILHAWK","OVERLAND"],
    "BMW": ["xDrive","M SPORT","M"],
    "Mercedes-Benz": ["AMG","4MATIC"],
    "Audi": ["QUATTRO","S LINE","S","RS"],
    "Mazda": ["CARBON","TURBO","PREMIUM","PREFERRED","SELECT"],
    "Cadillac": ["SPORT","PREMIUM","LUXURY","V"],
    "Lincoln": ["RESERVE","PREMIUM","LUXURY","BLACK LABEL"],
    "Acura": ["A-SPEC","TYPE S","SH-AWD","TECHNOLOGY","ADVANCE"],
    "Lexus": ["LUXURY","PREMIUM","SPORT","F SPORT","EXECUTIVE"],
    "Chrysler": ["S","LIMITED","TOURING","LX"],
    "Infiniti": ["LUXURY","PURE","SENSORY","SPORT"],
    "Volvo": ["R-DESIGN","INSCRIPTION","MOMENTUM","POLESTAR","ULTIMATE","PLUS","CORE"],
    "Land Rover": ["SE","HSE","AUTOBIOGRAPHY","FIRST EDITION","S"],
}

# Make aliases
MAKE_ALIASES = {
    "FORD":"Ford","CHEVROLET":"Chevrolet","CHEVY":"Chevrolet","TOYOTA":"Toyota",
    "GMC":"GMC","HONDA":"Honda","DODGE":"Dodge","NISSAN":"Nissan","KIA":"Kia",
    "HYUNDAI":"Hyundai","JEEP":"Jeep","SUBARU":"Subaru","VOLKSWAGEN":"Volkswagen",
    "VW":"Volkswagen","MAZDA":"Mazda","BUICK":"Buick","BMW":"BMW",
    "MERCEDES-BENZ":"Mercedes-Benz","MERCEDES":"Mercedes-Benz","AUDI":"Audi",
    "LEXUS":"Lexus","CADILLAC":"Cadillac","LINCOLN":"Lincoln","RAM":"Ram",
    "CHRYSLER":"Chrysler","ACURA":"Acura","INFINITI":"Infiniti","VOLVO":"Volvo",
    "TESLA":"Tesla","RIVIAN":"Rivian","MITSUBISHI":"Mitsubishi","SCION":"Scion",
    "MINI":"Mini","PORSCHE":"Porsche","LAND ROVER":"Land Rover","JAGUAR":"Jaguar",
    "FIAT":"Fiat","GENESIS":"Genesis","PONTIAC":"Pontiac","SATURN":"Saturn",
    "ISUZU":"Isuzu","SUZUKI":"Suzuki","HUMMER":"Hummer","MERCURY":"Mercury",
}

def normalize_make(m):
    m = m.strip().upper()
    for k, v in MAKE_ALIASES.items():
        if m == k or m == k.upper():
            return v
    return m.title()

# Comprehensive model normalization regex list
MODEL_RULES = [
    # Ford
    (r'\bF[- ]?150\b', 'F-150'), (r'\bF[- ]?250\b', 'F-250'), (r'\bF[- ]?350\b', 'F-350'),
    (r'\bF[- ]?450\b', 'F-450'), (r'\bF[- ]?550\b', 'F-550'),
    (r'\bEXPEDITION\b', 'Expedition'), (r'\bEXPLORER\b', 'Explorer'),
    (r'\bESCAPE\b', 'Escape'), (r'\bEDGE\b', 'Edge'),
    (r'\bBRONCO\b', 'Bronco'), (r'\bRANGER\b', 'Ranger'),
    (r'\bMAVERICK\b', 'Maverick'), (r'\bMUSTANG\b', 'Mustang'),
    (r'\bFOCUS\b', 'Focus'), (r'\bFUSION\b', 'Fusion'),
    (r'\bTAURUS\b', 'Taurus'), (r'\bTRANSIT\b', 'Transit'),
    (r'\bFLEX\b', 'Flex'), (r'\bC-MAX\b', 'C-Max'),
    (r'\bE[- ]?SERIES\b', 'E-Series'), (r'\bE[- ]?150\b', 'E-150'),
    (r'\bE[- ]?250\b', 'E-250'), (r'\bE[- ]?350\b', 'E-350'),
    (r'\bEXCURSION\b', 'Excursion'),
    
    # Chevy
    (r'\bSILVERADO\s*(1500)?\b', 'Silverado 1500'),
    (r'\bSILVERADO\s*2500\s*HD\b', 'Silverado 2500HD'),
    (r'\bSILVERADO\s*2500\b', 'Silverado 2500HD'),
    (r'\bSILVERADO\s*3500\s*HD\b', 'Silverado 3500HD'),
    (r'\bSILVERADO\s*3500\b', 'Silverado 3500HD'),
    (r'\bTAHOE\b', 'Tahoe'), (r'\bSUBURBAN\b', 'Suburban'),
    (r'\bEQUINOX\b', 'Equinox'), (r'\bTRAVERSE\b', 'Traverse'),
    (r'\bTRAIL[B]?LAZER\b', 'Trailblazer'), (r'\bTRAX\b', 'Trax'),
    (r'\bMALIBU\b', 'Malibu'), (r'\bBLAZER\b', 'Blazer'),
    (r'\bCORVETTE\b', 'Corvette'), (r'\bCAMARO\b', 'Camaro'),
    (r'\bCRUZE\b', 'Cruze'), (r'\bIMPALA\b', 'Impala'),
    (r'\bSPARK\b', 'Spark'), (r'\bSONIC\b', 'Sonic'),
    (r'\bEXPRESS\b', 'Express'), (r'\bCOLORADO\b', 'Colorado'),
    (r'\bAVALANCHE\b', 'Avalanche'), (r'\bHHR\b', 'HHR'),
    (r'\bCAPTIVA\b', 'Captiva'), (r'\bCOBALT\b', 'Cobalt'),
    
    # GMC
    (r'\bSIERRA\s*(1500)?\b', 'Sierra 1500'),
    (r'\bSIERRA\s*2500\s*HD\b', 'Sierra 2500HD'),
    (r'\bSIERRA\s*2500\b', 'Sierra 2500HD'),
    (r'\bSIERRA\s*3500\s*HD\b', 'Sierra 3500HD'),
    (r'\bSIERRA\s*3500\b', 'Sierra 3500HD'),
    (r'\bYUKON\b', 'Yukon'), (r'\bACADIA\b', 'Acadia'),
    (r'\bTERRAIN\b', 'Terrain'), (r'\bCANYON\b', 'Canyon'),
    (r'\bSAVANA\b', 'Savana'),
    
    # Toyota
    (r'\bTACOMA\b', 'Tacoma'), (r'\bTUNDRA\b', 'Tundra'),
    (r'\b4[- ]?RUNNER\b', '4Runner'), (r'\b4RUNNER\b', '4Runner'),
    (r'\bHIGHLANDER\b', 'Highlander'), (r'\bRAV4\b', 'RAV4'),
    (r'\bCAMRY\b', 'Camry'), (r'\bCOROLLA\b', 'Corolla'),
    (r'\bSEQUOIA\b', 'Sequoia'), (r'\bSIENNA\b', 'Sienna'),
    (r'\bAVALON\b', 'Avalon'), (r'\bVENZA\b', 'Venza'),
    (r'\bGRAND\s*HIGHLANDER\b', 'Grand Highlander'),
    (r'\bLAND\s*CRUISER\b', 'Land Cruiser'),
    (r'\bPRIUS\b', 'Prius'), (r'\bYARIS\b', 'Yaris'),
    (r'\bSUPRA\b', 'Supra'), (r'\bFJ\s*CRUISER\b', 'FJ Cruiser'),
    (r'\bMATRIX\b', 'Matrix'),
    
    # Ram
    (r'\bRAM\s*(1500)?\b', 'Ram 1500'),
    (r'\bRAM\s*2500\b', 'Ram 2500'), (r'\bRAM\s*3500\b', 'Ram 3500'),
    (r'\bRAM\s*4500\b', 'Ram 4500'), (r'\bRAM\s*5500\b', 'Ram 5500'),
    
    # Honda
    (r'\bCR[- ]?V\b', 'CR-V'), (r'\bCRV\b', 'CR-V'),
    (r'\bPILOT\b', 'Pilot'), (r'\bCIVIC\b', 'Civic'),
    (r'\bACCORD\b', 'Accord'), (r'\bODYSSEY\b', 'Odyssey'),
    (r'\bRIDGELINE\b', 'Ridgeline'), (r'\bPASSPORT\b', 'Passport'),
    (r'\bHR[- ]?V\b', 'HR-V'), (r'\bHRV\b', 'HR-V'),
    (r'\bFIT\b', 'Fit'), (r'\bELEMENT\b', 'Element'),
    
    # Nissan
    (r'\bROGUE\b', 'Rogue'), (r'\bALTIMA\b', 'Altima'),
    (r'\bFRONTIER\b', 'Frontier'), (r'\bTITAN\b', 'Titan'),
    (r'\bPATHFINDER\b', 'Pathfinder'), (r'\bARMADA\b', 'Armada'),
    (r'\bMURANO\b', 'Murano'), (r'\bSENTRA\b', 'Sentra'),
    (r'\bVERSA\b', 'Versa'), (r'\bCUBE\b', 'Cube'),
    (r'\bJUKE\b', 'Juke'), (r'\bKICKS\b', 'Kicks'),
    (r'\bMAXIMA\b', 'Maxima'), (r'\bXTERRA\b', 'Xterra'),
    (r'\bQUEST\b', 'Quest'),
    
    # Jeep
    (r'\bWRANGLER\b', 'Wrangler'), (r'\bGRAND\s*CHEROKEE\b', 'Grand Cherokee'),
    (r'\bCHEROKEE\b', 'Cherokee'), (r'\bCOMPASS\b', 'Compass'),
    (r'\bRENEGADE\b', 'Renegade'), (r'\bGLADIATOR\b', 'Gladiator'),
    (r'\bPATRIOT\b', 'Patriot'), (r'\bCOMMANDER\b', 'Commander'),
    (r'\bLIBERTY\b', 'Liberty'), (r'\bWAGONEER\b', 'Wagoneer'),
    
    # Hyundai/Kia
    (r'\bSANTA\s*FE\b', 'Santa Fe'), (r'\bTUCSON\b', 'Tucson'),
    (r'\bELANTRA\b', 'Elantra'), (r'\bSONATA\b', 'Sonata'),
    (r'\bPALISADE\b', 'Palisade'), (r'\bTELLURIDE\b', 'Telluride'),
    (r'\bSORENTO\b', 'Sorento'), (r'\bSPORTAGE\b', 'Sportage'),
    (r'\bSELTOS\b', 'Seltos'), (r'\bFORTE\b', 'Forte'),
    (r'\bK5\b', 'K5'), (r'\bOPTIMA\b', 'Optima'), (r'\bRIO\b', 'Rio'),
    (r'\bSOUL\b', 'Soul'), (r'\bCARNIVAL\b', 'Carnival'),
    (r'\bSEDONA\b', 'Sedona'), (r'\bNIRO\b', 'Niro'),
    (r'\bKONA\b', 'Kona'), (r'\bIONIQ\b', 'Ioniq'),
    (r'\bVENUE\b', 'Venue'), (r'\bVELOSTER\b', 'Veloster'),
    (r'\bAZERA\b', 'Azera'), (r'\bSTINGER\b', 'Stinger'),
    
    # Subaru
    (r'\bOUTBACK\b', 'Outback'), (r'\bFORESTER\b', 'Forester'),
    (r'\bCROSSTREK\b', 'Crosstrek'), (r'\bLEGACY\b', 'Legacy'),
    (r'\bIMPREZA\b', 'Impreza'), (r'\bASCENT\b', 'Ascent'),
    (r'\bWRX\b', 'WRX'), (r'\bBRZ\b', 'BRZ'),
    
    # Mazda
    (r'\bCX[- ]?5\b', 'CX-5'), (r'\bCX[- ]?9\b', 'CX-9'),
    (r'\bCX[- ]?3\b', 'CX-3'), (r'\bCX[- ]?30\b', 'CX-30'),
    (r'\bCX[- ]?50\b', 'CX-50'), (r'\bCX[- ]?70\b', 'CX-70'),
    (r'\bCX[- ]?90\b', 'CX-90'),
    (r'\bMAZDA3\b', 'Mazda3'), (r'\bMAZDA6\b', 'Mazda6'),
    (r'\bMX[- ]?5\b', 'MX-5 Miata'),
    
    # BMW
    (r'\bX1\b', 'X1'), (r'\bX3\b', 'X3'), (r'\bX5\b', 'X5'),
    (r'\bX6\b', 'X6'), (r'\bX7\b', 'X7'),
    (r'\b3[- ]?SERIES\b', '3 Series'), (r'\b5[- ]?SERIES\b', '5 Series'),
    (r'\b7[- ]?SERIES\b', '7 Series'),
    
    # Mercedes
    (r'\bGLC\b', 'GLC'), (r'\bGLE\b', 'GLE'), (r'\bGLS\b', 'GLS'),
    (r'\bC[- ]?CLASS\b', 'C-Class'), (r'\bE[- ]?CLASS\b', 'E-Class'),
    (r'\bS[- ]?CLASS\b', 'S-Class'), (r'\bSPRINTER\b', 'Sprinter'),
    
    # Audi
    (r'\bQ3\b', 'Q3'), (r'\bQ5\b', 'Q5'), (r'\bQ7\b', 'Q7'),
    (r'\bA3\b', 'A3'), (r'\bA4\b', 'A4'), (r'\bA5\b', 'A5'),
    (r'\bA6\b', 'A6'), (r'\bA7\b', 'A7'), (r'\bA8\b', 'A8'),
    
    # VW
    (r'\bJETTA\b', 'Jetta'), (r'\bPASSAT\b', 'Passat'),
    (r'\bTIGUAN\b', 'Tiguan'), (r'\bATLAS\b', 'Atlas'),
    (r'\bGOLF\b', 'Golf'), (r'\bTOUAREG\b', 'Touareg'),
    (r'\bBEETLE\b', 'Beetle'), (r'\bID\.?4\b', 'ID.4'),
    
    # Others
    (r'\bMODEL\s*3\b', 'Model 3'), (r'\bMODEL\s*S\b', 'Model S'),
    (r'\bMODEL\s*X\b', 'Model X'), (r'\bMODEL\s*Y\b', 'Model Y'),
    (r'\bCYBERTRUCK\b', 'Cybertruck'),
    (r'\bMDX\b', 'MDX'), (r'\bRDX\b', 'RDX'), (r'\bTLX\b', 'TLX'),
    (r'\bESCALADE\b', 'Escalade'), (r'\bXT4\b', 'XT4'),
    (r'\bXT5\b', 'XT5'), (r'\bXT6\b', 'XT6'),
    (r'\bNAVIGATOR\b', 'Navigator'), (r'\bAVIATOR\b', 'Aviator'),
    (r'\bXC90\b', 'XC90'), (r'\bXC60\b', 'XC60'), (r'\bXC40\b', 'XC40'),
    (r'\bRANGE\s*ROVER\s*SPORT\b', 'Range Rover Sport'),
    (r'\bRANGE\s*ROVER\b', 'Range Rover'),
    (r'\bDEFENDER\b', 'Defender'), (r'\bDISCOVERY\b', 'Discovery'),
    (r'\bQX60\b', 'QX60'), (r'\bQX80\b', 'QX80'), (r'\bQX50\b', 'QX50'),
    (r'\bRX[- ]?\d{3}\b', 'RX'), (r'\bNX[- ]?\d{3}\b', 'NX'),
    (r'\bES[- ]?\d{3}\b', 'ES'), (r'\bGX[- ]?\d{3}\b', 'GX'),
    (r'\bLX[- ]?\d{3}\b', 'LX'),
    (r'\bR1S\b', 'R1S'), (r'\bR1T\b', 'R1T'),
    (r'\bDURANGO\b', 'Durango'),
    (r'\bGRAND\s*CARAVAN\b', 'Grand Caravan'),
    (r'\bCHARGER\b', 'Charger'), (r'\bCHALLENGER\b', 'Challenger'),
    (r'\bPACIFICA\b', 'Pacifica'), (r'\b300\b', '300'),
    (r'\bENCLAVE\b', 'Enclave'), (r'\bENVISION\b', 'Envision'),
    (r'\bLACROSSE\b', 'LaCrosse'), (r'\bREGAL\b', 'Regal'),
    (r'\bOUTLANDER\b', 'Outlander'),
    (r'\bPROLOGUE\b', 'Prologue'),
]

# Dealer cab/body config patterns that should be kept as trim info
TRIM_AS_MODEL = {
    'CREW CAB', 'CREW CAB', 'QUAD CAB', 'REGULAR CAB', 'EXTENDED CAB',
    'DOUBLE CAB', 'CREWMAX', 'SUPER CAB', 'CREW CAB',
    'SHORT BED', 'LONG BED', 'STANDARD BED',
}
CAB_PATTERNS = {
    r'\bCREW\s*CAB\b': 'Crew Cab', r'\bQUAD\s*CAB\b': 'Quad Cab',
    r'\bREGULAR\s*CAB\b': 'Regular Cab', r'\bEXTENDED\s*CAB\b': 'Extended Cab',
    r'\bDOUBLE\s*CAB\b': 'Double Cab', r'\bCREWMAX\b': 'CrewMax',
    r'\bSUPER\s*CAB\b': 'Super Cab',
    r'\bSHORT\s*BED\b': 'Short Bed', r'\bLONG\s*BED\b': 'Long Bed',
    r'\bSTANDARD\s*BED\b': 'Standard Bed',
}

def extract_trim_and_model(model_raw, make_std):
    """Extract trim info from model name. Returns (clean_model, trim_list)"""
    m = model_raw.strip()
    if not m:
        return "", []
    
    m_upper = m.upper()
    trims_found = []
    
    # First, handle cab/body patterns as separate trim info
    cab_info = []
    for pat, label in CAB_PATTERNS.items():
        matches = list(re.finditer(pat, m_upper))
        for match in matches:
            cab_info.append(label)
        m_upper = re.sub(pat, '', m_upper)
    
    # Also remove from original for regression
    for pat, label in CAB_PATTERNS.items():
        m = re.sub(pat, '', m, flags=re.IGNORECASE)
    
    # Apply model normalization rules
    for pat, repl in MODEL_RULES:
        if re.search(pat, m_upper):
            m = re.sub(pat, repl, m, flags=re.IGNORECASE)
            m_upper = m.upper()
    
    # Extract known trims by brand
    brand_trims = TRIM_MAP.get(make_std, [])
    for trim in brand_trims:
        # Word-boundary match for multi-word trims first
        trim_up = trim.upper()
        if ' ' in trim_up:
            if trim_up in m_upper:
                trims_found.append(trim)
                m_upper = m_upper.replace(trim_up, '')
                m = re.sub(re.escape(trim), '', m, flags=re.IGNORECASE)
        else:
            pat = r'\b' + re.escape(trim_up) + r'\b'
            if re.search(pat, m_upper):
                trims_found.append(trim)
                m_upper = re.sub(pat, '', m_upper)
                m = re.sub(r'\b' + re.escape(trim) + r'\b', '', m, flags=re.IGNORECASE)
    
    # Also catch general trim keywords
    for general_trim in ['AWD','4WD','4X4','FWD','4x4','4×4']:
        pat = r'\b' + re.escape(general_trim.upper()) + r'\b'
        if re.search(pat, m_upper) and general_trim not in trims_found:
            trims_found.append(general_trim)
            m_upper = re.sub(pat, '', m_upper)
            m = re.sub(r'\b' + re.escape(general_trim) + r'\b', '', m, flags=re.IGNORECASE)
    
    # Clean up residuals
    m = re.sub(r'\s+', ' ', m).strip()
    m = re.sub(r'\s*-\s*', '-', m)
    m = re.sub(r'[^a-zA-Z0-9\-\s\.]', '', m)  # remove special chars
    m = re.sub(r'\s+', ' ', m).strip()
    
    # If model got cleaned to nothing, keep original model only (standardize as-is)
    if not m:
        m = model_raw.strip()
    
    all_trims = trims_found + cab_info
    return m, all_trims


# === PROCESS SUBMISSIONS ===
print("\nProcessing submissions...")
results = []
trim_stats = defaultdict(int)

for i, row in enumerate(rows[1:], 1):
    make_raw = safe(row[0]) if len(row) > 0 else ""
    model_raw = safe(row[1]) if len(row) > 1 else ""
    year_raw = safe(row[3]) if len(row) > 3 else ""  # Year is col D
    note = safe(row[4]) if len(row) > 4 else ""  # Note is col E
    
    # Years as 4-digit numbers only
    year = ""
    if year_raw:
        try:
            y = int(float(year_raw))
            if 1900 < y < 2030:
                year = str(y)
        except:
            pass
    
    make_std = normalize_make(make_raw)
    model_std, trims = extract_trim_and_model(model_raw, make_std)
    
    # Check note for trim info
    note_trims = []
    for brand_trims in TRIM_MAP.values():
        for trim in brand_trims:
            if trim.upper() in note.upper() and trim not in trims and trim not in note_trims:
                note_trims.append(trim)
    
    all_trims = list(dict.fromkeys(trims + note_trims))  # deduped, order preserved
    trim_str = " / ".join(all_trims)
    
    count_add = 1  # each row = 1 submission
    
    results.append({
        "make_std": make_std,
        "model_std": model_std,
        "year": year,
        "trim": trim_str,
        "note": note,
    })
    
    if trims or note_trims:
        trim_stats["has_trim"] += 1
    else:
        trim_stats["no_trim"] += 1
    
    if all_trims:
        for t in all_trims:
            trim_stats[t] += 1

print(f"  Processed {len(results)} submissions")
print(f"  With trim info: {trim_stats['has_trim']}")
print(f"  Without trim: {trim_stats['no_trim']}")

# === BUILD BATCHED WRITE BACK FOR SUBMISSIONS ===
# We need to write columns A (Make), B (Model), C (销售版本), D (Year)
print("\nWriting back to sheet...")

def write_range(token, sheet_id, range_str, values):
    """Write a range of values to the sheet"""
    url = f"https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SP}/values/{range_str}"
    payload = {
        "valueRange": {
            "range": f"{sheet_id}!{range_str}",
            "values": values
        }
    }
    r = requests.put(url, headers={
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }, json=payload, timeout=30)
    return r.json()

# Prepare columns as batch write
# Column A: Make
# Column B: Model  
# Column C: 销售版本
# Column D: Year

# Write column A & B together (2 cols, up to 5000 rows per batch)
BATCH_SIZE = 2000
for start in range(0, len(results), BATCH_SIZE):
    batch = results[start:start+BATCH_SIZE]
    row_start = start + 2  # +2 because row 1 is header
    row_end = row_start + len(batch) - 1
    
    # Write A+B columns
    ab_vals = [[r["make_std"], r["model_std"]] for r in batch]
    ab_range = f"A{row_start}:B{row_end}"
    token = get_token()
    resp = write_range(token, SUB_SHEET, ab_range, ab_vals)
    print(f"  A+B {row_start}-{row_end}: {resp.get('code')} {resp.get('msg','')}")
    
    # Write C column (销售版本)
    c_vals = [[r["trim"]] for r in batch]
    c_range = f"C{row_start}:C{row_end}"
    token = get_token()
    resp = write_range(token, SUB_SHEET, c_range, c_vals)
    print(f"  C {row_start}-{row_end}: {resp.get('code')} {resp.get('msg','')}")
    
    # Write D column (Year)
    d_vals = [[r["year"]] for r in batch]
    d_range = f"D{row_start}:D{row_end}"
    token = get_token()
    resp = write_range(token, SUB_SHEET, d_range, d_vals)
    print(f"  D {row_start}-{row_end}: {resp.get('code')} {resp.get('msg','')}")
    
    if (start + BATCH_SIZE) % 6000 == 0:
        print(f"  Progress: {start + BATCH_SIZE}/{len(results)}")
    time.sleep(0.5)

print("✅ Submissions sheet updated!")

# === NOW PROCESS MAIN SHEET (站内-车型提交人数) ===
print("\n=== Processing main sheet ===")
token = get_token()
r = requests.get(f"https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SP}/values/{MAIN_SHEET}!A:G",
    headers={"Authorization": f"Bearer {token}"}, timeout=30)
d = r.json()
main_rows = d["data"]["valueRange"]["values"]
print(f"  {len(main_rows)} rows")

# Aggregate by standardized make+model  
from collections import Counter
agg = defaultdict(lambda: {"makes": set(), "models": set(), "dev_status": "", "notes": ""})

for row in main_rows[1:]:
    if len(row) < 2: continue
    make_raw = safe(row[0])
    model_raw = safe(row[1])
    if not make_raw or not model_raw: continue
    
    make_std = normalize_make(make_raw)
    model_std, _ = extract_trim_and_model(model_raw, make_std)
    
    key = f"{make_std}|{model_std}"
    agg[key]["makes"].add(make_raw)
    agg[key]["models"].add(model_raw)
    # Keep the first non-empty dev status
    if len(row) > 3 and row[3] and not agg[key]["dev_status"]:
        agg[key]["dev_status"] = safe(row[3])
    # Keep notes
    if len(row) > 4 and row[4]:
        agg[key]["notes"] = safe(row[4])

# Count from submissions (actual people count)
sub_count = Counter()
for r2 in results:
    key = f"{r2['make_std']}|{r2['model_std']}"
    sub_count[key] += 1

# Build output for main sheet
output_rows = [["Make", "Model", "提交人数", "是否开发", "备注"]]
for key, info in sorted(agg.items(), key=lambda x: -sub_count.get(x[0], 0)):
    make_std, model_std = key.split("|", 1)
    count = sub_count.get(key, 0)
    if count < 1: continue  # skip models with no submissions
    output_rows.append([make_std, model_std, count, info["dev_status"], info["notes"]])

print(f"  Standardized models: {len(output_rows)-1}")
print(f"  Total people: {sum(sub_count.values())}")

# Write back to main sheet
# First, write the new headers and data
token = get_token()
resp = write_range(token, MAIN_SHEET, f"A1:E{len(output_rows)}", output_rows)
print(f"  Write main sheet: {resp.get('code')} {resp.get('msg','')}")

# Then clear remaining rows (from row+1 to the end)
if len(output_rows) < len(main_rows):
    clear_start = len(output_rows) + 1
    clear_end = len(main_rows)
    # Write empty values to clear
    empty_rows = [["" for _ in range(5)] for _ in range(clear_start - 1, clear_end + 1)]
    token = get_token()
    # Write empty values
    write_range(token, MAIN_SHEET, f"A{clear_start}:E{clear_end}", empty_rows)
    print(f"  Cleared rows {clear_start}-{clear_end}")

print("\n✅ Complete!")
print(f"\nTrim usage stats (top 20):")
for t, c in sorted(trim_stats.items(), key=lambda x: -x[1])[:20]:
    if t != "has_trim" and t != "no_trim" and len(t) < 30:
        print(f"  {t}: {c}")
