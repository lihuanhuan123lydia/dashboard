#!/usr/bin/env python3
"""处理 SubmissionsExport_20 (WOLFBOX Help Us Support Your Ride, 147条新提交 + 1条产品创意)
1. 追加原始行到 源表-车型 (cJ2gXd)
2. 追加标准化行到 车型需求 (53652a)
3. 追加产品创意到 源表-产品 (11HTsJ) + 创意产品需求 (VeNjAU)
"""
import requests, json, re, sys, openpyxl
from datetime import datetime

APP_ID = 'cli_a95e614746395cbd'
APP_SECRET = 'ZTPbyJlJNK0utcjkqgTazh8JDnLFhK4X'
TOKEN = 'W8Dxsti3Vhvo2itAuYDcULXyneb'
EXCEL = '/home/ecs-user/.openclaw/media/inbound/SubmissionsExport_20---ac591426-8bdf-41c0-a9ec-02574d3aa518.xlsx'

SRC_SHEET = 'cJ2gXd'   # 源表-车型, 14列
STD_SHEET = '53652a'   # 车型需求, 10列
PROD_SHEET = '11HTsJ'  # 源表-产品, 21列
IDEA_SHEET = 'VeNjAU'  # 创意产品需求, 6列有效

SRC_START = 562
STD_START = 402
PROD_START = 12
IDEA_START = 10

DRY = '--dry' in sys.argv

CAT_MAP = {
    'Power Running Boards': '电动踏板',
    'Retractable Bed Step': '后侧踏',
    'Powered Retractable Bed Cover': '电动伸缩盖',
    'Hard Tri-Fold Flip Up Tonneau Cover': '硬折叠',
}

# 空产品名按描述归类
DESC_CAT = {
    21888664: '未知',   # "I'd like products for my vehicle" 无明确产品
    21867042: '灯光',   # Light mounts for Ford Transit t150
    21822428: '电动踏板',  # Do you have running board for this vehicle
    21754690: '后侧踏',  # Rear Step
}

MAKE_NORM = {
    'chevy': 'Chevy', 'chevrolet': 'Chevy', 'chev': 'Chevy', 'gm': 'GMC',
    'gmc': 'GMC', 'ram': 'Ram', 'dodge': 'Ram', 'chrysler': 'Ram',
    'jeep': 'Jeep', 'toyota': 'Toyota', 'lexus': 'Lexus',
    'honda': 'Honda', 'acura': 'Acura', 'hyundai': 'Hyundai', 'kia': 'Kia',
    'ford': 'Ford', 'lincoln': 'Lincoln', 'nissan': 'Nissan',
    'mazda': 'Mazda', 'subaru': 'Subaru', 'volkswagen': 'Volkswagen',
    'vw': 'Volkswagen', 'audi': 'Audi', 'bmw': 'BMW',
    'mercedes': 'Mercedes-Benz', 'mercedes-benz': 'Mercedes-Benz',
    'porsche': 'Porsche', 'volvo': 'Volvo', 'tesla': 'Tesla',
    'rivian': 'Rivian', 'cadillac': 'Cadillac', 'buick': 'Buick',
    'chrysler(dodge)': 'Ram', 'land rover': 'Land Rover',
    'jaguar': 'Jaguar', 'mini': 'MINI', 'genesis': 'Genesis',
    'hummer': 'GMC',
}

CAB_WORDS = ['crew cab', 'crewcab', 'crew', 'super cab', 'supercab',
             'extended cab', 'quad cab', 'mega cab', 'regular cab',
             'single cab', '2 door', '4 door', '4door', '2-door', '4-door',
             '4x4', '4wd', '2wd', 'awd', 'dually', 'short bed', 'long bed',
             'standard bed', '6.5 box', "6 1/2' bed", 'diesel', '5.3 liter',
             'v-8', 'v8', '4wd', 'box']

def txt(v):
    if v is None: return ''
    if isinstance(v, (int, float)): return str(int(v))
    return str(v).strip()

def norm_make(raw):
    r = txt(raw)
    if not r: return ''
    l = r.lower().strip()
    if l in MAKE_NORM: return MAKE_NORM[l]
    for k, v in sorted(MAKE_NORM.items(), key=lambda x: -len(x[0])):
        if k in l: return v
    return r.title()

def norm_model(make, raw):
    """返回 (Model, 清理后)"""
    m = txt(raw)
    m = re.sub(r'\s*\(.*?\)', ' ', m)
    m = re.sub(r'\s+', ' ', m).strip()
    if not m: return ''
    low = m.lower()

    if make == 'Ford':
        if 'f350' in low or 'f-350' in low:
            return 'F-350 Super Duty'
        if 'f250' in low or 'f-250' in low or 'super duty' in low:
            return 'F-250 Super Duty'
        if 'f150' in low or 'f-150' in low or 'f160' in low or 'f-160' in low:
            return 'F-150'
        if 'bronco raptor' in low or 'raptor' in low:
            return 'Bronco Raptor'
        if 'bronco' in low:
            return 'Bronco'
        if 'ranger' in low:
            return 'Ranger'
        if 'maverick' in low:
            return 'Maverick'
        if 'transit' in low:
            return 'Transit'
        if 'excursion' in low:
            return 'Excursion'
        if 'explorer' in low:
            return 'Explorer Sport Trac' if 'sport trac' in low or 'sports trac' in low else 'Explorer'
        if 'expedition' in low:
            return 'Expedition'
        return m.title()
    if make == 'Chevy':
        if '2500' in low: return 'Silverado 2500 HD'
        if '3500' in low: return 'Silverado 3500 HD'
        if '1500' in low: return 'Silverado 1500'
        if 'silverado' in low: return 'Silverado'
        if 'colorado' in low: return 'Colorado'
        if 'tahoe' in low: return 'Tahoe'
        if 'suburban' in low: return 'Suburban'
        if 'traverse' in low: return 'Traverse'
        if 'blazer' in low: return 'Blazer'
        if 'avalanche' in low: return 'Avalanche'
        if 'express' in low: return 'Express Van 1500' if '1500' in low else 'Express Van'
        if 'k10' in low: return 'K10'
        if 'camaro' in low: return 'Camaro'
        return m.title()
    if make == 'GMC':
        if '3500' in low: return 'Sierra 3500 HD'
        if '2500' in low: return 'Sierra 2500 HD'
        if 'sierra' in low: return 'Sierra 1500' if '1500' in low else 'Sierra'
        if 'savana' in low: return 'Savana 1500' if '1500' in low else 'Savana'
        if 'yukon' in low:
            if 'xl' in low: return 'Yukon XL'
            return 'Yukon'
        if 'canyon' in low: return 'Canyon'
        if 'hummer' in low: return 'Hummer EV'
        return m.title()
    if make == 'Ram':
        for n in ('5500', '3500', '2500', '1500'):
            if n in low: return n
        if 'rebel' in low: return '1500'
        if 'dodge' in low: return 'Dodge'
        if 'promaster' in low: return 'Promaster'
        if 'dakota' in low: return 'Dakota'
        return m.title()
    if make == 'Jeep':
        if 'wrangler' in low or 'jk' in low or 'jku' in low: return 'Wrangler'
        if 'gladiator' in low: return 'Gladiator'
        if 'grand cherokee' in low: return 'Grand Cherokee'
        if 'cherokee' in low: return 'Cherokee'
        if 'liberty' in low: return 'Liberty'
        return m.title()
    if make == 'Toyota':
        if 'landcruiser' in low or 'land cruiser' in low: return 'Land Cruiser'
        if 'tundra' in low: return 'Tundra'
        if 'tacoma' in low: return 'Tacoma'
        if 'highlander' in low: return 'Highlander'
        if 'sequoia' in low: return 'Sequoia'
        if '4runner' in low or '4 runner' in low or '4runner' in low.replace(' ', ''): return '4Runner'
        if 'fjcruiser' in low.replace(' ', '') or 'fj cruiser' in low: return 'FJ Cruiser'
        return m.title()
    if make == 'Lexus':
        if 'nx' in low: return 'NX 300'
        if 'gx' in low: return 'GX 550'
        if 'rx' in low: return 'RX 350'
        return m.title()
    if make == 'Rivian':
        return 'R1T' if 'r1t' in low else 'R1S' if 'r1s' in low else m.title()
    if make == 'Honda':
        if 'ridgeline' in low: return 'Ridgeline'
        if 'pilot' in low: return 'Pilot'
        if 'odyssey' in low: return 'Odyssey'
        return m.title()
    if make == 'Cadillac':
        if 'escalade' in low: return 'Escalade'
        return m.title()
    if make == 'Nissan':
        if 'frontier' in low: return 'Frontier'
        if 'titan' in low: return 'Titan'
        if 'nv' in low or 'nv3500' in low.replace('-', ''): return 'NV3500'
        return m.title()
    if make == 'Tesla':
        if 'cyber' in low: return 'Cybertruck'
        return m.title()
    for w in CAB_WORDS:
        m = re.sub(r'\b' + re.escape(w) + r'\b', ' ', m, flags=re.IGNORECASE)
    m = re.sub(r'\s+', ' ', m).strip()
    if not m: return ''
    return ' '.join(w.title() if not w.isupper() else w for w in m.split())

def norm_year(raw, desc='', model=''):
    y = txt(raw)
    for src in (y, model, desc):
        mm = re.search(r'\b(19\d{2}|20\d{2})\b', src)
        if mm: return mm.group(1)
    return ''

# 特殊行覆盖: ID -> (year, make, model, category, product_name)
OVERRIDES = {
    21926069: ('2019', 'GMC', 'Sierra 2500 HD', '电动伸缩盖', 'Powered Retractable Bed Cover'),  # "2500 had" typo
    21869701: ('2026', 'Toyota', '4Runner', '电动踏板', 'Power Running Boards'),  # year from desc
    21862560: ('1996', 'Chevy', 'Silverado', '电动踏板', 'Power Running Boards'),  # GMC/Chevrolet 混淆
    21840746: ('2022', 'Nissan', 'Titan', '硬折叠', 'Hard Tri-Fold Flip Up Tonneau Cover'),
    21816169: ('2009', 'Nissan', 'Titan', '电动伸缩盖', 'Powered Retractable Bed Cover'),  # desc 提到 Nissan Titan
    21792081: ('1999', 'Ford', 'F-350 Super Duty', '电动踏板', 'Power Running Boards'),  # year in model
    21789650: ('2018', 'Chevy', 'Silverado 2500 HD', '电动伸缩盖', 'Powered Retractable Bed Cover'),  # year from desc
    21789577: ('1989', 'Toyota', '', '电动踏板', 'Power Running Boards'),
    21759329: ('2021', 'Toyota', '4Runner', '电动踏板', 'Power Running Boards'),  # "Limited" = 4Runner Limited
    21747189: ('2018', 'Ram', '1500', '后侧踏', 'Retractable Bed Step'),  # desc: 2018 Ram 1500
    21743055: ('2022', 'Jeep', 'Grand Cherokee', '电动伸缩盖', 'Powered Retractable Bed Cover'),
    21740126: ('2012', 'Toyota', 'Land Cruiser', '电动踏板', 'Power Running Boards'),
    21737203: ('2023', 'Nissan', 'Titan', '电动踏板', 'Power Running Boards'),
    21705768: ('2014', 'GMC', 'Savana 1500', '电动踏板', 'Power Running Boards'),
    21675867: ('2023', 'Nissan', 'Titan', '电动踏板', 'Power Running Boards'),
    21662591: ('2016', 'Nissan', 'NV3500', '电动踏板', 'Power Running Boards'),
    21659045: ('2008', 'Ford', 'Explorer Sport Trac', '电动伸缩盖', 'Powered Retractable Bed Cover'),
    21781526: ('2008', 'Toyota', 'FJ Cruiser', '电动踏板', 'Power Running Boards'),
    21761794: ('2025', 'Tesla', 'Cybertruck', '硬折叠', 'Hard Tri-Fold Flip Up Tonneau Cover'),
    21825763: ('2008', 'Ford', 'F-150', '硬折叠', 'Hard Tri-Fold Flip Up Tonneau Cover'),  # "F 150"
    21755812: ('2025', 'Ford', 'Ranger Raptor', '电动踏板', 'Power Running Boards'),
    21786831: ('2026', 'Ford', 'Explorer', '电动踏板', 'Power Running Boards'),
    21885068: ('2019', 'Ram', '1500', '后侧踏', 'Retractable Bed Step'),  # Rebel = 1500 trim
    21664880: ('1993', 'Ford', 'Bronco', '电动踏板', 'Power Running Boards'),
    21754690: ('2019', 'Ram', '1500', '后侧踏', 'Retractable Bed Step'),  # Rear Step
    21888664: ('2001', 'Chevy', 'Silverado', '未知', ''),
    21867042: ('2015', 'Ford', 'Transit', '灯光', ''),
    21822428: ('2022', 'Chevy', 'Tahoe', '电动踏板', ''),
    21954749: ('2008', 'Chevy', 'Express Van 1500', '电动踏板', 'Power Running Boards'),
    21768753: ('1975', 'Ford', 'Bronco', '电动踏板', 'Power Running Boards'),
    21667168: ('2027', 'Toyota', 'Land Cruiser', '电动踏板', 'Power Running Boards'),
    21771426: ('2014', 'Ram', '2500', '电动踏板', 'Power Running Boards'),
    21845356: ('2010', 'Ram', '2500', '电动伸缩盖', 'Powered Retractable Bed Cover'),  # Learime typo
    21662412: ('2005', 'Toyota', 'Tundra', '后侧踏', 'Retractable Bed Step'),
    21869158: ('2016', 'Ram', '2500', '电动伸缩盖', 'Powered Retractable Bed Cover'),
    21868174: ('2008', 'Honda', 'Ridgeline', '硬折叠', 'Hard Tri-Fold Flip Up Tonneau Cover'),
    21698238: ('2023', 'Honda', 'Ridgeline', '硬折叠', 'Hard Tri-Fold Flip Up Tonneau Cover'),
    21677607: ('2022', 'Ford', 'Expedition', '电动踏板', 'Power Running Boards'),
    21718222: ('2010', 'Ford', 'Explorer', '电动踏板', 'Power Running Boards'),
    21666289: ('2003', 'Ford', 'Explorer Sport Trac', '电动踏板', 'Power Running Boards'),
    21857586: ('2024', 'Rivian', 'R1T', '后侧踏', 'Retractable Bed Step'),
    21770446: ('2023', 'Rivian', 'R1T', '电动踏板', 'Power Running Boards'),
    21763978: ('2024', 'GMC', 'Hummer EV', '电动伸缩盖', 'Powered Retractable Bed Cover'),
    21841251: ('2025', 'GMC', 'Hummer EV', '电动伸缩盖', 'Powered Retractable Bed Cover'),
    21817311: ('2025', 'GMC', 'Hummer EV', '电动伸缩盖', 'Powered Retractable Bed Cover'),
    21739286: ('2026', 'Ram', '1500', '后侧踏', 'Retractable Bed Step'),  # RHO
    21670275: ('2015', 'Toyota', 'Tundra', '电动踏板', 'Power Running Boards'),
    21670070: ('2023', 'Toyota', 'Tundra', '电动踏板', 'Power Running Boards'),
    21724843: ('2024', 'Toyota', 'Sequoia', '电动踏板', 'Power Running Boards'),
    21900416: ('2026', 'Lexus', 'GX 550', '电动踏板', 'Power Running Boards'),
    21706501: ('2023', 'Lexus', 'GX 550', '电动踏板', 'Power Running Boards'),
    21910116: ('2017', 'Jeep', 'Grand Cherokee', '电动踏板', 'Power Running Boards'),
    21906446: ('2006', 'Toyota', 'Tacoma', '后侧踏', 'Retractable Bed Step'),
    21782413: ('2006', 'Toyota', 'Tacoma', '后侧踏', 'Retractable Bed Step'),
    21736322: ('2003', 'Toyota', 'Tundra', '后侧踏', 'Retractable Bed Step'),
    21946755: ('2013', 'Chevy', 'Avalanche', '后侧踏', 'Retractable Bed Step'),
    21864713: ('2013', 'Ford', 'F-150', '后侧踏', 'Retractable Bed Step'),
    21757623: ('1986', 'Toyota', '4Runner', '电动踏板', 'Power Running Boards'),
    21869780: ('2007', 'Toyota', 'FJ Cruiser', '电动踏板', 'Power Running Boards'),
    21700444: ('1988', 'Ford', 'F-150', '电动踏板', 'Power Running Boards'),
    21851806: ('1994', 'Ford', 'F-150', '电动踏板', 'Power Running Boards'),
    21731213: ('1997', 'Ford', 'F-150', '电动踏板', 'Power Running Boards'),
    21913795: ('2014', 'Ford', 'F-350 Super Duty', '电动踏板', 'Power Running Boards'),
    21662194: ('2015', 'Ford', 'F-350 Super Duty', '电动踏板', 'Power Running Boards'),
    21712263: ('1996', 'Ford', 'F-350 Super Duty', '电动踏板', 'Power Running Boards'),
    21833192: ('2000', 'Ford', 'F-350 Super Duty', '电动踏板', 'Power Running Boards'),
    21904068: ('2013', 'Ford', 'F-250 Super Duty', '电动踏板', 'Power Running Boards'),
    21810894: ('2015', 'Ford', 'F-250 Super Duty', '电动踏板', 'Power Running Boards'),
    21789665: ('2015', 'Ford', 'F-250 Super Duty', '电动踏板', 'Power Running Boards'),
    21791833: ('2000', 'Ford', 'F-250 Super Duty', '电动踏板', 'Power Running Boards'),
    21807760: ('2004', 'Ford', 'F-250 Super Duty', '电动踏板', 'Power Running Boards'),
    21792402: ('2012', 'Ford', 'F-250 Super Duty', '电动踏板', 'Power Running Boards'),
    21709011: ('2016', 'Ford', 'F-250 Super Duty', '电动踏板', 'Power Running Boards'),
    21656925: ('2015', 'Ford', 'F-250 Super Duty', '电动踏板', 'Power Running Boards'),
    21937400: ('2021', 'Ford', 'Ranger', '电动伸缩盖', 'Powered Retractable Bed Cover'),
    21781570: ('2022', 'Ford', 'Ranger', '硬折叠', 'Hard Tri-Fold Flip Up Tonneau Cover'),
    21807514: ('2021', 'Ford', 'Ranger', '硬折叠', 'Hard Tri-Fold Flip Up Tonneau Cover'),
    21758056: ('2020', 'Ford', 'Ranger', '电动踏板', 'Power Running Boards'),
    21901731: ('2023', 'Ford', 'Bronco', '电动踏板', 'Power Running Boards'),
    21877607: ('2023', 'Ford', 'Bronco', '电动踏板', 'Power Running Boards'),
    21921271: ('2005', 'Ford', 'Excursion', '电动踏板', 'Power Running Boards'),
    21653421: ('2022', 'Chevy', 'Colorado', '电动踏板', 'Power Running Boards'),
    21827776: ('2026', 'Chevy', 'Colorado', '电动踏板', 'Power Running Boards'),
    21674751: ('2016', 'Chevy', 'Colorado', '硬折叠', 'Hard Tri-Fold Flip Up Tonneau Cover'),
    21868399: ('2021', 'Chevy', 'Colorado', '电动伸缩盖', 'Powered Retractable Bed Cover'),
    21788432: ('2018', 'Chevy', 'Colorado', '电动踏板', 'Power Running Boards'),
    21807166: ('2015', 'GMC', 'Canyon', '硬折叠', 'Hard Tri-Fold Flip Up Tonneau Cover'),
    21807075: ('2019', 'GMC', 'Canyon', '电动踏板', 'Power Running Boards'),
    21751351: ('2016', 'GMC', 'Canyon', '电动踏板', 'Power Running Boards'),
    21783096: ('2021', 'GMC', 'Canyon', '电动伸缩盖', 'Powered Retractable Bed Cover'),
    21661841: ('2022', 'GMC', 'Canyon', '电动踏板', 'Power Running Boards'),
    21868555: ('2025', 'Chevy', 'Tahoe', '电动踏板', 'Power Running Boards'),
    21789890: ('2015', 'Chevy', 'Tahoe', '电动踏板', 'Power Running Boards'),
    21762283: ('2014', 'Chevy', 'Tahoe', '电动踏板', 'Power Running Boards'),
    21750724: ('1999', 'Chevy', 'Tahoe', '电动踏板', 'Power Running Boards'),
    21820359: ('2019', 'Chevy', 'Silverado 1500', '电动踏板', 'Power Running Boards'),
    21774185: ('2011', 'Chevy', 'Silverado 1500', '电动踏板', 'Power Running Boards'),
    21773509: ('1998', 'Chevy', 'Silverado 1500', '电动踏板', 'Power Running Boards'),
    21707257: ('2008', 'Chevy', 'Silverado 1500', '电动踏板', 'Power Running Boards'),
    21851182: ('2016', 'Chevy', 'Silverado 2500 HD', '电动踏板', 'Power Running Boards'),
    21809715: ('2017', 'Chevy', 'Silverado 3500 HD', '电动踏板', 'Power Running Boards'),
    21878023: ('2015', 'Chevy', 'Silverado 3500 HD', '电动踏板', 'Power Running Boards'),
    21878264: ('2016', 'Chevy', 'Silverado 2500 HD', '电动踏板', 'Power Running Boards'),
    21800624: ('2016', 'Chevy', 'Silverado 2500 HD', '电动踏板', 'Power Running Boards'),
    21789277: ('2004', 'Chevy', 'Silverado 2500 HD', '电动踏板', 'Power Running Boards'),
    21727993: ('2026', 'GMC', 'Sierra 1500', '电动踏板', 'Power Running Boards'),
    21725366: ('2011', 'GMC', 'Sierra 1500', '电动踏板', 'Power Running Boards'),
    21780426: ('2022', 'GMC', 'Sierra 1500', '电动踏板', 'Power Running Boards'),
    21755837: ('2018', 'GMC', 'Sierra 1500', '硬折叠', 'Hard Tri-Fold Flip Up Tonneau Cover'),
    21909497: ('2010', 'GMC', 'Sierra 1500', '电动伸缩盖', 'Powered Retractable Bed Cover'),
    21878116: ('2021', 'GMC', 'Yukon', '电动踏板', 'Power Running Boards'),
    21672946: ('2015', 'GMC', 'Sierra 2500 HD', '电动踏板', 'Power Running Boards'),
    21880241: ('2014', 'GMC', 'Sierra 2500 HD', '电动踏板', 'Power Running Boards'),
    21843744: ('2018', 'GMC', 'Sierra 2500 HD', '电动踏板', 'Power Running Boards'),
    21738286: ('2022', 'GMC', 'Sierra 2500 HD', '电动踏板', 'Power Running Boards'),
    21707447: ('2019', 'GMC', 'Sierra 2500 HD', '电动踏板', 'Power Running Boards'),
    21707844: ('2008', 'GMC', 'Sierra 2500 HD', '电动踏板', 'Power Running Boards'),
    21702739: ('2019', 'GMC', 'Sierra 2500 HD', '电动踏板', 'Power Running Boards'),
    21670066: ('2017', 'GMC', 'Sierra 2500 HD', '电动踏板', 'Power Running Boards'),
    21816580: ('2017', 'GMC', 'Sierra 2500 HD', '电动踏板', 'Power Running Boards'),
    21657773: ('2002', 'GMC', 'Sierra 2500 HD', '电动踏板', 'Power Running Boards'),
    21763129: ('2006', 'GMC', 'Sierra 2500 HD', '电动踏板', 'Power Running Boards'),
    21694828: ('2005', 'GMC', 'Sierra 3500 HD', '电动踏板', 'Power Running Boards'),
    21689274: ('2019', 'GMC', 'Sierra 2500 HD', '电动踏板', 'Power Running Boards'),
    21954882: ('2020', 'Ram', 'Promaster', '电动踏板', 'Power Running Boards'),
    21959005: ('2026', 'Ram', '2500', '电动踏板', 'Power Running Boards'),
    21922084: ('2014', 'Ram', '2500', '电动踏板', 'Power Running Boards'),
    21912666: ('2018', 'Ram', '2500', '电动踏板', 'Power Running Boards'),
    21899521: ('2012', 'Ram', '2500', '电动踏板', 'Power Running Boards'),
    21884370: ('2014', 'Ram', '2500', '电动踏板', 'Power Running Boards'),
    21877881: ('2017', 'Ram', '2500', '电动踏板', 'Power Running Boards'),
    21830378: ('2016', 'Ram', '2500', '电动踏板', 'Power Running Boards'),
    21790487: ('2015', 'Ram', '2500', '电动踏板', 'Power Running Boards'),
    21761583: ('2013', 'Ram', '2500', '电动踏板', 'Power Running Boards'),
    21756437: ('2015', 'Ram', '2500', '电动伸缩盖', 'Powered Retractable Bed Cover'),
    21751149: ('2010', 'Ram', '2500', '电动踏板', 'Power Running Boards'),
    21750279: ('2000', 'Ram', '2500', '电动伸缩盖', 'Powered Retractable Bed Cover'),
    21702912: ('2016', 'Ram', '2500', '电动踏板', 'Power Running Boards'),
    21805926: ('2016', 'Ram', '3500', '电动踏板', 'Power Running Boards'),
    21687484: ('2007', 'Ram', '3500', '电动踏板', 'Power Running Boards'),
    21733241: ('2017', 'Ram', '3500', '硬折叠', 'Hard Tri-Fold Flip Up Tonneau Cover'),
    21766829: ('2018', 'Ram', '3500', '硬折叠', 'Hard Tri-Fold Flip Up Tonneau Cover'),
    21815435: ('2012', 'Ram', '3500', '电动踏板', 'Power Running Boards'),
    21794327: ('2001', 'Ram', '1500', '电动踏板', 'Power Running Boards'),
    21845042: ('2005', 'Ford', 'F-150', '电动踏板', 'Power Running Boards'),
    21816161: ('2020', 'Ford', 'F-150', '电动伸缩盖', 'Powered Retractable Bed Cover'),
    21947574: ('2014', 'Ford', 'F-150', '电动踏板', 'Power Running Boards'),
}

# ===== 读取 Excel =====
wb = openpyxl.load_workbook(EXCEL, read_only=True)
ws = wb['vehicle model submit']
rows = list(ws.iter_rows(values_only=True))
header = rows[0]
idx = {h: i for i, h in enumerate(header)}
data = rows[1:]
print(f'读取 {len(data)} 条提交')

PAGE = 'Help Us Support Your Ride – WOLFBOX Gear'

src_rows = []   # 14列
std_rows = []   # 10列
skipped = []
for r in data:
    rid = txt(r[idx['ID']])
    if not rid:
        skipped.append(('no-id', r)); continue
    iid = int(rid)
    prod = txt(r[idx['Product name']])
    desc = txt(r[idx['Product description or any custom request']])
    raw_year = txt(r[idx['Vehicle Year']])
    raw_make = txt(r[idx['Vehicle Make']])
    raw_model = txt(r[idx['Vehicle Model']])

    if iid in OVERRIDES:
        year, make, model, cat, prod2 = OVERRIDES[iid]
        prod = prod2 or prod
        if not year: year = norm_year(raw_year, desc, raw_model)
        if not make: make = norm_make(raw_make)
        if not model: model = norm_model(make, raw_model)
    else:
        make = norm_make(raw_make)
        model = norm_model(make, raw_model)
        year = norm_year(raw_year, desc, raw_model)
        cat = CAT_MAP.get(prod, DESC_CAT.get(iid, ''))

    src_rows.append([
        rid, PAGE, '', txt(r[idx['IP Address']]),
        txt(r[idx['First Name']]), txt(r[idx['Last Name']]),
        txt(r[idx['Email']]), txt(r[idx['Phone']]),
        raw_year, raw_make, raw_model, prod, desc,
        txt(r[idx['created at']]),
    ])
    std_rows.append([year, make, model, '', prod, desc, cat, '', '', ''])

print(f'原始行: {len(src_rows)}, 标准化行: {len(std_rows)}, 跳过: {len(skipped)}')
if skipped:
    print('跳过明细:', skipped)

no_cat = [(s[0], s[1], s[2], s[4]) for s in std_rows if not s[6]]
print('无分类的行:', no_cat if no_cat else '无 ✓')

if DRY:
    print('\n===== 标准化结果预览 =====')
    for s in std_rows:
        print(f"{s[0]:5s} {s[1]:8s} {s[2]:28s} {s[6]}")
    from collections import Counter
    print('\n品类分布:', dict(Counter(s[6] for s in std_rows)))
    sys.exit(0)

# ===== 写入飞书 =====
r = requests.post("https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
                  json={"app_id": APP_ID, "app_secret": APP_SECRET}, timeout=10)
t = r.json()['tenant_access_token']

def append_rows(sheet, start_row, values):
    end_row = start_row + len(values) - 1
    ncols = len(values[0])
    col_end = chr(ord('A') + ncols - 1)
    rng = f"{sheet}!A{start_row}:{col_end}{end_row}"
    url = f"https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{TOKEN}/values"
    body = {"valueRange": {"range": rng, "values": values}}
    resp = requests.put(url, headers={"Authorization": f"Bearer {t}", "Content-Type": "application/json"},
                        json=body, timeout=30)
    d = resp.json()
    print(f"写入 {sheet} {rng}: {d.get('code')} {d.get('msg')}")
    return d.get('code') == 0

ok1 = append_rows(SRC_SHEET, SRC_START, src_rows)
ok2 = append_rows(STD_SHEET, STD_START, std_rows)
print('源表-车型 成功:', ok1, '| 车型需求 成功:', ok2)

# ===== 产品创意 =====
ws2 = wb['Product idea']
rows2 = list(ws2.iter_rows(values_only=True))
hdr2 = rows2[0]
idx2 = {h: i for i, h in enumerate(hdr2)}
print(f'\n产品创意 {len(rows2)-1} 条')
for r2 in rows2[1:]:
    rid = txt(r2[idx2['ID']])
    # 源表-产品 (21列)
    prod_row = [
        rid, 'New Product Ideas | WOLFBOX Gear – WOLFBOX', '', txt(r2[idx2['IP Address']]),
        txt(r2[idx2['By clicking ‘Agree’ or submitting your idea, you confirm that you are at least 18 years old and agree to be bound by the terms and conditions outlined above.']]),
        txt(r2[idx2['First Name']]), txt(r2[idx2['Last Name']]),
        txt(r2[idx2['Email']]), txt(r2[idx2['Phone Number']]),
        txt(r2[idx2['Street Address']]), txt(r2[idx2['Street Address Line 2']]),
        txt(r2[idx2['City']]), txt(r2[idx2['State / Province']]), txt(r2[idx2['Postal / Zip Code']]),
        txt(r2[idx2['Submission Type']]), txt(r2[idx2['Title']]),
        txt(r2[idx2['Description']]), txt(r2[idx2['Have you shared this idea with any other truck/off-road accessory brands?']]),
        txt(r2[idx2['Please specify which brands (so we can faster evaluate market availability:']]),
        txt(r2[idx2['Attachments']]), txt(r2[idx2['created at']]),
    ]
    ok3 = append_rows(PROD_SHEET, PROD_START, [prod_row])
    print('源表-产品 成功:', ok3)

    # 创意产品需求 (6列): Title, Description, 是否分享, 产品分类, 更新日期, 中文译文
    title = txt(r2[idx2['Title']])
    desc = txt(r2[idx2['Description']])
    shared = txt(r2[idx2['Have you shared this idea with any other truck/off-road accessory brands?']])
    today = datetime.now().strftime('%Y/%-m/%-d')
    idea_row = [title, desc, shared, '电动踏板', today,
                '悍马H2玩家想要电动踏板方案：客户愿自己加工支架，把2013款凯迪拉克Escalade原厂折叠踏板改装到H2上，或直接购买WOLFBOX裸板+电机+线束（不带车型适配支架）自己开发安装支架。客户有原厂岩石护板+3寸圆管踏板，觉得效果一般但不理想，希望与WOLFBOX合作开发H2专用套件。']
    ok4 = append_rows(IDEA_SHEET, IDEA_START, [idea_row])
    print('创意产品需求 成功:', ok4)
