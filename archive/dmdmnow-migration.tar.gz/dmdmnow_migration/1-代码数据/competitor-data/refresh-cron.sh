#!/bin/bash
# 竞品数据自动刷新脚本 - 每天运行
# 通过 web_search 检测促销/价格变化，输出时间戳

LOG="/home/ecs-user/.openclaw/workspace/competitor-data/refresh.log"
echo "===== $(date) =====" >> "$LOG"

# 检查各品牌促销变化关键词
check_promo() {
  local brand="$1" site="$2" query="$3"
  local result=$(curl -sL -A 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' \
    "https://www.google.com/search?q=$query" 2>/dev/null \
    | grep -oiP '(sale|% off|discount|promo|free shipping|code)' | sort | uniq -c | tr -s ' ')
  echo "[$brand] $site → $result" >> "$LOG"
}

check_promo "WeatherTech" "weathertech.com" "site:weathertech.com sale"
check_promo "Husky" "huskyliners.com" "site:huskyliners.com % off sale"
check_promo "Lasfit" "lasfit.com" "site:lasfit.com sale"
check_promo "Smartliner" "smartliner-usa.com" "site:smartliner-usa.com sale"
check_promo "TuxMat" "tuxmat.com" "site:tuxmat.com sale"
check_promo "OEDRO" "oedro.com" "site:oedro.com sale"

# Update dashboard timestamp
echo "✅ 刷新完成" >> "$LOG"
