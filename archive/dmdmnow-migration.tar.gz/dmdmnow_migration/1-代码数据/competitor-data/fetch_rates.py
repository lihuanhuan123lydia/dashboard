import json, os, requests

DATA_DIR = os.path.dirname(os.path.abspath(__file__))

with open(os.path.join(DATA_DIR, 'api_keys.json')) as f:
    keys = json.load(f)
api_key = keys.get('alpha_vantage_key', '')

result = {'GBPUSD': None, 'EURUSD': None, 'timestamp': None}

try:
    for pair, from_c, to_c in [('GBPUSD','GBP','USD'), ('EURUSD','EUR','USD')]:
        r = requests.get(f'https://www.alphavantage.co/query?function=CURRENCY_EXCHANGE_RATE&from_currency={from_c}&to_currency={to_c}&apikey={api_key}', timeout=10)
        data = r.json()
        rate = data.get('Realtime Currency Exchange Rate', {})
        result[pair] = rate.get('5. Exchange Rate')
    result['timestamp'] = __import__('datetime').datetime.now().isoformat()
except Exception as e:
    result['error'] = str(e)

with open(os.path.join(DATA_DIR, 'fx_rates.json'), 'w') as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
print(f"Rates: GBP/USD={result['GBPUSD']} EUR/USD={result['EURUSD']}")
