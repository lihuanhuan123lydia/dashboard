#!/usr/bin/env python3
"""标准化学员v2 — 修复了API格式"""
import requests, json, re, time
from collections import defaultdict, Counter

APP_ID = "cli_a95e614746395cbd"
APP_SECRET = "ZTPbyJlJNK0utcjkqgTazh8JDnLFhK4X"
SP = "NV6Gsl1lwhBw7RtYPTAcpQQenjq"
SUB_SHEET = "1sCyzd"
MAIN_SHEET = "0iCDMN"

def get_token():
    r = requests.post("https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
        json={"app_id": APP_ID, "app_secret": APP_SECRET}, timeout=10)
    return r.json()["tenant_access_token"]

def safe(v):
    if v is None: return ""
    return str(v).strip()

def write_range(token, sheet_id, range_str, values):
    url = f"https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SP}/values"
    payload = {"valueRange": {"range": f"{sheet_id}!{range_str}", "values": values}}
    r = requests.put(url, headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        json=payload, timeout=30)
    return r.json()

# === READ ===
print("Reading submissions...")
token = get_token()
r = requests.get(f"https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SP}/values/{SUB_SHEET}!A:I",
    headers={"Authorization": f"Bearer {token}"}, timeout=120)
rows = r.json()["data"]["valueRange"]["values"]
print(f"  {len(rows)} rows")

# === MODEL STANDARDIZATION ===
MAKE_ALIASES = {
    "FORD":"Ford","CHEVROLET":"Chevrolet","CHEVY":"Chevrolet","TOYOTA":"Toyota",
    "GMC":"GMC","HONDA":"Honda","DODGE":"Dodge","NISSAN":"Nissan","KIA":"Kia",
    "HYUNDAI":"Hyundai","JEEP":"Jeep","SUBARU":"Subaru","VOLKSWAGEN":"Volkswagen",
    "VW":"Volkswagen","MAZDA":"Mazda","BUICK":"Buick","BMW":"BMW",
    "MERCEDES-BENZ":"Mercedes-Benz","MERCEDES":"Mercedes-Benz","AUDI":"Audi",
    "LEXUS":"Lexus","CADILLAC":"Cadillac","LINCOLN":"Lincoln","RAM":"Ram",
    "CHRYSLER":"Chrysler","ACURA":"Acura","INFINITI":"Infiniti","VOLVO":"Volvo",
    "TESLA":"Tesla","RIVIAN":"Rivian","MITSUBISHI":"Mitsubishi",
}

MODEL_RULES = [
    (r'\bF[- ]?150\b', 'F-150'), (r'\bF[- ]?250\b', 'F-250'), (r'\bF[- ]?350\b', 'F-350'),
    (r'\bF[- ]?450\b', 'F-450'), (r'\bF[- ]?550\b', 'F-550'),
    (r'\bEXPEDITION\b', 'Expedition'), (r'\bEXPLORER\b', 'Explorer'),
    (r'\bESCAPE\b', 'Escape'), (r'\bEDGE\b', 'Edge'),
    (r'\bBRONCO\b', 'Bronco'), (r'\bRANGER\b', 'Ranger'),
    (r'\bMAVERICK\b', 'Maverick'), (r'\bMUSTANG\b', 'Mustang'),
    (r'\bFOCUS\b', 'Focus'), (r'\bFUSION\b', 'Fusion'),
    (r'\bTAURUS\b', 'Taurus'), (r'\bTRANSIT\b', 'Transit'),
    (r'\bFLEX\b', 'Flex'), (r'\bC-MAX\b', 'C-Max'),
    (r'\bE[- ]?SERIES\b', 'E-Series'), (r'\bE[- ]?150\b', 'E-150'),
    (r'\bE[- ]?250\b', 'E-250'), (r'\bE[- ]?350\b', 'E-350'),
    (r'\bEXCURSION\b', 'Excursion'),
    (r'\bSILVERADO\s*1500\b', 'Silverado 1500'),
    (r'\bSILVERADO\s*2500\s*HD\b', 'Silverado 2500HD'),
    (r'\bSILVERADO\s*2500\b', 'Silverado 2500HD'),
    (r'\bSILVERADO\s*3500\s*HD\b', 'Silverado 3500HD'),
    (r'\bSILVERADO\s*3500\b', 'Silverado 3500HD'),
    (r'\bSILVERADO\b', 'Silverado 1500'),
    (r'\bTAHOE\b', 'Tahoe'), (r'\bSUBURBAN\b', 'Suburban'),
    (r'\bEQUINOX\b', 'Equinox'), (r'\bTRAVERSE\b', 'Traverse'),
    (r'\bTRAIL[B]?LAZER\b', 'Trailblazer'), (r'\bTRAX\b', 'Trax'),
    (r'\bMALIBU\b', 'Malibu'), (r'\bBLAZER\b', 'Blazer'),
    (r'\bCORVETTE\b', 'Corvette'), (r'\bCAMARO\b', 'Camaro'),
    (r'\bCRUZE\b', 'Cruze'), (r'\bIMPALA\b', 'Impala'),
    (r'\bSPARK\b', 'Spark'), (r'\bSONIC\b', 'Sonic'),
    (r'\bEXPRESS\b', 'Express'), (r'\bCOLORADO\b', 'Colorado'),
    (r'\bAVALANCHE\b', 'Avalanche'),
    (r'\bSIERRA\s*1500\b', 'Sierra 1500'),
    (r'\bSIERRA\s*2500\s*HD\b', 'Sierra 2500HD'),
    (r'\bSIERRA\s*2500\b', 'Sierra 2500HD'),
    (r'\bSIERRA\s*3500\s*HD\b', 'Sierra 3500HD'),
    (r'\bSIERRA\s*3500\b', 'Sierra 3500HD'),
    (r'\bSIERRA\b', 'Sierra 1500'),
    (r'\bYUKON\b', 'Yukon'), (r'\bACADIA\b', 'Acadia'),
    (r'\bTERRAIN\b', 'Terrain'), (r'\bCANYON\b', 'Canyon'),
    (r'\bSAVANA\b', 'Savana'),
    (r'\bTACOMA\b', 'Tacoma'), (r'\bTUNDRA\b', 'Tundra'),
    (r'\b4[- ]?RUNNER\b', '4Runner'), (r'\b4RUNNER\b', '4Runner'),
    (r'\bHIGHLANDER\b', 'Highlander'), (r'\bRAV4\b', 'RAV4'),
    (r'\bCAMRY\b', 'Camry'), (r'\bCOROLLA\b', 'Corolla'),
    (r'\bSEQUOIA\b', 'Sequoia'), (r'\bSIENNA\b', 'Sienna'),
    (r'\bAVALON\b', 'Avalon'), (r'\bVENZA\b', 'Venza'),
    (r'\bGRAND\s*HIGHLANDER\b', 'Grand Highlander'),
    (r'\bLAND\s*CRUISER\b', 'Land Cruiser'),
    (r'\bPRIUS\b', 'Prius'), (r'\bYARIS\b', 'Yaris'),
    (r'\bFJ\s*CRUISER\b', 'FJ Cruiser'), (r'\bSUPRA\b', 'Supra'),
    (r'\bRAM\s*1500\b', 'Ram 1500'), (r'\bRAM\b', 'Ram 1500'),
    (r'\bRAM\s*2500\b', 'Ram 2500'), (r'\bRAM\s*3500\b', 'Ram 3500'),
    (r'\bRAM\s*4500\b', 'Ram 4500'), (r'\bRAM\s*5500\b', 'Ram 5500'),
    (r'\bCR[- ]?V\b', 'CR-V'), (r'\bCRV\b', 'CR-V'),
    (r'\bPILOT\b', 'Pilot'), (r'\bCIVIC\b', 'Civic'),
    (r'\bACCORD\b', 'Accord'), (r'\bODYSSEY\b', 'Odyssey'),
    (r'\bRIDGELINE\b', 'Ridgeline'), (r'\bPASSPORT\b', 'Passport'),
    (r'\bHR[- ]?V\b', 'HR-V'), (r'\bHRV\b', 'HR-V'),
    (r'\bFIT\b', 'Fit'), (r'\bELEMENT\b', 'Element'),
    (r'\bPROLOGUE\b', 'Prologue'),
    (r'\bROGUE\b', 'Rogue'), (r'\bALTIMA\b', 'Altima'),
    (r'\bFRONTIER\b', 'Frontier'), (r'\bTITAN\b', 'Titan'),
    (r'\bPATHFINDER\b', 'Pathfinder'), (r'\bARMADA\b', 'Armada'),
    (r'\bMURANO\b', 'Murano'), (r'\bSENTRA\b', 'Sentra'),
    (r'\bVERSA\b', 'Versa'), (r'\bKICKS\b', 'Kicks'),
    (r'\bMAXIMA\b', 'Maxima'), (r'\bXTERRA\b', 'Xterra'),
    (r'\bWRANGLER\b', 'Wrangler'),
    (r'\bGRAND\s*CHEROKEE\b', 'Grand Cherokee'),
    (r'\bCHEROKEE\b', 'Cherokee'), (r'\bCOMPASS\b', 'Compass'),
    (r'\bRENEGADE\b', 'Renegade'), (r'\bGLADIATOR\b', 'Gladiator'),
    (r'\bPATRIOT\b', 'Patriot'), (r'\bCOMMANDER\b', 'Commander'),
    (r'\bLIBERTY\b', 'Liberty'), (r'\bWAGONEER\b', 'Wagoneer'),
    (r'\bSANTA\s*FE\b', 'Santa Fe'), (r'\bTUCSON\b', 'Tucson'),
    (r'\bELANTRA\b', 'Elantra'), (r'\bSONATA\b', 'Sonata'),
    (r'\bPALISADE\b', 'Palisade'), (r'\bTELLURIDE\b', 'Telluride'),
    (r'\bSORENTO\b', 'Sorento'), (r'\bSPORTAGE\b', 'Sportage'),
    (r'\bSELTOS\b', 'Seltos'), (r'\bFORTE\b', 'Forte'),
    (r'\bK5\b', 'K5'), (r'\bOPTIMA\b', 'Optima'), (r'\bRIO\b', 'Rio'),
    (r'\bSOUL\b', 'Soul'), (r'\bCARNIVAL\b', 'Carnival'),
    (r'\bSEDONA\b', 'Sedona'), (r'\bNIRO\b', 'Niro'),
    (r'\bKONA\b', 'Kona'), (r'\bIONIQ\b', 'Ioniq'),
    (r'\bVENUE\b', 'Venue'), (r'\bSTINGER\b', 'Stinger'),
    (r'\bOUTBACK\b', 'Outback'), (r'\bFORESTER\b', 'Forester'),
    (r'\bCROSSTREK\b', 'Crosstrek'), (r'\bLEGACY\b', 'Legacy'),
    (r'\bIMPREZA\b', 'Impreza'), (r'\bASCENT\b', 'Ascent'),
    (r'\bWRX\b', 'WRX'), (r'\bCX[- ]?5\b', 'CX-5'),
    (r'\bCX[- ]?9\b', 'CX-9'), (r'\bCX[- ]?3\b', 'CX-3'),
    (r'\bCX[- ]?30\b', 'CX-30'), (r'\bCX[- ]?50\b', 'CX-50'),
    (r'\bCX[- ]?70\b', 'CX-70'), (r'\bCX[- ]?90\b', 'CX-90'),
    (r'\bMAZDA3\b', 'Mazda3'), (r'\bMAZDA6\b', 'Mazda6'),
    (r'\bMX[- ]?5\b', 'MX-5 Miata'),
    (r'\bX1\b', 'X1'), (r'\bX3\b', 'X3'), (r'\bX5\b', 'X5'),
    (r'\bX7\b', 'X7'), (r'\b3[- ]?SERIES\b', '3 Series'),
    (r'\b5[- ]?SERIES\b', '5 Series'), (r'\b7[- ]?SERIES\b', '7 Series'),
    (r'\bGLC\b', 'GLC'), (r'\bGLE\b', 'GLE'), (r'\bGLS\b', 'GLS'),
    (r'\bC[- ]?CLASS\b', 'C-Class'), (r'\bE[- ]?CLASS\b', 'E-Class'),
    (r'\bS[- ]?CLASS\b', 'S-Class'), (r'\bSPRINTER\b', 'Sprinter'),
    (r'\bQ3\b', 'Q3'), (r'\bQ5\b', 'Q5'), (r'\bQ7\b', 'Q7'),
    (r'\bA3\b', 'A3'), (r'\bA4\b', 'A4'), (r'\bA5\b', 'A5'),
    (r'\bA6\b', 'A6'), (r'\bA7\b', 'A7'), (r'\bA8\b', 'A8'),
    (r'\bJETTA\b', 'Jetta'), (r'\bPASSAT\b', 'Passat'),
    (r'\bTIGUAN\b', 'Tiguan'), (r'\bATLAS\b', 'Atlas'),
    (r'\bGOLF\b', 'Golf'), (r'\bTOUAREG\b', 'Touareg'),
    (r'\bID\.?4\b', 'ID.4'),
    (r'\bMODEL\s*3\b', 'Model 3'), (r'\bMODEL\s*S\b', 'Model S'),
    (r'\bMODEL\s*X\b', 'Model X'), (r'\bMODEL\s*Y\b', 'Model Y'),
    (r'\bCYBERTRUCK\b', 'Cybertruck'),
    (r'\bMDX\b', 'MDX'), (r'\bRDX\b', 'RDX'), (r'\bTLX\b', 'TLX'),
    (r'\bINTEGRA\b', 'Integra'), (r'\bZDX\b', 'ZDX'),
    (r'\bESCALADE\b', 'Escalade'), (r'\bXT4\b', 'XT4'),
    (r'\bXT5\b', 'XT5'), (r'\bXT6\b', 'XT6'), (r'\bSRX\b', 'SRX'),
    (r'\bNAVIGATOR\b', 'Navigator'), (r'\bAVIATOR\b', 'Aviator'),
    (r'\bCORSAIR\b', 'Corsair'),
    (r'\bXC90\b', 'XC90'), (r'\bXC60\b', 'XC60'), (r'\bXC40\b', 'XC40'),
    (r'\bS60\b', 'S60'), (r'\bS90\b', 'S90'),
    (r'\bRANGE\s*ROVER\s*SPORT\b', 'Range Rover Sport'),
    (r'\bRANGE\s*ROVER\s*VELAR\b', 'Range Rover Velar'),
    (r'\bRANGE\s*ROVER\s*EVOQUE\b', 'Range Rover Evoque'),
    (r'\bRANGE\s*ROVER\b', 'Range Rover'),
    (r'\bDEFENDER\b', 'Defender'),
    (r'\bDISCOVERY\s*SPORT\b', 'Discovery Sport'),
    (r'\bDISCOVERY\b', 'Discovery'),
    (r'\bQX60\b', 'QX60'), (r'\bQX80\b', 'QX80'), (r'\bQX50\b', 'QX50'),
    (r'\bQ50\b', 'Q50'), (r'\bQ60\b', 'Q60'),
    (r'\bRX[- ]?\d{0,3}\b', 'RX'), (r'\bRX\b', 'RX'),
    (r'\bNX\b', 'NX'), (r'\bES[- ]?\d{0,3}\b', 'ES'),
    (r'\bGX\b', 'GX'), (r'\bLX\b', 'LX'),
    (r'\bR1S\b', 'R1S'), (r'\bR1T\b', 'R1T'),
    (r'\bDURANGO\b', 'Durango'),
    (r'\bGRAND\s*CARAVAN\b', 'Grand Caravan'),
    (r'\bCHARGER\b', 'Charger'), (r'\bCHALLENGER\b', 'Challenger'),
    (r'\bPACIFICA\b', 'Pacifica'), (r'\b300\b', '300'),
    (r'\b200\b', '200'), (r'\bJOURNEY\b', 'Journey'),
    (r'\bENCLAVE\b', 'Enclave'), (r'\bENVISION\b', 'Envision'),
    (r'\bLACROSSE\b', 'LaCrosse'), (r'\bREGAL\b', 'Regal'),
    (r'\bOUTLANDER\b', 'Outlander'),
    (r'\b2500\b', '2500'), (r'\b3500\b', '3500'),
    (r'\bDURANGO\b', 'Durango'),
]

CAB_PATTERNS = [
    (r'\bCREW\s*CAB\b', 'Crew Cab'), (r'\bQUAD\s*CAB\b', 'Quad Cab'),
    (r'\bREGULAR\s*CAB\b', 'Regular Cab'),
    (r'\bEXTENDED\s*CAB\b', 'Extended Cab'),
    (r'\bDOUBLE\s*CAB\b', 'Double Cab'),
    (r'\bCREWMAX\b', 'CrewMax'), (r'\bSUPER\s*CAB\b', 'Super Cab'),
    (r'\bSHORT\s*BED\b', 'Short Bed'), (r'\bLONG\s*BED\b', 'Long Bed'),
    (r'\bSTANDARD\s*BED\b', 'Standard Bed'),
]

KNOWN_TRIMS = {
    'Ford': ['XLT','XL','XLS','LARIAT','PLATINUM','KING RANCH','LIMITED','TREMOR','RAPTOR','STX','FX4','SPORT'],
    'Chevrolet': ['LTZ','LT','LS','Z71','ZR2','RST','HIGH COUNTRY','PREMIER','TRAIL BOSS','CUSTOM','WT','RS','SS'],
    'GMC': ['DENALI','AT4','AT4X','ELEVATION','SLT','SLE','PRO'],
    'Toyota': ['SR5','TRD PRO','TRD','XLE','XSE','SE','LE','CAPSTONE','NIGHTSHADE','PLATINUM','LIMITED','HYBRID','AWD'],
    'Honda': ['EX-L','EXL','EX','LX','TOURING','ELITE','SPORT','HYBRID','AWD'],
    'Nissan': ['SV','SL','S','PRO-4X','PRO 4X','PRO4X','PLATINUM','LE','SR'],
    'Hyundai': ['SEL','SE','LIMITED','NIGHT','HYBRID'],
    'Kia': ['EX','S','LX','GT Line','GT'],
    'Ram': ['LARAMIE','LONE STAR','BIG HORN','REBEL','TRX','LONGHORN','TRADESMAN','LARAMIE'],
    'Subaru': ['WILDERNESS','ONYX','PREMIUM','BASE','LIMITED','SPORT','TOURING'],
    'Volkswagen': ['GTI','GTE','R-LINE','R','TDI','SEL','SE','ALLTRACK'],
    'Dodge': ['GT','R/T','SLT','SXT','HELLCAT'],
    'Jeep': ['SAHARA','RUBICON','WILLYS','ALTITUDE','LATITUDE','LIMITED','TRAILHAWK','OVERLAND','SPORT'],
    'BMW': ['xDrive','SPORT','M'],
    'Mercedes-Benz': ['AMG','4MATIC'],
    'Audi': ['QUATTRO','S LINE'],
    'Mazda': ['CARBON','TURBO','PREMIUM','SELECT','SPORT'],
    'Cadillac': ['SPORT','PREMIUM','LUXURY','V','PLATINUM'],
    'Lexus': ['LUXURY','PREMIUM','SPORT','F SPORT','HYBRID','AWD'],
    'Chrysler': ['S','LIMITED','TOURING','LX'],
    'Volvo': ['R-DESIGN','INSCRIPTION','MOMENTUM','POLESTAR','ULTIMATE','PLUS','CORE'],
    'Land Rover': ['SE','HSE','AUTOBIOGRAPHY','S'],
    'Tesla': ['LONG RANGE','PERFORMANCE','PLAID','STANDARD'],
}

def normalize_make(m):
    m = m.strip().upper()
    return MAKE_ALIASES.get(m, m.title())

def process_model(model_raw, make_std):
    m = model_raw.strip()
    if not m: return "", []
    m_orig = m
    m_up = m.upper()
    
    # Extract cab/body info
    cab_info = []
    for pat, label in CAB_PATTERNS:
        if re.search(pat, m_up):
            cab_info.append(label)
            m_up = re.sub(pat, '', m_up)
            m = re.sub(pat, '', m, flags=re.IGNORECASE)
    
    # Apply model rules (match against uppercase)
    for pat, repl in MODEL_RULES:
        if re.search(pat, m_up):
            m = re.sub(pat, repl, m, flags=re.IGNORECASE)
            m_up = m.upper()
    
    # Extract trims
    trims = cab_info[:]
    brand_trims = KNOWN_TRIMS.get(make_std, [])
    for trim in brand_trims:
        t_up = trim.upper()
        if ' ' in t_up:
            if t_up in m_up:
                trims.append(trim)
                m_up = m_up.replace(t_up, '')
                m = re.sub(re.escape(trim), '', m, flags=re.IGNORECASE)
        else:
            pat = r'\b' + re.escape(t_up) + r'\b'
            if re.search(pat, m_up):
                trims.append(trim)
                m_up = re.sub(pat, '', m_up)
                m = re.sub(r'\b' + re.escape(trim) + r'\b', '', m, flags=re.IGNORECASE)
    
    # Catch AWD/4WD generically
    for g in ['AWD','4WD','4X4','4x4','FWD']:
        pat = r'\b' + re.escape(g.upper()) + r'\b'
        if re.search(pat, m_up) and g not in trims:
            trims.append(g)
            m_up = re.sub(pat, '', m_up)
            m = re.sub(r'\b' + re.escape(g) + r'\b', '', m, flags=re.IGNORECASE)
    
    # Clean up
    m = re.sub(r'\s+', ' ', m).strip()
    m = re.sub(r'\s*-\s*', '-', m)
    
    # Remove stray characters
    m = re.sub(r'[^\w\s\-\.\d]', '', m)
    m = re.sub(r'\s+', ' ', m).strip()
    
    if not m:
        m = model_raw.strip()
    
    return m, list(dict.fromkeys(trims))

# === PROCESS ===
print("Processing submissions...")
results = []
for row in rows[1:]:
    make_raw = safe(row[0]) if len(row) > 0 else ""
    model_raw = safe(row[1]) if len(row) > 1 else ""
    year_raw = safe(row[3]) if len(row) > 3 else ""
    note = safe(row[4]) if len(row) > 4 else ""
    
    if not make_raw or not model_raw: continue
    
    year = ""
    if year_raw:
        try:
            y = int(float(year_raw))
            if 1900 < y < 2030: year = str(y)
        except: pass
    
    make_std = normalize_make(make_raw)
    model_std, trims = process_model(model_raw, make_std)
    trim_str = " / ".join(trims)
    
    results.append([make_std, model_std, trim_str, year])

print(f"  Processed {len(results)} submissions")
trimmed = sum(1 for r in results if r[2])
print(f"  With trim: {trimmed}, Without: {len(results)-trimmed}")

# === WRITE TO SUBMISSIONS SHEET ===
print("\nWriting to submissions sheet (A:D columns)...")
BATCH = 2000
for start in range(0, len(results), BATCH):
    batch = results[start:start+BATCH]
    row_start = start + 2
    row_end = row_start + len(batch) - 1
    
    token = get_token()
    resp = write_range(token, SUB_SHEET, f"A{row_start}:D{row_end}", batch)
    code = resp.get('code', -1)
    if code != 0:
        print(f"  ERROR batch {row_start}-{row_end}: {resp}")
        break
    if (start // BATCH) % 3 == 0:
        print(f"  Wrote rows {row_start}-{row_end} ({start+len(batch)}/{len(results)})")
    time.sleep(0.5)

print("✅ Submissions sheet done!")

# === PROCESS MAIN SHEET ===
print("\n=== Processing main sheet ===")
token = get_token()
r = requests.get(f"https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SP}/values/{MAIN_SHEET}!A:G",
    headers={"Authorization": f"Bearer {token}"}, timeout=30)
main_rows = r.json()["data"]["valueRange"]["values"]
print(f"  {len(main_rows)} rows")

# Aggregate
agg = {}
for row in main_rows[1:]:
    if len(row) < 2: continue
    make_raw = safe(row[0])
    model_raw = safe(row[1])
    if not make_raw or not model_raw: continue
    make_std = normalize_make(make_raw)
    model_std, _ = process_model(model_raw, make_std)
    key = f"{make_std}|{model_std}"
    if key not in agg:
        agg[key] = {"dev_status": "", "notes": ""}
    if len(row) > 3 and row[3] and not agg[key]["dev_status"]:
        agg[key]["dev_status"] = safe(row[3])
    if len(row) > 4 and row[4]:
        agg[key]["notes"] = safe(row[4])

# Count from submissions
sub_count = Counter()
for r2 in results:
    key = f"{r2[0]}|{r2[1]}"
    sub_count[key] += 1

output = [["Make", "Model", "提交人数", "是否开发", "备注"]]
for key, info in sorted(agg.items(), key=lambda x: -sub_count.get(x[0], 0)):
    make_std, model_std = key.split("|", 1)
    count = sub_count.get(key, 0)
    if count < 1: continue
    output.append([make_std, model_std, count, info["dev_status"], info["notes"]])

print(f"  Output models: {len(output)-1}")
print(f"  Total people: {sum(sub_count.values())}")

# Clear old data first
old_row_count = len(main_rows)
token = get_token()
if len(output) < old_row_count:
    empty_vals = [["" for _ in range(7)] for _ in range(old_row_count)]
    resp = write_range(token, MAIN_SHEET, f"A1:G{old_row_count}", empty_vals)
    print(f"  Cleared old data: {resp.get('code')}")

# Write new data (A-E columns)
token = get_token()
resp = write_range(token, MAIN_SHEET, f"A1:E{len(output)}", output)
print(f"  Write main sheet: {resp.get('code')} {resp.get('msg','')}")

print("\n✅ COMPLETE!")
print(f"\nTop 20 models by requests:")
for row in output[1:21]:
    print(f"  {row[0]} {row[1]}: {row[2]}人 [{row[3] or '待处理'}]")
