#!/usr/bin/env python3
"""处理 SubmissionsExport_19 (WOLFBOX Help Us Support Your Ride, 92条新提交)
1. 追加原始行到 源表-车型 (cJ2gXd)
2. 追加标准化行到 车型需求 (53652a)
"""
import requests, json, re, sys, openpyxl
from datetime import datetime

APP_ID = 'cli_a95e614746395cbd'
APP_SECRET = 'ZTPbyJlJNK0utcjkqgTazh8JDnLFhK4X'
TOKEN = 'W8Dxsti3Vhvo2itAuYDcULXyneb'
EXCEL = '/home/ecs-user/.openclaw/media/inbound/SubmissionsExport_19---2e9e345e-5efe-4082-ba1f-ade9d4007bb3.xlsx'

SRC_SHEET = 'cJ2gXd'   # 源表-车型, 14列
STD_SHEET = '53652a'   # 车型需求, 10列
SRC_START = 258
STD_START = 258

DRY = '--dry' in sys.argv
FIX_STD = '--fix-std' in sys.argv  # 只重写 车型需求 258-349 行（修复被覆盖的数据）

CAT_MAP = {
    'Power Running Boards': '电动踏板',
    'Retractable Bed Step': '后侧踏',
    'Powered Retractable Bed Cover': '电动后斗盖',
    'Side Mirrors': '后视镜',
}

MAKE_NORM = {
    'chevy': 'Chevy', 'chevrolet': 'Chevy', 'chev': 'Chevy', 'gm': 'GMC',
    'gmc': 'GMC', 'ram': 'Ram', 'dodge': 'Ram', 'chrysler': 'Ram',
    'jeep': 'Jeep', 'toyota': 'Toyota', 'lexus': 'Lexus',
    'honda': 'Honda', 'acura': 'Acura', 'hyundai': 'Hyundai', 'kia': 'Kia',
    'ford': 'Ford', 'lincoln': 'Lincoln', 'nissan': 'Nissan',
    'mazda': 'Mazda', 'subaru': 'Subaru', 'volkswagen': 'Volkswagen',
    'vw': 'Volkswagen', 'audi': 'Audi', 'bmw': 'BMW',
    'mercedes': 'Mercedes-Benz', 'mercedes-benz': 'Mercedes-Benz',
    'porsche': 'Porsche', 'volvo': 'Volvo', 'tesla': 'Tesla',
    'rivian': 'Rivian', 'cadillac': 'Cadillac', 'buick': 'Buick',
    'chrysler(dodge)': 'Ram', 'land rover': 'Land Rover',
    'jaguar': 'Jaguar', 'mini': 'MINI', 'genesis': 'Genesis',
    'hummer': 'GMC',
}

CAB_WORDS = ['crew cab', 'crewcab', 'crew', 'super cab', 'supercab',
             'extended cab', 'quad cab', 'mega cab', 'regular cab',
             'single cab', '2 door', '4 door', '4door', '2-door', '4-door',
             '4x4', '4wd', '2wd', 'awd', 'dually', 'short bed', 'long bed',
             'standard bed', '6.5 box', "6 1/2' bed", 'diesel', '5.3 liter',
             'v-8', 'v8', '4wd', 'box']

def txt(v):
    if v is None: return ''
    if isinstance(v, (int, float)): return str(int(v))
    return str(v).strip()

def norm_make(raw):
    r = txt(raw)
    if not r: return ''
    l = r.lower().strip()
    if l in MAKE_NORM: return MAKE_NORM[l]
    for k, v in sorted(MAKE_NORM.items(), key=lambda x: -len(x[0])):
        if k in l: return v
    return r.title()

def norm_model(make, raw):
    """返回 (Model, 清理后)"""
    m = txt(raw)
    m = re.sub(r'\s*\(.*?\)', ' ', m)
    m = re.sub(r'\s+', ' ', m).strip()
    if not m: return ''
    low = m.lower()

    # 品牌特定处理
    if make == 'Ford':
        if 'f350' in low or 'f-350' in low:
            if 'and' in low and 'f250' in low:
                return 'F-350 Super Duty & F-250 Super Duty'
            return 'F-350 Super Duty'
        if 'f250' in low or 'f-250' in low or 'super duty' in low:
            return 'F-250 Super Duty'
        if 'f150' in low or 'f-150' in low or 'f160' in low or 'f-160' in low:
            return 'F-150'
        if 'bronco raptor' in low or 'raptor' in low:
            return 'Bronco Raptor'
        if 'bronco' in low:
            return 'Bronco'
        if 'ranger' in low:
            return 'Ranger'
        if 'maverick' in low:
            return 'Maverick'
        if 'transit' in low:
            return 'Transit'
        if 'excursion' in low:
            return 'Excursion'
        return m.title()
    if make == 'Chevy':
        if '2500' in low: return 'Silverado 2500 HD'
        if '3500' in low: return 'Silverado 3500 HD'
        if '1500' in low: return 'Silverado 1500'
        if 'silverado' in low: return 'Silverado'
        if 'colorado' in low: return 'Colorado'
        if 'tahoe' in low: return 'Tahoe'
        if 'suburban' in low: return 'Suburban'
        if 'traverse' in low: return 'Traverse'
        if 'blazer' in low: return 'Blazer'
        if 'avalanche' in low: return 'Avalanche'
        if 'k10' in low: return 'K10'
        if 'camaro' in low: return 'Camaro'
        return m.title()
    if make == 'GMC':
        if '3500' in low: return 'Sierra 3500 HD'
        if '2500' in low: return 'Sierra 2500 HD'
        if 'sierra' in low: return 'Sierra 1500' if '1500' in low else 'Sierra'
        if 'yukon' in low:
            if 'xl' in low: return 'Yukon XL'
            return 'Yukon'
        if 'canyon' in low: return 'Canyon'
        if 'hummer' in low: return 'Hummer EV'
        return m.title()
    if make == 'Ram':
        for n in ('5500', '3500', '2500', '1500'):
            if n in low: return n
        if 'dodge' in low: return 'Dodge'
        if 'promaster' in low: return 'Promaster'
        if 'dakota' in low: return 'Dakota'
        return m.title()
    if make == 'Jeep':
        if 'wrangler' in low or 'jk' in low or 'jku' in low: return 'Wrangler'
        if 'gladiator' in low: return 'Gladiator'
        if 'grand cherokee' in low: return 'Grand Cherokee'
        if 'liberty' in low: return 'Liberty'
        return m.title()
    if make == 'Toyota':
        if 'landcruiser' in low or 'land cruiser' in low: return 'Land Cruiser'
        if 'tundra' in low: return 'Tundra'
        if 'tacoma' in low: return 'Tacoma'
        if 'highlander' in low: return 'Highlander'
        if 'sequoia' in low: return 'Sequoia'
        if 'fj cruiser' in low: return 'FJ Cruiser'
        return m.title()
    if make == 'Lexus':
        if 'nx' in low: return 'NX 300'
        if 'gx' in low: return 'GX 550'
        if 'rx' in low: return 'RX 350'
        return m.title()
    if make == 'Rivian':
        return 'R1T' if 'r1t' in low else 'R1S' if 'r1s' in low else m.title()
    if make == 'Honda':
        if 'ridgeline' in low: return 'Ridgeline'
        if 'pilot' in low: return 'Pilot'
        if 'odyssey' in low: return 'Odyssey'
        return m.title()
    if make == 'Cadillac':
        if 'escalade' in low: return 'Escalade'
        return m.title()
    if make == 'Nissan':
        if 'frontier' in low: return 'Frontier'
        if 'titan' in low: return 'Titan'
        return m.title()
    # 通用: 去掉cab/驱动等后缀后 title
    for w in CAB_WORDS:
        m = re.sub(r'\b' + re.escape(w) + r'\b', ' ', m, flags=re.IGNORECASE)
    m = re.sub(r'\s+', ' ', m).strip()
    if not m: return ''
    return ' '.join(w.title() if not w.isupper() else w for w in m.split())

def norm_year(raw, desc=''):
    y = txt(raw)
    mm = re.search(r'\b(19\d{2}|20\d{2})\b', y)
    if mm: return mm.group(1)
    mm = re.search(r'\b(19\d{2}|20\d{2})\b', desc)
    if mm: return mm.group(1)
    return ''

# 特殊行覆盖: ID -> (year, make, model, category, product_name)
OVERRIDES = {
    21395646: ('', 'Ram', '3500', '电动踏板', 'Power Running Boards'),
    21394087: ('2011', 'Chevy', 'Silverado 2500 HD', '电动踏板', 'Power Running Boards'),
    21393839: ('2015', 'Chevy', 'Silverado 2500 HD', '电动踏板', 'Power Running Boards'),
    21383556: ('1983', 'Ford', 'F-150', '电动踏板', 'Power Running Boards'),
    21383036: ('2005', 'Ram', 'Dodge', '电动踏板', 'Power Running Boards'),
    21381131: ('2018', 'Chevy', 'Silverado 3500 HD', '电动踏板', 'Power Running Boards'),
    21369197: ('1989', 'GMC', 'Sierra 1500', '电动踏板', 'Power Running Boards'),
    21367075: ('2013', 'Ram', '3500', '电动踏板', 'Power Running Boards'),
    21357315: ('2004', 'GMC', 'Yukon XL', '电动踏板', 'Power Running Boards'),
    21348792: ('2025', 'GMC', 'Yukon', '电动踏板', 'Power Running Boards'),
    21337168: ('2004', 'Ford', 'F-350 Super Duty & F-250 Super Duty', '电动踏板', 'Power Running Boards'),
    21316074: ('2019', 'Toyota', 'Tundra', '电动踏板', 'Power Running Boards'),
    21314771: ('2018', 'Jeep', 'Wrangler', '电动踏板', 'Power Running Boards'),
    21311744: ('2012', 'Ram', '2500', '后侧踏', 'Retractable Bed Step'),
    21302063: ('2018', 'Ram', '2500', '电动踏板', 'Power Running Boards'),
    21298089: ('1996', 'Ford', 'F-250 Super Duty', '电动踏板', 'Power Running Boards'),
    21296082: ('2018', 'Chevy', 'Silverado 2500 HD', '电动踏板', 'Power Running Boards'),
    21284041: ('2017', 'Chevy', 'Silverado 2500 HD', '电动踏板', 'Power Running Boards'),
    21281855: ('2024', 'Ford', 'Bronco', '电动踏板', 'Power Running Boards'),
    21280641: ('2006', 'Ram', '2500', '电动踏板', 'Power Running Boards'),
    21280088: ('2008', 'Ram', '3500', '电动踏板', 'Power Running Boards'),
    21276486: ('2015', 'Jeep', 'Wrangler', '电动踏板', 'Power Running Boards'),
    21271373: ('2021', 'Ram', '2500', '电动踏板', 'Power Running Boards'),
    21270103: ('2014', 'Ford', 'F-150', '硬折叠', 'Hard Cover'),
    21254323: ('2013', 'Ford', 'F-350 Super Duty', '电动踏板', 'Power Running Boards'),
    21254189: ('2018', 'GMC', 'Sierra 3500 HD', '电动踏板', 'Power Running Boards'),
    21247342: ('2018', 'Ram', '2500', '电动踏板', 'Power Running Boards'),
    21246199: ('2026', 'Chevy', 'Colorado', '电动踏板', 'Power Running Boards'),
    21246039: ('2008', 'Chevy', 'Silverado 1500', '电动踏板', 'Power Running Boards'),
    21242124: ('2016', 'Jeep', 'Wrangler', '电动踏板', 'Power Running Boards'),
    21234954: ('2019', 'GMC', 'Sierra 2500 HD', '电动踏板', 'Power Running Boards'),
    21225179: ('2016', 'GMC', 'Sierra 2500 HD', '电动踏板', 'Power Running Boards'),
    21219716: ('2012', 'Ram', '2500', '电动踏板', 'Power Running Boards'),
    21214764: ('2018', 'GMC', 'Sierra 2500 HD', '电动踏板', 'Power Running Boards'),
    21214009: ('2013', 'Toyota', 'Land Cruiser', '电动踏板', 'Power Running Boards'),
    21213784: ('2015', 'Ram', '2500', '后斗拓展架', 'Bed Rack'),
    21213617: ('2026', 'Lexus', 'GX 550', '电动踏板', 'Power Running Boards'),
    21212496: ('2018', 'Chevy', 'Silverado 2500 HD', '电动踏板', 'Power Running Boards'),
    21210014: ('2015', 'Chevy', 'Silverado 3500 HD', '电动后斗盖', 'Powered Retractable Bed Cover'),
    21208994: ('2004', 'Ford', 'F-350 Super Duty', '电动踏板', 'Power Running Boards'),
    21206370: ('2016', 'Ford', 'F-250 Super Duty', '电动踏板', 'Power Running Boards'),
    21202679: ('2005', 'GMC', 'Sierra 2500 HD', '电动踏板', 'Power Running Boards'),
    21200486: ('2023', 'Ford', 'Ranger', '后侧踏', 'Retractable Bed Step'),
    21197670: ('2022', 'Rivian', 'R1T', '电动踏板', 'Power Running Boards'),
    21195911: ('2026', 'Ford', 'Bronco Raptor', '电动踏板', 'Power Running Boards'),
    21337493: ('2026', 'Ram', '5500', '电动踏板', 'Power Running Boards'),
    21302942: ('2017', 'Ram', '3500', '后侧踏', 'Retractable Bed Step'),
    21298984: ('2016', 'GMC', 'Sierra 2500 HD', '后侧踏', 'Retractable Bed Step'),
    21349711: ('2014', 'Ford', 'F-150', '后侧踏', 'Retractable Bed Step'),
    21381176: ('1988', 'Toyota', 'Land Cruiser', '后侧踏', 'Retractable Bed Step'),
    21354733: ('2021', 'Lexus', 'NX 300', '后视镜', 'Side Mirrors'),
    21310692: ('2025', 'Ford', 'Ranger', '后侧踏', 'Retractable Bed Step'),
}

# ===== 读取 Excel =====
wb = openpyxl.load_workbook(EXCEL, read_only=True)
ws = wb['vehicle model submit']
rows = list(ws.iter_rows(values_only=True))
header = rows[0]
idx = {h: i for i, h in enumerate(header)}
data = rows[1:]
print(f'读取 {len(data)} 条提交')

PAGE = 'Help Us Support Your Ride – WOLFBOX Gear'

src_rows = []   # 14列
std_rows = []   # 10列
skipped = []
for r in data:
    rid = txt(r[idx['ID']])
    if not rid: 
        skipped.append(('no-id', r)); continue
    iid = int(rid)
    prod = txt(r[idx['Product name']])
    desc = txt(r[idx['Product description or any custom request']])
    raw_year = txt(r[idx['Vehicle Year']])
    raw_make = txt(r[idx['Vehicle Make']])
    raw_model = txt(r[idx['Vehicle Model']])

    if iid in OVERRIDES:
        year, make, model, cat, prod2 = OVERRIDES[iid]
        prod = prod2 or prod
    else:
        make = norm_make(raw_make)
        model = norm_model(make, raw_model)
        year = norm_year(raw_year, desc)
        cat = CAT_MAP.get(prod, '')

    # 原始行 (A-N)
    src_rows.append([
        rid, PAGE, '', txt(r[idx['IP Address']]),
        txt(r[idx['First Name']]), txt(r[idx['Last Name']]),
        txt(r[idx['Email']]), txt(r[idx['Phone']]),
        raw_year, raw_make, raw_model, prod, desc,
        txt(r[idx['created at']]),
    ])
    # 标准化行 (A-J): Year, Make, Model, 销售版本(留空), Product, Dscription, 产品分类, 是否处理, 处理时间, 更新日期
    std_rows.append([year, make, model, '', prod, desc, cat, '', '', ''])

print(f'原始行: {len(src_rows)}, 标准化行: {len(std_rows)}, 跳过: {len(skipped)}')
if skipped:
    print('跳过明细:', skipped)

# 校验没有空分类
no_cat = [(s[0], s[2]) for s in std_rows if not s[6]]
print('无分类的行:', no_cat if no_cat else '无 ✓')

if DRY:
    print('\n===== 标准化结果预览 =====')
    for s in std_rows:
        print(f"{s[0]:5s} {s[1]:8s} {s[2]:32s} {s[6]}")
    sys.exit(0)

# ===== 写入飞书 =====
if FIX_STD:
    r = requests.post("https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
                      json={"app_id": APP_ID, "app_secret": APP_SECRET}, timeout=10)
    t = r.json()['tenant_access_token']
    end_row = STD_START + len(std_rows) - 1
    rng = f"{STD_SHEET}!A{STD_START}:J{end_row}"
    url = f"https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{TOKEN}/values"
    body = {"valueRange": {"range": rng, "values": std_rows}}
    resp = requests.put(url, headers={"Authorization": f"Bearer {t}", "Content-Type": "application/json"},
                        json=body, timeout=30)
    d = resp.json()
    print(f"重写 {rng}: {d.get('code')} {d.get('msg')}")
    sys.exit(0)
r = requests.post("https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
                  json={"app_id": APP_ID, "app_secret": APP_SECRET}, timeout=10)
t = r.json()['tenant_access_token']

def append_rows(sheet, start_row, values):
    end_row = start_row + len(values) - 1
    ncols = len(values[0])
    col_end = chr(ord('A') + ncols - 1)
    rng = f"{sheet}!A{start_row}:{col_end}{end_row}"
    url = f"https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{TOKEN}/values"
    body = {"valueRange": {"range": rng, "values": values}}
    resp = requests.put(url, headers={"Authorization": f"Bearer {t}", "Content-Type": "application/json"},
                        json=body, timeout=30)
    d = resp.json()
    print(f"写入 {sheet} {rng}: {d.get('code')} {d.get('msg')}")
    return d.get('code') == 0

ok1 = append_rows(SRC_SHEET, SRC_START, src_rows)
ok2 = append_rows(STD_SHEET, STD_START, std_rows)
print('源表-车型 成功:', ok1, '| 车型需求 成功:', ok2)
