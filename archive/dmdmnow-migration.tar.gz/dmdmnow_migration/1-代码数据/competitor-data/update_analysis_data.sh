#!/bin/bash
cd /home/ecs-user/.openclaw/workspace/competitor-data
python3 feishu_fetch.py
