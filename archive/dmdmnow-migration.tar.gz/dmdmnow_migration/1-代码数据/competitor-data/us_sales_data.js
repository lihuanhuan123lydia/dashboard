// Auto-generated 2026-06-02
var US_SALES = [
 {
  "model": "Ford F-Series",
  "month": 62048,
  "month_ly": 72765,
  "change_pct": -14.73,
  "ytd": 221949,
  "ytd_ly": 263154,
  "ytd_change_pct": -15.66,
  "brand_group": "Ford"
 },
 {
  "model": "Honda CR-V",
  "month": 42667,
  "month_ly": 41483,
  "change_pct": 2.85,
  "ytd": 142104,
  "ytd_ly": 144808,
  "ytd_change_pct": -1.87,
  "brand_group": "Honda"
 },
 {
  "model": "Toyota Camry",
  "month": 33419,
  "month_ly": 28350,
  "change_pct": 17.88,
  "ytd": 111674,
  "ytd_ly": 98658,
  "ytd_change_pct": 13.19,
  "brand_group": "Toyota"
 },
 {
  "model": "Toyota RAV4",
  "month": 28212,
  "month_ly": 41957,
  "change_pct": -32.76,
  "ytd": 88081,
  "ytd_ly": 157359,
  "ytd_change_pct": -44.03,
  "brand_group": "Toyota"
 },
 {
  "model": "Toyota Corolla",
  "month": 25312,
  "month_ly": 22473,
  "change_pct": 12.63,
  "ytd": 87886,
  "ytd_ly": 77929,
  "ytd_change_pct": 12.78,
  "brand_group": "Toyota"
 },
 {
  "model": "Honda Civic",
  "month": 25040,
  "month_ly": 23553,
  "change_pct": 6.31,
  "ytd": 82640,
  "ytd_ly": 82529,
  "ytd_change_pct": 0.13,
  "brand_group": "Honda"
 },
 {
  "model": "Toyota Tacoma",
  "month": 24777,
  "month_ly": 23036,
  "change_pct": 7.56,
  "ytd": 94040,
  "ytd_ly": 82861,
  "ytd_change_pct": 13.49,
  "brand_group": "Toyota"
 },
 {
  "model": "Ford Explorer",
  "month": 21191,
  "month_ly": 20989,
  "change_pct": 0.96,
  "ytd": 82578,
  "ytd_ly": 68303,
  "ytd_change_pct": 20.9,
  "brand_group": "Ford"
 },
 {
  "model": "Subaru Forester",
  "month": 17837,
  "month_ly": 19330,
  "change_pct": -7.72,
  "ytd": 71989,
  "ytd_ly": 69195,
  "ytd_change_pct": 4.04,
  "brand_group": "Subaru"
 },
 {
  "model": "Ford Bronco",
  "month": 17073,
  "month_ly": 14400,
  "change_pct": 18.56,
  "ytd": 48270,
  "ytd_ly": 46995,
  "ytd_change_pct": 2.71,
  "brand_group": "Ford"
 },
 {
  "model": "Honda Accord",
  "month": 16071,
  "month_ly": 11277,
  "change_pct": 42.51,
  "ytd": 53388,
  "ytd_ly": 41889,
  "ytd_change_pct": 27.45,
  "brand_group": "Honda"
 },
 {
  "model": "Kia Sportage",
  "month": 15803,
  "month_ly": 16178,
  "change_pct": -2.32,
  "ytd": 60507,
  "ytd_ly": 57479,
  "ytd_change_pct": 5.27,
  "brand_group": "Hyundai"
 },
 {
  "model": "Subaru CrossTrek",
  "month": 15667,
  "month_ly": 14935,
  "change_pct": 4.9,
  "ytd": 54164,
  "ytd_ly": 58547,
  "ytd_change_pct": -7.49,
  "brand_group": "Subaru"
 },
 {
  "model": "Hyundai Elantra",
  "month": 14778,
  "month_ly": 13125,
  "change_pct": 12.59,
  "ytd": 47841,
  "ytd_ly": 46615,
  "ytd_change_pct": 2.63,
  "brand_group": "Hyundai"
 },
 {
  "model": "Ford Maverick",
  "month": 14196,
  "month_ly": 20183,
  "change_pct": -29.66,
  "ytd": 48157,
  "ytd_ly": 58198,
  "ytd_change_pct": -17.25,
  "brand_group": "Ford"
 },
 {
  "model": "Toyota Grand Highlander",
  "month": 14096,
  "month_ly": 13304,
  "change_pct": 5.95,
  "ytd": 48703,
  "ytd_ly": 39022,
  "ytd_change_pct": 24.81,
  "brand_group": "Toyota"
 },
 {
  "model": "Jeep Grand Cherokee",
  "month": 13370,
  "month_ly": 0,
  "change_pct": 10.3,
  "ytd": 53482,
  "ytd_ly": 48465,
  "ytd_change_pct": 10.3
 },
 {
  "model": "Kia Telluride",
  "month": 12577,
  "month_ly": 10860,
  "change_pct": 15.81,
  "ytd": 48505,
  "ytd_ly": 40703,
  "ytd_change_pct": 19.17,
  "brand_group": "Hyundai"
 },
 {
  "model": "Honda HR-V",
  "month": 12264,
  "month_ly": 13912,
  "change_pct": -11.85,
  "ytd": 43281,
  "ytd_ly": 54856,
  "ytd_change_pct": -21.1,
  "brand_group": "Honda"
 },
 {
  "model": "Toyota 4Runner",
  "month": 11929,
  "month_ly": 9261,
  "change_pct": 28.81,
  "ytd": 45173,
  "ytd_ly": 17696,
  "ytd_change_pct": 155.27,
  "brand_group": "Toyota"
 },
 {
  "model": "Hyundai Palisade",
  "month": 11324,
  "month_ly": 10502,
  "change_pct": 7.83,
  "ytd": 39028,
  "ytd_ly": 36737,
  "ytd_change_pct": 6.24,
  "brand_group": "Hyundai"
 },
 {
  "model": "Honda Pilot",
  "month": 11156,
  "month_ly": 12157,
  "change_pct": -8.23,
  "ytd": 42649,
  "ytd_ly": 44799,
  "ytd_change_pct": -4.8,
  "brand_group": "Honda"
 },
 {
  "model": "Toyota Corolla Cross",
  "month": 11042,
  "month_ly": 9765,
  "change_pct": 13.08,
  "ytd": 41135,
  "ytd_ly": 33885,
  "ytd_change_pct": 21.4,
  "brand_group": "Toyota"
 },
 {
  "model": "Subaru Outback",
  "month": 10552,
  "month_ly": 11501,
  "change_pct": -8.25,
  "ytd": 37626,
  "ytd_ly": 51435,
  "ytd_change_pct": -26.85,
  "brand_group": "Subaru"
 },
 {
  "model": "Ford Bronco Sport",
  "month": 10516,
  "month_ly": 11886,
  "change_pct": -11.53,
  "ytd": 45537,
  "ytd_ly": 45249,
  "ytd_change_pct": 0.64,
  "brand_group": "Ford"
 },
 {
  "model": "Mazda CX-5",
  "month": 10206,
  "month_ly": 12590,
  "change_pct": -18.94,
  "ytd": 45197,
  "ytd_ly": 47000,
  "ytd_change_pct": -3.84,
  "brand_group": "Mazda"
 },
 {
  "model": "Toyota Sienna",
  "month": 9448,
  "month_ly": 10315,
  "change_pct": -8.41,
  "ytd": 34100,
  "ytd_ly": 33876,
  "ytd_change_pct": 0.66,
  "brand_group": "Toyota"
 },
 {
  "model": "Kia Sorento",
  "month": 9109,
  "month_ly": 9659,
  "change_pct": -5.69,
  "ytd": 30619,
  "ytd_ly": 34776,
  "ytd_change_pct": -11.95,
  "brand_group": "Hyundai"
 },
 {
  "model": "Hyundai Santa Fe",
  "month": 9058,
  "month_ly": 12417,
  "change_pct": -27.05,
  "ytd": 42401,
  "ytd_ly": 43818,
  "ytd_change_pct": -3.23,
  "brand_group": "Hyundai"
 },
 {
  "model": "Mazda CX-50",
  "month": 8201,
  "month_ly": 7753,
  "change_pct": 5.78,
  "ytd": 37235,
  "ytd_ly": 31055,
  "ytd_change_pct": 19.9,
  "brand_group": "Mazda"
 },
 {
  "model": "Honda Odyssey",
  "month": 7449,
  "month_ly": 9677,
  "change_pct": -23.02,
  "ytd": 25924,
  "ytd_ly": 31779,
  "ytd_change_pct": -18.42,
  "brand_group": "Honda"
 },
 {
  "model": "Hyundai Sonata",
  "month": 7105,
  "month_ly": 6012,
  "change_pct": 18.18,
  "ytd": 21652,
  "ytd_ly": 21809,
  "ytd_change_pct": -0.72,
  "brand_group": "Hyundai"
 },
 {
  "model": "Ford Expedition",
  "month": 6751,
  "month_ly": 11116,
  "change_pct": -39.27,
  "ytd": 24305,
  "ytd_ly": 24598,
  "ytd_change_pct": -1.19,
  "brand_group": "Ford"
 },
 {
  "model": "Hyundai Kona",
  "month": 6706,
  "month_ly": 7914,
  "change_pct": -15.26,
  "ytd": 24097,
  "ytd_ly": 24932,
  "ytd_change_pct": -3.35,
  "brand_group": "Hyundai"
 },
 {
  "model": "Kia K5",
  "month": 6537,
  "month_ly": 6248,
  "change_pct": 4.63,
  "ytd": 25793,
  "ytd_ly": 21995,
  "ytd_change_pct": 17.27,
  "brand_group": "Hyundai"
 },
 {
  "model": "Toyota Highlander",
  "month": 6456,
  "month_ly": 6272,
  "change_pct": 2.93,
  "ytd": 22239,
  "ytd_ly": 18289,
  "ytd_change_pct": 21.6,
  "brand_group": "Toyota"
 },
 {
  "model": "Kia Carnival",
  "month": 6389,
  "month_ly": 6405,
  "change_pct": -0.25,
  "ytd": 25020,
  "ytd_ly": 20979,
  "ytd_change_pct": 19.26,
  "brand_group": "Hyundai"
 },
 {
  "model": "Lexus NX",
  "month": 5524,
  "month_ly": 7077,
  "change_pct": -21.94,
  "ytd": 18743,
  "ytd_ly": 25069,
  "ytd_change_pct": -25.23,
  "brand_group": "Toyota"
 },
 {
  "model": "Honda Passport",
  "month": 5447,
  "month_ly": 5457,
  "change_pct": -0.18,
  "ytd": 19492,
  "ytd_ly": 17155,
  "ytd_change_pct": 13.62,
  "brand_group": "Honda"
 },
 {
  "model": "Kia Seltos",
  "month": 5335,
  "month_ly": 4051,
  "change_pct": 31.7,
  "ytd": 20034,
  "ytd_ly": 15426,
  "ytd_change_pct": 29.87,
  "brand_group": "Hyundai"
 },
 {
  "model": "Ford Ranger",
  "month": 5245,
  "month_ly": 7006,
  "change_pct": -25.14,
  "ytd": 23020,
  "ytd_ly": 21919,
  "ytd_change_pct": 5.02,
  "brand_group": "Ford"
 },
 {
  "model": "Ford Escape",
  "month": 5050,
  "month_ly": 12903,
  "change_pct": -60.86,
  "ytd": 17447,
  "ytd_ly": 50260,
  "ytd_change_pct": -65.29,
  "brand_group": "Ford"
 },
 {
  "model": "Acura MDX",
  "month": 4211,
  "month_ly": 4230,
  "change_pct": -0.45,
  "ytd": 15139,
  "ytd_ly": 14871,
  "ytd_change_pct": 1.8,
  "brand_group": "Honda"
 },
 {
  "model": "Lincoln MKX/Nautilus",
  "month": 4135,
  "month_ly": 3841,
  "change_pct": 7.65,
  "ytd": 11812,
  "ytd_ly": 12505,
  "ytd_change_pct": -5.54,
  "brand_group": "Ford"
 },
 {
  "model": "Mazda CX-30",
  "month": 4067,
  "month_ly": 6261,
  "change_pct": -35.04,
  "ytd": 11965,
  "ytd_ly": 27293,
  "ytd_change_pct": -56.16,
  "brand_group": "Mazda"
 },
 {
  "model": "Hyundai Ioniq 5",
  "month": 3603,
  "month_ly": 3411,
  "change_pct": 5.63,
  "ytd": 13393,
  "ytd_ly": 12022,
  "ytd_change_pct": 11.4,
  "brand_group": "Hyundai"
 },
 {
  "model": "Honda Ridgeline",
  "month": 3602,
  "month_ly": 4274,
  "change_pct": -15.72,
  "ytd": 14582,
  "ytd_ly": 15225,
  "ytd_change_pct": -4.22,
  "brand_group": "Honda"
 },
 {
  "model": "Subaru Ascent",
  "month": 3472,
  "month_ly": 3758,
  "change_pct": -7.61,
  "ytd": 12647,
  "ytd_ly": 14837,
  "ytd_change_pct": -14.76,
  "brand_group": "Subaru"
 },
 {
  "model": "Mazda CX-90",
  "month": 3286,
  "month_ly": 5402,
  "change_pct": -39.17,
  "ytd": 12365,
  "ytd_ly": 20555,
  "ytd_change_pct": -39.84,
  "brand_group": "Mazda"
 },
 {
  "model": "Mazda Mazda3",
  "month": 3235,
  "month_ly": 3236,
  "change_pct": -0.03,
  "ytd": 12544,
  "ytd_ly": 12587,
  "ytd_change_pct": -0.34,
  "brand_group": "Mazda"
 },
 {
  "model": "Toyota Land Cruiser",
  "month": 3226,
  "month_ly": 4527,
  "change_pct": -28.74,
  "ytd": 11309,
  "ytd_ly": 19943,
  "ytd_change_pct": -43.29,
  "brand_group": "Toyota"
 },
 {
  "model": "Toyota bZ4X",
  "month": 3001,
  "month_ly": 1064,
  "change_pct": 182.05,
  "ytd": 13030,
  "ytd_ly": 6674,
  "ytd_change_pct": 95.24,
  "brand_group": "Toyota"
 },
 {
  "model": "Lexus IS",
  "month": 2998,
  "month_ly": 1984,
  "change_pct": 51.11,
  "ytd": 8043,
  "ytd_ly": 6763,
  "ytd_change_pct": 18.93,
  "brand_group": "Toyota"
 },
 {
  "model": "Ford E-Series",
  "month": 2888,
  "month_ly": 3699,
  "change_pct": -21.92,
  "ytd": 12247,
  "ytd_ly": 13378,
  "ytd_change_pct": -8.45,
  "brand_group": "Ford"
 },
 {
  "model": "Genesis GV70",
  "month": 2837,
  "month_ly": 2634,
  "change_pct": 7.71,
  "ytd": 11071,
  "ytd_ly": 9398,
  "ytd_change_pct": 17.8,
  "brand_group": "Hyundai"
 },
 {
  "model": "Ford Mustang Mach E",
  "month": 2670,
  "month_ly": 2927,
  "change_pct": -8.78,
  "ytd": 7270,
  "ytd_ly": 14534,
  "ytd_change_pct": -49.98,
  "brand_group": "Ford"
 },
 {
  "model": "Acura Integra",
  "month": 2591,
  "month_ly": 2038,
  "change_pct": 27.13,
  "ytd": 8468,
  "ytd_ly": 6718,
  "ytd_change_pct": 26.05,
  "brand_group": "Honda"
 },
 {
  "model": "Acura RDX",
  "month": 2538,
  "month_ly": 3741,
  "change_pct": -32.16,
  "ytd": 9210,
  "ytd_ly": 12663,
  "ytd_change_pct": -27.27,
  "brand_group": "Honda"
 },
 {
  "model": "Toyota Sequoia",
  "month": 2418,
  "month_ly": 2602,
  "change_pct": -7.07,
  "ytd": 8800,
  "ytd_ly": 7709,
  "ytd_change_pct": 14.15,
  "brand_group": "Toyota"
 },
 {
  "model": "Acura ADX",
  "month": 2403,
  "month_ly": 970,
  "change_pct": 147.73,
  "ytd": 10267,
  "ytd_ly": 1148,
  "ytd_change_pct": 794.34,
  "brand_group": "Honda"
 },
 {
  "model": "Toyota Prius",
  "month": 2301,
  "month_ly": 6849,
  "change_pct": -66.4,
  "ytd": 12038,
  "ytd_ly": 23502,
  "ytd_change_pct": -48.78,
  "brand_group": "Toyota"
 },
 {
  "model": "Genesis GV80",
  "month": 2128,
  "month_ly": 1920,
  "change_pct": 10.83,
  "ytd": 8504,
  "ytd_ly": 6709,
  "ytd_change_pct": 26.76,
  "brand_group": "Hyundai"
 },
 {
  "model": "Lincoln Aviator",
  "month": 2053,
  "month_ly": 2795,
  "change_pct": -26.55,
  "ytd": 8319,
  "ytd_ly": 7564,
  "ytd_change_pct": 9.98,
  "brand_group": "Ford"
 },
 {
  "model": "Toyota Crown Signia",
  "month": 2002,
  "month_ly": 1910,
  "change_pct": 4.82,
  "ytd": 7295,
  "ytd_ly": 9818,
  "ytd_change_pct": -25.7,
  "brand_group": "Toyota"
 },
 {
  "model": "Hyundai Santa Cruz",
  "month": 1885,
  "month_ly": 2494,
  "change_pct": -24.42,
  "ytd": 6429,
  "ytd_ly": 9142,
  "ytd_change_pct": -29.68,
  "brand_group": "Hyundai"
 },
 {
  "model": "Lexus GX",
  "month": 1868,
  "month_ly": 3959,
  "change_pct": -52.82,
  "ytd": 10433,
  "ytd_ly": 13198,
  "ytd_change_pct": -20.95,
  "brand_group": "Toyota"
 },
 {
  "model": "Lincoln Navigator",
  "month": 1600,
  "month_ly": 2745,
  "change_pct": -41.71,
  "ytd": 5922,
  "ytd_ly": 6803,
  "ytd_change_pct": -12.95,
  "brand_group": "Ford"
 },
 {
  "model": "Honda Prologue",
  "month": 1508,
  "month_ly": 1847,
  "change_pct": -18.35,
  "ytd": 4827,
  "ytd_ly": 11408,
  "ytd_change_pct": -57.69,
  "brand_group": "Honda"
 },
 {
  "model": "Kia Niro",
  "month": 1491,
  "month_ly": 2350,
  "change_pct": -36.55,
  "ytd": 8946,
  "ytd_ly": 7468,
  "ytd_change_pct": 19.79,
  "brand_group": "Hyundai"
 },
 {
  "model": "Subaru Impreza",
  "month": 1444,
  "month_ly": 2559,
  "change_pct": -43.57,
  "ytd": 5356,
  "ytd_ly": 10466,
  "ytd_change_pct": -48.82,
  "brand_group": "Subaru"
 },
 {
  "model": "Kia EV9",
  "month": 1349,
  "month_ly": 232,
  "change_pct": 481.47,
  "ytd": 4089,
  "ytd_ly": 3988,
  "ytd_change_pct": 2.53,
  "brand_group": "Hyundai"
 },
 {
  "model": "Lincoln Corsair / MKC",
  "month": 1339,
  "month_ly": 2234,
  "change_pct": -40.06,
  "ytd": 6684,
  "ytd_ly": 8474,
  "ytd_change_pct": -21.12,
  "brand_group": "Ford"
 },
 {
  "model": "Lexus RZ",
  "month": 1214,
  "month_ly": 651,
  "change_pct": 86.48,
  "ytd": 5670,
  "ytd_ly": 2105,
  "ytd_change_pct": 169.36,
  "brand_group": "Toyota"
 },
 {
  "model": "Mazda MX-5 Miata",
  "month": 1163,
  "month_ly": 727,
  "change_pct": 59.97,
  "ytd": 2858,
  "ytd_ly": 3173,
  "ytd_change_pct": -9.93,
  "brand_group": "Mazda"
 },
 {
  "model": "Subaru Solterra",
  "month": 1128,
  "month_ly": 949,
  "change_pct": 18.86,
  "ytd": 4169,
  "ytd_ly": 4080,
  "ytd_change_pct": 2.18,
  "brand_group": "Subaru"
 },
 {
  "model": "Genesis G70",
  "month": 991,
  "month_ly": 803,
  "change_pct": 23.41,
  "ytd": 3410,
  "ytd_ly": 2794,
  "ytd_change_pct": 22.05,
  "brand_group": "Hyundai"
 },
 {
  "model": "Mazda CX-70",
  "month": 970,
  "month_ly": 1691,
  "change_pct": -42.64,
  "ytd": 3436,
  "ytd_ly": 6313,
  "ytd_change_pct": -45.57,
  "brand_group": "Mazda"
 },
 {
  "model": "Kia EV6",
  "month": 728,
  "month_ly": 656,
  "change_pct": 10.98,
  "ytd": 2751,
  "ytd_ly": 4394,
  "ytd_change_pct": -37.39,
  "brand_group": "Hyundai"
 },
 {
  "model": "Toyota Crown",
  "month": 721,
  "month_ly": 980,
  "change_pct": -26.43,
  "ytd": 3662,
  "ytd_ly": 3216,
  "ytd_change_pct": 13.87,
  "brand_group": "Toyota"
 },
 {
  "model": "Lexus LX",
  "month": 636,
  "month_ly": 767,
  "change_pct": -17.08,
  "ytd": 2484,
  "ytd_ly": 2471,
  "ytd_change_pct": 0.53,
  "brand_group": "Toyota"
 },
 {
  "model": "Toyota GR86",
  "month": 486,
  "month_ly": 990,
  "change_pct": -50.91,
  "ytd": 2532,
  "ytd_ly": 3767,
  "ytd_change_pct": -32.78,
  "brand_group": "Toyota"
 },
 {
  "model": "Toyota Supra",
  "month": 344,
  "month_ly": 177,
  "change_pct": 94.35,
  "ytd": 1263,
  "ytd_ly": 598,
  "ytd_change_pct": 111.2,
  "brand_group": "Toyota"
 },
 {
  "model": "Subaru BRZ",
  "month": 283,
  "month_ly": 331,
  "change_pct": -14.5,
  "ytd": 1086,
  "ytd_ly": 1133,
  "ytd_change_pct": -4.15,
  "brand_group": "Subaru"
 },
 {
  "model": "Genesis G80",
  "month": 282,
  "month_ly": 320,
  "change_pct": -11.88,
  "ytd": 1141,
  "ytd_ly": 1234,
  "ytd_change_pct": -7.54,
  "brand_group": "Hyundai"
 },
 {
  "model": "Subaru Legacy",
  "month": 247,
  "month_ly": 1876,
  "change_pct": -86.83,
  "ytd": 2035,
  "ytd_ly": 7676,
  "ytd_change_pct": -73.49,
  "brand_group": "Subaru"
 },
 {
  "model": "Hyundai Ioniq 6",
  "month": 198,
  "month_ly": 1106,
  "change_pct": -82.1,
  "ytd": 1027,
  "ytd_ly": 4424,
  "ytd_change_pct": -76.79,
  "brand_group": "Hyundai"
 },
 {
  "model": "Lexus ES",
  "month": 183,
  "month_ly": 3377,
  "change_pct": -94.58,
  "ytd": 3227,
  "ytd_ly": 12575,
  "ytd_change_pct": -74.34,
  "brand_group": "Toyota"
 },
 {
  "model": "Kia Soul",
  "month": 171,
  "month_ly": 5069,
  "change_pct": -96.63,
  "ytd": 3470,
  "ytd_ly": 16346,
  "ytd_change_pct": -78.77,
  "brand_group": "Hyundai"
 },
 {
  "model": "Lexus LC",
  "month": 92,
  "month_ly": 103,
  "change_pct": -10.68,
  "ytd": 416,
  "ytd_ly": 622,
  "ytd_change_pct": -33.12,
  "brand_group": "Toyota"
 },
 {
  "model": "Genesis GV60",
  "month": 89,
  "month_ly": 192,
  "change_pct": -53.65,
  "ytd": 206,
  "ytd_ly": 902,
  "ytd_change_pct": -77.16,
  "brand_group": "Hyundai"
 },
 {
  "model": "Genesis G90",
  "month": 29,
  "month_ly": 116,
  "change_pct": -75.0,
  "ytd": 341,
  "ytd_ly": 539,
  "ytd_change_pct": -36.73,
  "brand_group": "Hyundai"
 },
 {
  "model": "Lexus RC",
  "month": 26,
  "month_ly": 135,
  "change_pct": -80.74,
  "ytd": 226,
  "ytd_ly": 587,
  "ytd_change_pct": -61.5,
  "brand_group": "Toyota"
 },
 {
  "model": "Lexus LS",
  "month": 1,
  "month_ly": 111,
  "change_pct": -99.1,
  "ytd": 144,
  "ytd_ly": 531,
  "ytd_change_pct": -72.88,
  "brand_group": "Toyota"
 },
 {
  "model": "Hyundai Nexo",
  "month": 0,
  "month_ly": 1,
  "change_pct": -100.0,
  "ytd": 0,
  "ytd_ly": 1,
  "ytd_change_pct": -100.0,
  "brand_group": "Hyundai"
 }
];
