#!/usr/bin/env python3
"""
处理新批次客户车型提交数据 (2026-07-09 批次, 29条)
"""
import os, sys, json, re, time, requests, openpyxl
from datetime import datetime
from collections import Counter

with open('/tmp/_secret.txt') as f:
    SECRET = ***
with open('/tmp/_spreadsheet_token.txt') as f:
    SPREADSHEET_TOKEN = ***
with open('/tmp/_feishu_bitable.txt') as f:
    BITTABLE_TOKEN = ***
APP_ID = 'cli_a95e614746395cbd'
SHEET_S = '1sCyzd'  # 站内-客户提交
SHEET_C = '0iCDMN'  # 站内-车型提交人数

EXCEL = '/home/ecs-user/.openclaw/media/inbound/SubmissionsExport_15---719887a0-2da8-4fae-ae20-e11dc759cf7a.xlsx'

def txt(v):
    if v is None: return ''
    if isinstance(v, (int, float)): return str(int(v))
    if isinstance(v, list): return ''
    return str(v).strip()

def norm_make(raw):
    MAKE = {
        'chevy':'Chevrolet','chevrolet':'Chevrolet','chev':'Chevrolet',
        'gmc':'GMC','ram':'Ram','dodge':'Ram',
        'jeep':'Jeep','toyota':'Toyota','lexus':'Lexus',
        'honda':'Honda','acura':'Acura','hyundai':'Hyundai',
        'kia':'Kia','ford':'Ford','lincoln':'Lincoln',
        'nissan':'Nissan','mazda':'Mazda','subaru':'Subaru',
        'volkswagen':'Volkswagen','vw':'Volkswagen',
        'audi':'Audi','bmw':'BMW','mercedes':'Mercedes-Benz',
        'chrysler':'Chrysler','buick':'Buick','cadillac':'Cadillac',
        'tesla':'Tesla','rivian':'Rivian',
        'land rover':'Land Rover','jaguar':'Jaguar',
        'porsche':'Porsche','volvo':'Volvo',
        'mini':'MINI','genesis':'Genesis',
    }
    r = raw.strip()
    if not r: return ''
    l = r.lower()
    if l in MAKE: return MAKE[l]
    for k,v in sorted(MAKE.items(), key=lambda x: -len(x[0])):
        if k in l: return v
    return r.title()

def norm_model(model_str):
    """Clean and normalize model, return (model, trim)"""
    m = model_str.strip() if model_str else ''
    m = re.sub(r'\s*\(.*?\)', '', m).strip()
    m = re.sub(r'\s+', ' ', m).strip()
    if not m: return '', ''
    
    # Known trim patterns (ordered by length desc to match longer first)
    trim_patterns = [
        # Ford
        ('xlt','XLT'),('xlt premium','XLT Premium'),
        ('lariat','Lariat'),('king ranch','King Ranch'),
        ('platinum','Platinum'),('limited','Limited'),
        ('rst','RST'),('stx','STX'),('st','ST'),
        # Chevy/GMC
        ('ltz','LTZ'),('lt','LT'),('ls','LS'),
        ('trail boss','Trail Boss'),('high country','High Country'),
        ('z71','Z71'),('zr2','ZR2'),
        ('denali','Denali'),('at4','AT4'),('sle','SLE'),('slt','SLT'),
        ('elevation','Elevation'),('wt','WT'),('custom','Custom'),
        ('premier','Premier'),('rs','RS'),
        # Ram/Dodge
        ('big horn','Big Horn'),('lone star','Lone Star'),
        ('laramie','Laramie'),('longhorn','Longhorn'),
        ('tradesman','Tradesman'),('rebel','Rebel'),
        ('r/t','R/T'),('sxt','SXT'),('gt','GT'),
        ('rt plus','R/T Plus'),('citadel','Citadel'),
        # Toyota
        ('sr5','SR5'),('sr','SR'),
        ('trd pro','TRD Pro'),('trd sport','TRD Sport'),
        ('trd off-road','TRD Off-Road'),
        ('1794','1794 Edition'),('capstone','Capstone'),
        # Honda
        ('ex-l','EX-L'),('ex-t','EX-T'),('ex','EX'),
        ('lx','LX'),('elite','Elite'),
        # Hyundai/Kia
        ('calligraphy','Calligraphy'),('sel plus','SEL Plus'),
        ('sel','SEL'),('se','SE'),
        ('sx prestige','SX Prestige'),('sx-prestige','SX Prestige'),
        ('sx','SX'),('prestige','Prestige'),
        ('x-line','X-Line'),
        ('nightfall','Nightfall Edition'),
        # Jeep
        ('laredo','Laredo'),('trailhawk','Trailhawk'),
        ('overland','Overland'),('summit','Summit'),
        ('altitude','Altitude'),('high altitude','High Altitude'),
        ('sahara','Sahara'),('rubicon','Rubicon'),
        # Subaru
        ('wilderness','Wilderness'),('onyx','Onyx'),
        # Lincoln
        ('reserve','Reserve'),('premiere','Premiere'),
        ('black label','Black Label'),
        # Audi/VW
        ('premium plus','Premium Plus'),('prestige','Prestige'),
        ('premium','Premium'),('r-line','R-Line'),
        # BMW
        ('xdrive','xDrive'),('sdrive','sDrive'),
        # Mazda
        ('grand touring','Grand Touring'),('signature','Signature'),
        ('carbon','Carbon'),('turbo','Turbo'),
        # Nissan
        ('pro-4x','Pro-4X'),('pro 4x','Pro-4X'),('pro4x','Pro-4X'),
        # Buick
        ('avenir','Avenir'),('essence','Essence'),('preferred','Preferred'),
        # Toyota/Lexus
        ('f sport','F Sport'),('f-sport','F Sport'),
        ('luxury','Luxury'),
        # Trim S
        ('s-line','S-Line'),('st-line','ST-Line'),
        ('sport','Sport'),
    ]
    
    # Common powertrain suffixes to keep in model
    powertrain_kw = ['hybrid','phev','ev']
    
    lower = m.lower().strip()
    
    # First check for Hybrid/EV to preserve
    has_powertrain = False
    pt_suffix = ''
    for pt in powertrain_kw:
        if pt in lower:
            has_powertrain = True
            pt_suffix = ' Hybrid' if pt == 'hybrid' else pt.upper()
            break
    
    # Remove Hybrid/EV temporarily for trim matching
    search = lower
    if has_powertrain:
        for pt in powertrain_kw:
            search = re.sub(r'\b' + re.escape(pt) + r'\b', '', search, flags=re.IGNORECASE).strip()
        search = re.sub(r'\s+', ' ', search).strip()
    
    # Try to find trim
    found_trim = ''
    for pattern, display in sorted(trim_patterns, key=lambda x: -len(x[0])):
        if pattern in search:
            # Check word boundary
            idx = search.index(pattern)
            end = idx + len(pattern)
            if (idx == 0 or not search[idx-1].isalnum()) and \
               (end >= len(search) or not search[end].isalnum()):
                found_trim = display
                break
    
    # Build final model name
    base = lower
    if found_trim:
        # Remove trim from model string
        base = re.sub(r'\s*' + re.escape(found_trim.lower()) + r'\s*', ' ', search, flags=re.IGNORECASE).strip()
        base = re.sub(r'\s+', ' ', base).strip()
    
    # Reconstruct
    words = base.split()
    titled = ' '.join(w.title() if not w.isupper() else w for w in words)
    if has_powertrain:
        titled += pt_suffix
    
    if found_trim == 'L' and titled.endswith(' L'):
        return titled[:-2].strip(), 'L'
    
    return titled, found_trim

def try_detect_trim(model_str):
    """For entries where model is clearly trim-only (like 'XLT')"""
    return norm_model('Fakemodel ' + model_str)[1]

def get_token():
    r = requests.post('https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal',
                      json={'app_id': APP_ID, 'app_secret': SECRET}, timeout=10)
    return r.json()['tenant_access_token']

def load_kanban():
    """Load kanban progress"""
    token = get_token()
    records = []
    pt = None
    while True:
        url = f'https://open.feishu.cn/open-apis/bitable/v1/apps/{BITTABLE_TOKEN}/tables/tbl3bbHPe7EeIV1D/records?page_size=100'
        if pt: url += f'&page_token={pt}'
        r = requests.get(url, headers={'Authorization': f'Bearer {token}'}, timeout=15)
        d = r.json()
        records.extend(d['data']['items'])
        if not d['data'].get('has_more'): break
        pt = d['data']['page_token']
        time.sleep(0.2)
    
    kb = {}
    for rec in records:
        f = rec['fields']
        b = (f.get('品牌','') or '').strip()
        mo = (f.get('车型','') or '').strip()
        if not b or not mo: continue
        nl = f.get('当前节点',[]) or []
        nt = nl[0].get('text','') if nl else ''
        sl = f.get('当前节点状态',[]) or []
        st = sl[0].get('text','') if sl else ''
        pr = f.get('优先级','') or ''
        ll = f.get('计划上市时间',[]) or []
        lt = ll[0].get('text','') if ll else ''
        
        ds = '已开发'
        if nt in ('已上市','上市','生产','下单','核车','修模','开模','寄样'):
            ds = '已开发'
        if st == '🏁已上市':
            ds = '已上线'
        elif nt in ('立项','扫描','产品设计'):
            ds = '已开发'
        else:
            ds = ''
        
        kb[f'{b.lower()}|{mo.lower()}'] = {
            'status': ds, 'node': nt, 'node_status': st,
            'priority': pr, 'launch': lt,
        }
    return kb

# ===== MAIN =====
def main():
    print("="*60)
    print(f"🚀 处理新批次数据 ({datetime.now().strftime('%H:%M:%S')})")
    print("="*60)
    
    # 1. Read Excel
    print("\n📂 读取Excel...")
    wb = openpyxl.load_workbook(EXCEL)
    ws = wb['Vehicle Collection']
    excel = []
    for row in list(ws.iter_rows(values_only=True))[1:]:
        if not row[0]: continue
        excel.append({
            'make': txt(row[6] or row[7]),
            'model': txt(row[8]),
            'year': txt(row[9]).split('.')[0],
            'note': txt(row[10]),
            'email': txt(row[5]).lower(),
            'created': txt(row[12]),
        })
    print(f"  {len(excel)} 条")
    
    # 2. Read Feishu
    print("📖 读取飞书现有数据...")
    token = get_token()
    
    # Read just enough to cover data
    feishu = []
    for start in range(1, 36500, 2000):
        end = min(start+1999, 36500)
        url = f'https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SPREADSHEET_TOKEN}/values/{SHEET_S}!A{start}:J{end}'
        r = requests.get(url, headers={'Authorization': f'Bearer {token}'}, timeout=30)
        rows = r.json()['data']['valueRange']['values']
        feishu.extend([(start+i, row) for i,row in enumerate(rows)])
        time.sleep(0.3)
    
    # Build lookup + find last row
    lookup = set()
    last_row = 0
    for rn, row in feishu:
        if rn == 1: continue  # header
        if len(row) >= 5 and any(row[c] and str(row[c]).strip() for c in range(5)):
            last_row = rn
            mk = txt(row[0]).lower() if len(row)>0 else ''
            md = txt(row[1]).lower() if len(row)>1 else ''
            yr = txt(row[3]) if len(row)>3 else ''
            em = ''
            if len(row)>7:
                e = row[7]
                em = (e if isinstance(e,str) else (e.get('text','') if isinstance(e,dict) else '')).strip().lower()
            lookup.add(f'{mk}|{md}|{yr}|{em}')
    
    print(f"  最后行: {last_row}, 已有: {len(lookup)}")
    
    # 3. Find new
    print("🔍 查找新增...")
    new = []
    for d in excel:
        if not d['make'] or not d['model']: continue
        key = f'{norm_make(d["make"]).lower()}|{norm_model(d["model"])[0].lower()}|{d["year"]}|{d["email"]}'
        key2 = f'{d["make"].lower()}|{d["model"].lower()}|{d["year"]}|{d["email"]}'
        if key not in lookup and key2 not in lookup:
            new.append(d)
    
    print(f"  新增: {len(new)} 条")
    if new:
        for d in new:
            print(f'    {d["make"]:20s} {d["model"]:35s} {d["year"]:5s} {d["email"]:30s}')
    
    if not new:
        print("✅ 无新增，跳过")
        return
    
    # 4. Normalize & write
    print("🏷️ 规整数据并写入...")
    prepared = []
    for d in new:
        make = norm_make(d['make'])
        model, trim = norm_model(d['model'])
        year = d['year']
        if not model:
            model, trim = d['model'], ''
        
        # Handle case where model field is just a trim
        if not make:
            make = d['make'].title()
        
        row = [make, model, trim, year, d['note'], '', '', d['email'], d['created']]
        prepared.append(row)
    
    print(f"  准备写入 {len(prepared)} 行")
    start_row = last_row + 1
    end_row = last_row + len(prepared)
    
    body = {'valueRange': {
        'range': f'{SHEET_S}!A{start_row}:I{end_row}',
        'values': prepared
    }}
    url = f'https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SPREADSHEET_TOKEN}/values'
    r = requests.put(url, headers={'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'},
                     json=body, timeout=30)
    if r.json().get('code') == 0:
        print(f"  ✅ 已写入行 {start_row}-{end_row}")
    else:
        print(f"  ✗ 写入失败: {r.json()}")
        return
    
    # 5. Update counts
    print("\n📊 更新人数表...")
    
    # Load kanban
    kanban = load_kanban()
    print(f"  📋 看板 {len(kanban)} 个车型")
    
    # Re-read all submissions for accurate counts
    print("  重新统计提交人数...")
    all_subs = []
    for start in range(1, 36500, 2000):
        end = min(start+1999, 36500)
        url = f'https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SPREADSHEET_TOKEN}/values/{SHEET_S}!A{start}:D{end}'
        r = requests.get(url, headers={'Authorization': f'Bearer {token}'}, timeout=30)
        rows = r.json()['data']['valueRange']['values']
        all_subs.extend(rows[(0 if start==1 else 0):])
        time.sleep(0.3)
    
    counts = Counter()
    for row in all_subs[1:]:
        if len(row) < 4 or not any(row[c] and str(row[c]).strip() for c in range(4)): continue
        mk = txt(row[0]); md = txt(row[1])
        if not mk or not md: continue
        counts[f'{mk}|{md}'] += 1
    print(f"  去重车型: {len(counts)} 个, 总人次: {sum(counts.values())}")
    
    # Read existing count sheet (preserve manual edits)
    url = f'https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SPREADSHEET_TOKEN}/values/{SHEET_C}!A1:G3000'
    r = requests.get(url, headers={'Authorization': f'Bearer {token}'}, timeout=15)
    try:
        existing = r.json()['data']['valueRange']['values']
    except:
        existing = []
    
    existing_progress = {}
    for row in existing[1:]:
        if not row or len(row) < 2: continue
        mk = txt(row[0]); md = txt(row[1])
        if not mk or not md: continue
        existing_progress[f'{mk}|{md}'] = {
            's': row[3] if len(row)>3 else '',
            'n1': row[4] if len(row)>4 else '',
            'n2': row[5] if len(row)>5 else '',
            'c': row[6] if len(row)>6 else '',
        }
    
    # Build new sorted list
    sorted_m = sorted(counts.items(), key=lambda x: -x[1])
    new_rows = [['Make','Model','提交人数','是否开发','备注','更新时间','竞品上线']]
    
    p_count = 0; n_count = 0; k_count = 0
    for key, cnt in sorted_m:
        mk, md = key.split('|', 1)
        if key in existing_progress:
            pr = existing_progress[key]
            status = pr['s']; note = pr['n1']; note2 = pr['n2']; comp = pr['c']
            p_count += 1
        else:
            status = ''; note = ''; note2 = ''; comp = ''
            n_count += 1
        
        kk = f'{mk.lower()}|{md.lower()}'
        if kk in kanban:
            kb = kanban[kk]
            if kb['status'] and not status:
                status = kb['status']; k_count += 1
            if kb['node']:
                ni = f"看板:{kb['node']}|{kb['priority']}"
                if kb['launch']: ni += f"|上市:{kb['launch']}"
                if note2:
                    if ni not in note2: note2 += f" | {ni}"
                else: note2 = ni
        
        new_rows.append([mk, md, cnt, status, note, note2, comp])
    
    print(f"  保留: {p_count} | 新增: {n_count} | 看板匹配: {k_count}")
    
    # Write
    body = {'valueRange': {'range': f'{SHEET_C}!A1:G{len(new_rows)}', 'values': new_rows}}
    r = requests.put(url, headers={'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'},
                     json=body, timeout=60)
    if r.json().get('code') == 0:
        print(f"  ✅ 人数表已更新 ({len(new_rows)-1} 条)")
    else:
        print(f"  ✗ 写入失败: {r.json()}")
    
    # 6. Trigger dashboard update
    print("\n🌐 触发面板更新...")
    try:
        r = requests.post('https://webhook.dmdmnow.com/refresh-3w', timeout=5)
        print(f"  webhook: {r.status_code}")
    except:
        print("  ⚠ webhook 超时")
    
    print(f"\n✅ 完成! 新增 {len(new)} 条提交记录")
    
    # Save new script location for next time
    updated_ts = datetime.now().strftime('%Y/%m/%d %H:%M')
    print(f"  📊 面板将在同步后更新 → https://dashboard.dmdmnow.com/3w/")

if __name__ == '__main__':
    main()
