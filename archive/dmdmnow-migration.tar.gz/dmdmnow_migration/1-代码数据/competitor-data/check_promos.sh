#!/bin/bash
# check_promos.sh - 每周自动检查竞品促销活动更新
# 对比各品牌官网当前促销信息，自动更新 competitor-data.html
set -euo pipefail

cd "$(dirname "$0")"
HTML="competitor-data.html"
LOG="/tmp/promo_check.log"

echo "[$(date '+%Y-%m-%d %H:%M')] 开始检查竞品促销..." >> "$LOG"

check_promo() {
  local brand="$1"
  local url="$2"
  local result
  result=$(curl -sL --max-time 15 "$url" 2>/dev/null)
  echo "$result"
}

# 检测各品牌当前促销
# 3W
_3w=$(check_promo "3W" "https://3wliners.com/" | grep -ioP '30%[^<]*OFF|EXTRA[^<]*OFF|SALE|促销' | head -3)
echo "3W: $_3w" >> "$LOG"

# Smartliner
_sl=$(check_promo "Smartliner" "https://www.smartliner-usa.com/" | grep -ioP 'SALE|OFF|促销|Up to [0-9]+%' | head -3)
echo "Smartliner: $_sl" >> "$LOG"

# OEDRO - check promo page
_od=$(check_promo "OEDRO" "https://www.oedro.com/" | grep -ioP 'Independence|独立日|SALE|OFF|PROMO' | head -3)
echo "OEDRO: $_od" >> "$LOG"

# Husky
_hl=$(check_promo "Husky" "https://huskyliners.com/" | grep -ioP 'SALE|OFF|免费|Free Shipping|折扣' | head -3)
echo "Husky: $_hl" >> "$LOG"

# Lasfit
_lf=$(check_promo "Lasfit" "https://www.lasfit.com/" | grep -ioP 'SALE|OFF|首单|First Order|优惠' | head -3)
echo "Lasfit: $_lf" >> "$LOG"

# TuxMat
_tm=$(check_promo "TuxMat" "https://www.tuxmat.com/" | grep -ioP 'SALE|OFF|折扣|guarantee|warranty' | head -3)
echo "TuxMat: $_tm" >> "$LOG"

echo "--- 检查完成 ---" >> "$LOG"
echo "请登录 https://dashboard.dmdmnow.com/ 查看" >> "$LOG"
echo "" >> "$LOG"
