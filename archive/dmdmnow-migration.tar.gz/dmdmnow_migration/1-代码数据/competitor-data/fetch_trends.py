#!/usr/bin/env python3
"""
Google Trends 搜索斜率爬虫
定时从 GCBC 车型列表 + 增长潜力榜/SUV Top20 核心车型 抓取 Google Trends 数据
输出: trend_data.json

使用 pytrends（免费、无需 API Key）
注意: Google Trends 有反爬限制，建议单次查询间隔 3-5 秒
"""

import json
import time
import os
import sys
from datetime import datetime, timedelta

try:
    from pytrends.request import TrendReq
    from pytrends.exceptions import ResponseError
except ImportError:
    print("❌ 请先安装 pytrends: pip install pytrends")
    sys.exit(1)

DATA_DIR = os.path.dirname(os.path.abspath(__file__))
US_SALES_PATH = os.path.join(DATA_DIR, "us_sales_data.json")
TREND_OUTPUT = os.path.join(DATA_DIR, "trend_data.json")
GCBC_PATH = os.path.join(DATA_DIR, "us_sales_data.json")


def load_sales_data():
    """加载 GCBC 销量数据，获取全部车型列表"""
    with open(US_SALES_PATH) as f:
        data = json.load(f)
    models = [s["model"] for s in data.get("sales", [])]
    print(f"📦 加载 {len(models)} 个车型")
    return models, data


def generate_search_terms(models):
    """
    为每个车型生成搜索关键词
    主词: {车型} accessories  (后市场相关)
    次词: {车型}              (通用关注度)
    返回: [(model, primary_kw, fallback_kw), ...]
    """
    terms = []
    for m in models:
        # 去掉年款前缀如 "2026 " 避免搜索过窄
        clean = m.replace("2026 ", "").replace("2025 ", "").replace("2024 ", "").strip()
        primary = f"{clean} accessories"
        fallback = clean
        terms.append((m, primary, fallback))
    return terms


def batch_query(pytrends, keywords, batch_size=4):
    """
    分批查询 Google Trends
    Google Trends 每次最多比较 5 个关键词
    返回: {keyword: interest_over_time(均值)}, ...
    """
    results = {}
    for i in range(0, len(keywords), batch_size):
        batch = keywords[i:i + batch_size]
        try:
            # 查近 90 天
            pytrends.build_payload(batch, timeframe="today 3-m", geo="US")
            data = pytrends.interest_over_time()
            if data is not None and not data.empty:
                # 去掉 "isPartial" 列
                if "isPartial" in data.columns:
                    data = data.drop(columns=["isPartial"])

                for kw in batch:
                    if kw in data.columns:
                        series = data[kw].dropna()
                        if len(series) > 0:
                            # 分两段计算斜率: 最近 30 天 vs 更早 60 天
                            cutoff = len(series) - 30
                            recent = series[cutoff:]
                            early = series[:cutoff]
                            recent_avg = recent.mean()
                            early_avg = early.mean() if len(early) > 0 else 0
                            if early_avg > 0:
                                slope_pct = round((recent_avg / early_avg - 1) * 100, 2)
                            else:
                                slope_pct = 0
                            overall_avg = round(series.mean(), 1)
                            results[kw] = {
                                "interest_avg_90d": overall_avg,
                                "slope_pct_30d_vs_60d": slope_pct,
                                "data_points": len(series),
                            }
            print(f"  ✓ 批次 {i // batch_size + 1}: {batch}")
        except ResponseError as e:
            print(f"  ⚠ 批次 {i // batch_size + 1} 失败: {e}")
            # 可能是限流，等久一点
            time.sleep(10)
        except Exception as e:
            print(f"  ⚠ 批次 {i // batch_size + 1} 异常: {e}")

        # 批次间隔，等 3 秒避免限流
        if i + batch_size < len(keywords):
            time.sleep(3)

    return results


def main():
    print(f"🚀 Google Trends 爬虫启动 — {datetime.now().isoformat()}")
    print("-" * 60)

    # 1. 加载车型
    models, sales_data = load_sales_data()
    terms = generate_search_terms(models)
    print(f"🔍 生成 {len(terms)} 组搜索词")

    # 2. 提取所有关键词（去重）
    all_keywords = []
    seen = set()
    for model, primary, fallback in terms:
        if primary not in seen:
            all_keywords.append(primary)
            seen.add(primary)
        if fallback not in seen:
            all_keywords.append(fallback)
            seen.add(fallback)

    # 3. 用主词查询（accessories 优先）
    print(f'\n📊 第 1 轮: 查询主词 (\u201c{primary}\u201d) ')
    pytrends = TrendReq(hl="en-US", tz=360)
    primary_results = batch_query(pytrends, [p for _, p, _ in terms], batch_size=4)

    # 4. 补充查询：主词失败的回落到车型名
    fallback_needed = [f for model, p, f in terms if p not in primary_results]
    if fallback_needed:
        print(f"\n📊 第 2 轮: 回退查询 {len(fallback_needed)} 个车型名")
        time.sleep(5)
        fallback_results = batch_query(pytrends, fallback_needed, batch_size=4)
    else:
        fallback_results = {}

    # 5. 组装最终输出
    trend_output = {}
    for model, primary, fallback in terms:
        if primary in primary_results:
            trend_output[model] = primary_results[primary]
        elif fallback in fallback_results:
            trend_output[model] = fallback_results[fallback]
        else:
            # 两次都失败，用占位
            trend_output[model] = {
                "interest_avg_90d": 0,
                "slope_pct_30d_vs_60d": 0,
                "data_points": 0,
                "note": "数据获取失败"
            }

    # 6. 保存
    output = {
        "source": "Google Trends",
        "scraped_at": datetime.now().isoformat(),
        "total_models": len(trend_output),
        "trends": trend_output,
    }
    with open(TREND_OUTPUT, "w") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)
    print(f"\n✅ 写入 {TREND_OUTPUT}")
    print(f"   成功: {sum(1 for v in trend_output.values() if v.get('data_points', 0) > 0)}/{len(trend_output)} 车型")

    # 7. 打印 Top 10 趋势上升车型
    sorted_by_slope = sorted(
        [m for m in trend_output if trend_output[m].get("data_points", 0) > 0],
        key=lambda m: trend_output[m].get("slope_pct_30d_vs_60d", 0),
        reverse=True,
    )
    print(f"\n📈 搜索热度上升 Top 10:")
    for m in sorted_by_slope[:10]:
        d = trend_output[m]
        print(f"   {m:35s} slope={d['slope_pct_30d_vs_60d']:>+8.2f}%  interest={d['interest_avg_90d']}")


if __name__ == "__main__":
    main()
