#!/usr/bin/env python3
"""处理 SubmissionsExport_22 (WOLFBOX Help Us Support Your Ride, 85条新提交)
1. 追加原始行到 源表-车型 (cJ2gXd)
2. 追加标准化行到 车型需求 (53652a)
本批无 Product idea sheet，不更新产品表/创意产品需求

前置检查(2026-08-31): 新ID 22075236-22253783 全部 > 已有max 22069235, 无重复
起始行: 源表 715 (当前714), 车型需求 610 (当前609)
"""
import requests, json, re, sys, openpyxl
from datetime import datetime

APP_ID = 'cli_a95e614746395cbd'
APP_SECRET = 'ZTPbyJlJNK0utcjkqgTazh8JDnLFhK4X'
TOKEN = 'W8Dxsti3Vhvo2itAuYDcULXyneb'
EXCEL = '/home/ecs-user/.openclaw/media/inbound/SubmissionsExport_22---a01bdce9-e1e2-494b-a825-a05718c7e615.xlsx'

SRC_SHEET = 'cJ2gXd'   # 源表-车型, 14列
STD_SHEET = '53652a'   # 车型需求, 10列

SRC_START = 715   # 当前最后非空行 714 → 从 715 开始
STD_START = 610   # 当前最后非空行 609 → 从 610 开始

DRY = '--dry' in sys.argv

CAT_MAP = {
    'Power Running Boards': '电动踏板',
    'Retractable Bed Step': '后侧踏',
    'Powered Retractable Bed Cover': '电动伸缩盖',
    'Hard Tri-Fold Flip Up Tonneau Cover': '硬折叠',
}

# 空产品名按描述归类
DESC_CAT = {
    22155918: '后侧踏',   # "step to help get into pickup bed when tailgate down"
    22139053: '电动踏板',  # desc 提到 "Power Running Boards"
}

MAKE_NORM = {
    'chevy': 'Chevy', 'chevrolet': 'Chevy', 'chev': 'Chevy', 'gm': 'GMC',
    'gmc': 'GMC', 'ram': 'Ram', 'dodge': 'Ram', 'chrysler': 'Ram',
    'jeep': 'Jeep', 'toyota': 'Toyota', 'lexus': 'Lexus',
    'honda': 'Honda', 'acura': 'Acura', 'hyundai': 'Hyundai', 'kia': 'Kia',
    'ford': 'Ford', 'lincoln': 'Lincoln', 'nissan': 'Nissan',
    'mazda': 'Mazda', 'subaru': 'Subaru', 'volkswagen': 'Volkswagen',
    'vw': 'Volkswagen', 'audi': 'Audi', 'bmw': 'BMW',
    'mercedes': 'Mercedes-Benz', 'mercedes-benz': 'Mercedes-Benz',
    'porsche': 'Porsche', 'volvo': 'Volvo', 'tesla': 'Tesla',
    'rivian': 'Rivian', 'cadillac': 'Cadillac', 'buick': 'Buick',
    'chrysler(dodge)': 'Ram', 'land rover': 'Land Rover',
    'jaguar': 'Jaguar', 'mini': 'MINI', 'genesis': 'Genesis',
    'hummer': 'GMC', 'infiniti': 'Nissan',  # Titan 记在 Nissan 下
}

CAB_WORDS = ['crew cab', 'crewcab', 'crew', 'super cab', 'supercab',
             'extended cab', 'quad cab', 'mega cab', 'regular cab',
             'single cab', '2 door', '4 door', '4door', '2-door', '4-door',
             '4x4', '4wd', '2wd', 'awd', 'dually', 'short bed', 'long bed',
             'standard bed', '6.5 box', "6 1/2' bed", 'diesel', '5.3 liter',
             'v-8', 'v8', '4wd', 'box']

def txt(v):
    if v is None: return ''
    if isinstance(v, (int, float)): return str(int(v))
    return str(v).strip()

def norm_make(raw):
    r = txt(raw)
    if not r: return ''
    l = r.lower().strip()
    if l in MAKE_NORM: return MAKE_NORM[l]
    for k, v in sorted(MAKE_NORM.items(), key=lambda x: -len(x[0])):
        if k in l: return v
    return r.title()

def norm_model(make, raw):
    """返回 (Model)"""
    m = txt(raw)
    m = re.sub(r'\s*\(.*?\)', ' ', m)
    m = re.sub(r'\s+', ' ', m).strip()
    if not m: return ''
    low = m.lower()

    if make == 'Ford':
        if 'f350' in low or 'f-350' in low:
            return 'F-350 Super Duty'
        if 'f250' in low or 'f-250' in low or 'super duty' in low or 'f250sd' in low.replace('-',''):
            return 'F-250 Super Duty'
        if 'f150' in low or 'f-150' in low or 'f160' in low or 'f-160' in low:
            return 'F-150'
        if low.strip() == '150':
            return 'F-150'
        if 'bronco raptor' in low or ('raptor' in low and 'bronco' in low):
            return 'Bronco Raptor'
        if 'bronco' in low:
            return 'Bronco'
        if 'ranger' in low:
            return 'Ranger'
        if 'maverick' in low:
            return 'Maverick'
        if 'transit' in low:
            return 'Transit'
        if 'excursion' in low:
            return 'Excursion'
        if 'explorer' in low:
            return 'Explorer Sport Trac' if 'sport trac' in low or 'sports trac' in low else 'Explorer'
        if 'expedition' in low:
            return 'Expedition'
        # 最后: Raptor 单列
        if 'raptor' in low:
            return 'F-150 Raptor' if make == 'Ford' else 'Raptor'
        return m.title()
    if make == 'Chevy':
        if '2500' in low: return 'Silverado 2500 HD'
        if '3500' in low: return 'Silverado 3500 HD'
        if '1500' in low: return 'Silverado 1500'
        if 'silverado' in low: return 'Silverado'
        if 'colorado' in low: return 'Colorado'
        if 'tahoe' in low: return 'Tahoe'
        if 'suburban' in low: return 'Suburban'
        if 'traverse' in low: return 'Traverse'
        if 'blazer' in low: return 'Blazer'
        if 'avalanche' in low: return 'Avalanche'
        if 'express' in low: return 'Express Van 1500' if '1500' in low else 'Express Van'
        if 'k10' in low: return 'K10'
        if 'camaro' in low: return 'Camaro'
        return m.title()
    if make == 'GMC':
        if '3500' in low: return 'Sierra 3500 HD'
        if '2500' in low: return 'Sierra 2500 HD'
        if 'sierra' in low: return 'Sierra 1500' if '1500' in low else 'Sierra EV' if ' ev' in low or low.endswith('ev') else 'Sierra'
        if 'savana' in low: return 'Savana 1500' if '1500' in low else 'Savana'
        if 'yukon' in low:
            if 'xl' in low: return 'Yukon XL'
            return 'Yukon'
        if 'canyon' in low: return 'Canyon'
        if 'hummer' in low: return 'Hummer EV'
        return m.title()
    if make == 'Ram':
        for n in ('5500', '3500', '2500', '1500'):
            if n in low: return n
        if 'rebel' in low: return '1500'
        if 'dodge' in low: return 'Dodge'
        if 'promaster' in low: return 'Promaster'
        if 'dakota' in low: return 'Dakota'
        return m.title()
    if make == 'Jeep':
        if 'wrangler' in low or 'jk' in low or 'jku' in low: return 'Wrangler'
        if 'gladiator' in low: return 'Gladiator'
        if 'grand cherokee' in low: return 'Grand Cherokee'
        if 'cherokee' in low: return 'Cherokee'
        if 'liberty' in low: return 'Liberty'
        return m.title()
    if make == 'Toyota':
        if 'landcruiser' in low or 'land cruiser' in low: return 'Land Cruiser'
        if 'tundra' in low: return 'Tundra'
        if 'tacoma' in low: return 'Tacoma'
        if 'highlander' in low: return 'Highlander'
        if 'sequoia' in low: return 'Sequoia'
        if '4runner' in low or '4 runner' in low or '4runner' in low.replace(' ', ''): return '4Runner'
        if 'fjcruiser' in low.replace(' ', '') or 'fj cruiser' in low: return 'FJ Cruiser'
        return m.title()
    if make == 'Lexus':
        if 'nx' in low: return 'NX 300'
        if 'gx' in low: return 'GX 460'
        if 'rx' in low: return 'RX 350'
        return m.title()
    if make == 'Nissan':
        if 'frontier' in low: return 'Frontier'
        if 'titan' in low: return 'Titan'
        if 'nv' in low or 'nv3500' in low.replace('-', ''): return 'NV3500'
        return m.title()
    if make == 'Rivian':
        return 'R1T' if 'r1t' in low else 'R1S' if 'r1s' in low else m.title()
    if make == 'Honda':
        if 'ridgeline' in low: return 'Ridgeline'
        if 'pilot' in low: return 'Pilot'
        if 'odyssey' in low: return 'Odyssey'
        return m.title()
    if make == 'Cadillac':
        if 'escalade' in low: return 'Escalade'
        return m.title()
    if make == 'Mercedes-Benz':
        if '2500' in low: return 'Sprinter 2500'
        if '3500' in low: return 'Sprinter 3500'
        if 'sprinter' in low: return 'Sprinter'
        return m.title()
    if make == 'Tesla':
        if 'cyber' in low: return 'Cybertruck'
        return m.title()
    for w in CAB_WORDS:
        m = re.sub(r'\b' + re.escape(w) + r'\b', ' ', m, flags=re.IGNORECASE)
    m = re.sub(r'\s+', ' ', m).strip()
    if not m: return ''
    return ' '.join(w.title() if not w.isupper() else w for w in m.split())

def norm_year(raw, desc='', model=''):
    y = txt(raw)
    for src in (y, model, desc):
        mm = re.search(r'\b(19\d{2}|20\d{2})\b', src)
        if mm: return mm.group(1)
    return ''

# 特殊行覆盖: ID -> (year, make, model, category, product_name)
OVERRIDES = {
    22251996: ('2003', 'Chevy', 'Silverado 1500', '后侧踏', 'Retractable Bed Step'),   # 1500HD
    22249982: ('2013', 'Ford', 'F-150', '电动伸缩盖', 'Powered Retractable Bed Cover'),  # F150 svt raptor -> F-150
    22237973: ('2021', 'Nissan', 'Titan', '电动伸缩盖', 'Powered Retractable Bed Cover'),  # INFINITI make, 实为 Nissan Titan
    22171672: ('2026', 'Jeep', 'Gladiator', '电动踏板', 'Power Running Boards'),  # 年份在 model
    22168740: ('2026', 'Toyota', 'Tacoma', '', ''),  # 仅 desc 提 Tacoma, 产品不明
    22141426: ('2023', 'Ford', 'F-150', '硬折叠', 'Hard Tri-Fold Flip Up Tonneau Cover'),  # MO="150"
    22138214: ('2009', 'Chevy', 'Silverado 1500', '电动踏板', 'Power Running Boards'),  # 年份混在 make
    22196557: ('2017', 'Nissan', 'Titan', '电动踏板', 'Power Running Boards'),  # make 空, model/desc Nissan titan
    22140769: ('2022', 'Nissan', 'Frontier', '电动踏板', 'Power Running Boards'),  # make 空, Frontier=Nissan
    22139191: ('2017', 'Nissan', 'Titan', '后侧踏', 'Retractable Bed Step'),  # make/model 空, desc Nissan Titan
    22132721: ('2008', 'Ford', 'F-150', '电动踏板', 'Power Running Boards'),  # F150 Lariat
    22142950: ('1993', 'Ford', 'F-150', '电动伸缩盖', 'Powered Retractable Bed Cover'),  # f150 lightning -> F-150
    22085680: ('2024', 'Ram', '3500', '电动踏板', 'Power Running Boards'),  # model 空, desc "3500 mega cab"
    22226245: ('2015', 'Ram', '1500', '电动踏板', 'Power Running Boards'),  # "Ram quad cab", desc 提到 2015 ram express 1500
    22180977: ('2019', 'Ram', '1500', '电动伸缩盖', 'Powered Retractable Bed Cover'),  # Laramie HD = 1500 trim
}

# ===== 读取 Excel =====
wb = openpyxl.load_workbook(EXCEL, read_only=True)
ws = wb['vehicle model submit']
rows = list(ws.iter_rows(values_only=True))
header = rows[0]
idx = {h: i for i, h in enumerate(header)}
data = rows[1:]
print(f'读取 {len(data)} 条提交')

PAGE = 'Help Us Support Your Ride – WOLFBOX Gear'

src_rows = []   # 14列
std_rows = []   # 10列
skipped = []
for r in data:
    rid = txt(r[idx['ID']])
    if not rid:
        skipped.append(('no-id', r)); continue
    iid = int(rid)
    prod = txt(r[idx['Product name']])
    desc = txt(r[idx['Product description or any custom request']])
    raw_year = txt(r[idx['Vehicle Year']])
    raw_make = txt(r[idx['Vehicle Make']])
    raw_model = txt(r[idx['Vehicle Model']])

    if iid in OVERRIDES:
        year, make, model, cat, prod2 = OVERRIDES[iid]
        prod = prod2 or prod
        if not year: year = norm_year(raw_year, desc, raw_model)
        if not make: make = norm_make(raw_make)
        if not model: model = norm_model(make, raw_model)
    else:
        make = norm_make(raw_make)
        model = norm_model(make, raw_model)
        year = norm_year(raw_year, desc, raw_model)
        cat = CAT_MAP.get(prod, DESC_CAT.get(iid, ''))

    src_rows.append([
        rid, PAGE, '', txt(r[idx['IP Address']]),
        txt(r[idx['First Name']]), txt(r[idx['Last Name']]),
        txt(r[idx['Email']]), txt(r[idx['Phone']]),
        raw_year, raw_make, raw_model, prod, desc,
        txt(r[idx['created at']]),
    ])
    std_rows.append([year, make, model, '', prod, desc, cat, '', '', ''])

print(f'原始行: {len(src_rows)}, 标准化行: {len(std_rows)}, 跳过: {len(skipped)}')
if skipped:
    print('跳过明细:', skipped)

no_cat = [(s[0], s[1], s[2], s[4]) for s in std_rows if not s[6]]
print('无分类的行:', no_cat if no_cat else '无 ✓')

if DRY:
    print('\n===== 标准化结果预览 =====')
    for s in std_rows:
        print(f"{s[0]:5s} {s[1]:8s} {s[2]:28s} {s[6]}")
    from collections import Counter
    print('\n品类分布:', dict(Counter(s[6] for s in std_rows)))
    sys.exit(0)

# ===== 写入飞书 =====
r = requests.post("https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
                  json={"app_id": APP_ID, "app_secret": APP_SECRET}, timeout=10)
t = r.json()['tenant_access_token']

def append_rows(sheet, start_row, values):
    end_row = start_row + len(values) - 1
    ncols = len(values[0])
    col_end = chr(ord('A') + ncols - 1)
    rng = f"{sheet}!A{start_row}:{col_end}{end_row}"
    url = f"https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{TOKEN}/values"
    body = {"valueRange": {"range": rng, "values": values}}
    resp = requests.put(url, headers={"Authorization": f"Bearer {t}", "Content-Type": "application/json"},
                        json=body, timeout=30)
    d = resp.json()
    print(f"写入 {sheet} {rng}: {d.get('code')} {d.get('msg')}")
    return d.get('code') == 0

ok1 = append_rows(SRC_SHEET, SRC_START, src_rows)
ok2 = append_rows(STD_SHEET, STD_START, std_rows)
print('源表-车型 成功:', ok1, '| 车型需求 成功:', ok2)
