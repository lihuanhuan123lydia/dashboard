#!/bin/bash
# 被 cron 调用：检查 Lasfit 新品，如有新品则输出结果
# 标准输出会被 cron 任务处理

DIR="$(cd "$(dirname "$0")" && pwd)"
bash "$DIR/check_lasfit_new.sh" 2>/dev/null
