#!/usr/bin/env python3
"""Process 3W floor mats vehicle model data → normalize + merge + aggregate"""
import json, re
from collections import defaultdict

# Load data
with open("/home/ecs-user/.openclaw/workspace/competitor-data/3w_models.json") as f:
    models = json.load(f)
with open("/home/ecs-user/.openclaw/workspace/competitor-data/3w_submissions.json") as f:
    submissions = json.load(f)

print(f"Models: {len(models)}, Submissions: {len(submissions)}")

# ===== Normalization Helpers =====

# Make name normalization
MAKE_ALIASES = {
    "FORD": "Ford", "CHEVROLET": "Chevrolet", "CHEVY": "Chevrolet",
    "TOYOTA": "Toyota", "GMC": "GMC", "HONDA": "Honda", "DODGE": "Dodge",
    "NISSAN": "Nissan", "KIA": "Kia", "HYUNDAI": "Hyundai", "JEEP": "Jeep",
    "SUBARU": "Subaru", "VOLKSWAGEN": "Volkswagen", "VW": "Volkswagen",
    "MAZDA": "Mazda", "BUICK": "Buick", "BMW": "BMW", "MERCEDES-BENZ": "Mercedes-Benz",
    "MERCEDES": "Mercedes-Benz", "AUDI": "Audi", "LEXUS": "Lexus",
    "CADILLAC": "Cadillac", "LINCOLN": "Lincoln", "RAM": "Ram",
    "CHRYSLER": "Chrysler", "ACURA": "Acura", "INFINITI": "Infiniti",
    "VOLVO": "Volvo", "TESLA": "Tesla", "RIVIAN": "Rivian",
    "MITSUBISHI": "Mitsubishi", "SCION": "Scion", "MINI": "Mini",
    "PORSCHE": "Porsche", "LAND ROVER": "Land Rover", "JAGUAR": "Jaguar",
    "FIAT": "Fiat", "GENESIS": "Genesis", "PONTIAC": "Pontiac",
    "SATURN": "Saturn", "ISUZU": "Isuzu", "SUZUKI": "Suzuki",
    "HUMMER": "Hummer", "MERCURY": "Mercury", "OLDSMOBILE": "Oldsmobile",
    "MAYBACH": "Maybach", "ALFA ROMEO": "Alfa Romeo", "MASERATI": "Maserati",
    "BENTLEY": "Bentley", "ROLLS-ROYCE": "Rolls-Royce", "LAMBORGHINI": "Lamborghini",
    "FERRARI": "Ferrari", "LOTUS": "Lotus", "MCLAREN": "McLaren",
    "ASTON MARTIN": "Aston Martin", "SMART": "Smart",
}

# Model normalization: common trim/variant suffixes to strip
TRIM_PATTERNS = [
    r'\b(XLT|XLT\s*SPORT|XL|XLS|XLT\s*FX4|LARIAT|KING\s*RANCH|PLATINUM|LIMITED|TREMOR|RAPTOR|RAPTOR\s*R|STX)\b',
    r'\b(LT|LS|LTZ|LZ|LTE|LTA|RS|SS|Z71|ZR2|RST|HIGH\s*COUNTRY|PREMIER|FLEET|WT|CUSTOM|TRAIL\s*BOSS)\b',
    r'\b(SE|SEL|SEL\s*PLUS|LIMITED|XSE|XLE|LE|XLE\s*PREMIUM|NIGHT\s*SHADE|TRD\s*PRO|TRD\s*OFF-ROAD|TRD|SR|SR5|GR\s*SPORT|GR|CAPSTONE)\b',
    r'\b(EX|LX|DX|Touring|Sport|EX-L|Touring\s*L|Elite|Hybrid|AWD|4WD|FWD|4X4)\b',
    r'\b(SLT|AT4|AT4X|DENALI|ELEVATION|SLE|SLT\s*PREMIUM|PRO|YUKON)\b',
    r'\b(Sport|Touring|EX\s*L|Hybrid|Plug-in\s*Hybrid|AWD\s*e-4WD)\b',
    r'\b(Limited|Outback|Wilderness|Onyx|Premier|High\s*Country|Preferred|Convenience)\b',
    r'\b(Big\s*Horn|Lone\s*Star|Rebel|TRX|Laramie|Longhorn|Tradesman|Classic)\b',
    r'\b(Pro-4X|PRO-4X|Pro\s*4X|SV|S|SL|Platinum\s*Reserve|Midnight\s*Edition)\b',
    r'\b(RTL|RTL-E|RTL\s*E|Sport|Black\s*Edition|TrailSport|Passport)\b',
    r'\b(GT|GTI|R|R-Line|TDI|TSI|GLI|Alltrack|Sportwagen)\b',
]

def normalize_make(m):
    m = m.strip().upper()
    if m in MAKE_ALIASES:
        return MAKE_ALIASES[m]
    # Title case
    return m.title()

def normalize_model(model_str):
    """Normalize model name: strip trims, standardize names"""
    m = model_str.strip()
    if not m:
        return ""
    
    # Handle common shorthand
    m = m.upper()
    
    # Specific model normalizations (Ford)
    m = re.sub(r'\bF[- ]?150\b', 'F-150', m)
    m = re.sub(r'\bF[- ]?250\b', 'F-250', m)
    m = re.sub(r'\bF[- ]?350\b', 'F-350', m)
    m = re.sub(r'\bF[- ]?450\b', 'F-450', m)
    m = re.sub(r'\bF[- ]?550\b', 'F-550', m)
    m = re.sub(r'\bF[- ]?650\b', 'F-650', m)
    m = re.sub(r'\bFOCUS\b', 'Focus', m)
    m = re.sub(r'\bMUSTANG\b', 'Mustang', m)
    m = re.sub(r'\bEXPLORER\b', 'Explorer', m)
    m = re.sub(r'\bESCAPE\b', 'Escape', m)
    m = re.sub(r'\bEXPEDITION\b', 'Expedition', m)
    m = re.sub(r'\bEXPEDITION\s*MAX\b', 'Expedition Max', m)
    m = re.sub(r'\bEDGE\b', 'Edge', m)
    m = re.sub(r'\bBRONCO\b', 'Bronco', m)
    m = re.sub(r'\bBRONCO\s*SPORT\b', 'Bronco Sport', m)
    m = re.sub(r'\bRANGER\b', 'Ranger', m)
    m = re.sub(r'\bMAVERICK\b', 'Maverick', m)
    m = re.sub(r'\bTRANSIT\b', 'Transit', m)
    m = re.sub(r'\bE[- ]?SERIES\b', 'E-Series', m)
    m = re.sub(r'\bE[- ]?150\b', 'E-150', m)
    m = re.sub(r'\bE[- ]?250\b', 'E-250', m)
    m = re.sub(r'\bE[- ]?350\b', 'E-350', m)
    m = re.sub(r'\bC-MAX\b', 'C-Max', m)
    m = re.sub(r'\bFLEX\b', 'Flex', m)
    m = re.sub(r'\bTAURUS\b', 'Taurus', m)
    
    # Chevy/GMC
    m = re.sub(r'\bSILVERADO\b', 'Silverado', m)
    m = re.sub(r'\bSILVERADO\s*1500\b', 'Silverado 1500', m)
    m = re.sub(r'\bSILVERADO\s*2500\b', 'Silverado 2500HD', m)
    m = re.sub(r'\bSILVERADO\s*2500HD\b', 'Silverado 2500HD', m)
    m = re.sub(r'\bSILVERADO\s*3500\b', 'Silverado 3500HD', m)
    m = re.sub(r'\bSILVERADO\s*3500HD\b', 'Silverado 3500HD', m)
    m = re.sub(r'\bTAHOE\b', 'Tahoe', m)
    m = re.sub(r'\bSUBURBAN\b', 'Suburban', m)
    m = re.sub(r'\bEQUINOX\b', 'Equinox', m)
    m = re.sub(r'\bTRAVERSE\b', 'Traverse', m)
    m = re.sub(r'\bTRAIL[BLOOD]+\b', 'Trailblazer', m)
    m = re.sub(r'\bTRAIL\s*BLAZER\b', 'Trailblazer', m)
    m = re.sub(r'\bTRAX\b', 'Trax', m)
    m = re.sub(r'\bMALIBU\b', 'Malibu', m)
    m = re.sub(r'\bCOBALT\b', 'Cobalt', m)
    m = re.sub(r'\bBLAZER\b', 'Blazer', m)
    m = re.sub(r'\bCORVETTE\b', 'Corvette', m)
    m = re.sub(r'\bCAMARO\b', 'Camaro', m)
    m = re.sub(r'\bCRUZE\b', 'Cruze', m)
    m = re.sub(r'\bIMPALA\b', 'Impala', m)
    m = re.sub(r'\bSPARK\b', 'Spark', m)
    m = re.sub(r'\bSONIC\b', 'Sonic', m)
    m = re.sub(r'\bEXPRESS\b', 'Express', m)
    m = re.sub(r'\bEXPRESS\s*1500\b', 'Express 1500', m)
    m = re.sub(r'\bEXPRESS\s*2500\b', 'Express 2500', m)
    m = re.sub(r'\bEXPRESS\s*3500\b', 'Express 3500', m)
    m = re.sub(r'\bCAPTIVA\b', 'Captiva', m)
    m = re.sub(r'\bAVALANCHE\b', 'Avalanche', m)
    m = re.sub(r'\bHHR\b', 'HHR', m)
    m = re.sub(r'\bUPLANDER\b', 'Uplander', m)
    m = re.sub(r'\bVENTURE\b', 'Venture', m)
    
    # GMC specific  
    m = re.sub(r'\bSIERRA\b', 'Sierra', m)
    m = re.sub(r'\bSIERRA\s*1500\b', 'Sierra 1500', m)
    m = re.sub(r'\bSIERRA\s*2500\b', 'Sierra 2500HD', m)
    m = re.sub(r'\bSIERRA\s*2500HD\b', 'Sierra 2500HD', m)
    m = re.sub(r'\bSIERRA\s*3500\b', 'Sierra 3500HD', m)
    m = re.sub(r'\bSIERRA\s*3500HD\b', 'Sierra 3500HD', m)
    m = re.sub(r'\bYUKON\b', 'Yukon', m)
    m = re.sub(r'\bYUKON\s*XL\b', 'Yukon XL', m)
    m = re.sub(r'\bYUKON\s*DENALI\b', 'Yukon', m)
    m = re.sub(r'\bACADIA\b', 'Acadia', m)
    m = re.sub(r'\bTERRAIN\b', 'Terrain', m)
    m = re.sub(r'\bCANYON\b', 'Canyon', m)
    m = re.sub(r'\bSAVANA\b', 'Savana', m)
    
    # Toyota
    m = re.sub(r'\bTACOMA\b', 'Tacoma', m)
    m = re.sub(r'\bTUNDRA\b', 'Tundra', m)
    m = re.sub(r'\b4RUNNER\b', '4Runner', m)
    m = re.sub(r'\bHIGHLANDER\b', 'Highlander', m)
    m = re.sub(r'\bHIGHLANDER\s*HYBRID\b', 'Highlander Hybrid', m)
    m = re.sub(r'\bRAV4\b', 'RAV4', m)
    m = re.sub(r'\bCAMRY\b', 'Camry', m)
    m = re.sub(r'\bCOROLLA\b', 'Corolla', m)
    m = re.sub(r'\bSEQUOIA\b', 'Sequoia', m)
    m = re.sub(r'\bTUNDRA\b', 'Tundra', m)
    m = re.sub(r'\bSIENNA\b', 'Sienna', m)
    m = re.sub(r'\bAVALON\b', 'Avalon', m)
    m = re.sub(r'\bVENZA\b', 'Venza', m)
    m = re.sub(r'\bGRAND\s*HIGHLANDER\b', 'Grand Highlander', m)
    m = re.sub(r'\bLAND\s*CRUISER\b', 'Land Cruiser', m)
    m = re.sub(r'\bPRIUS\b', 'Prius', m)
    m = re.sub(r'\bYARIS\b', 'Yaris', m)
    m = re.sub(r'\bSUPRA\b', 'Supra', m)
    m = re.sub(r'\bFJ\s*CRUISER\b', 'FJ Cruiser', m)
    m = re.sub(r'\bTACOMA\b', 'Tacoma', m)
    m = re.sub(r'\bMATRIX\b', 'Matrix', m)
    
    # Ram
    m = re.sub(r'\bRAM\s*1500\b', 'Ram 1500', m)
    m = re.sub(r'\bRAM\s*2500\b', 'Ram 2500', m)
    m = re.sub(r'\bRAM\s*3500\b', 'Ram 3500', m)
    m = re.sub(r'\bRAM\s*4500\b', 'Ram 4500', m)
    m = re.sub(r'\bRAM\s*5500\b', 'Ram 5500', m)
    m = re.sub(r'\b1500\b', '1500', m)
    m = re.sub(r'\b2500\b', '2500', m)
    m = re.sub(r'\b3500\b', '3500', m)
    m = re.sub(r'\b4500\b', '4500', m)
    m = re.sub(r'\b5500\b', '5500', m)
    
    # Honda
    m = re.sub(r'\bCR-V\b', 'CR-V', m)
    m = re.sub(r'\bCRV\b', 'CR-V', m)
    m = re.sub(r'\bPILOT\b', 'Pilot', m)
    m = re.sub(r'\bCIVIC\b', 'Civic', m)
    m = re.sub(r'\bACCORD\b', 'Accord', m)
    m = re.sub(r'\bODYSSEY\b', 'Odyssey', m)
    m = re.sub(r'\bRIDGELINE\b', 'Ridgeline', m)
    m = re.sub(r'\bPASSPORT\b', 'Passport', m)
    m = re.sub(r'\bHR-V\b', 'HR-V', m)
    m = re.sub(r'\bHRV\b', 'HR-V', m)
    m = re.sub(r'\bFIT\b', 'Fit', m)
    m = re.sub(r'\bELEMENT\b', 'Element', m)
    
    # Nissan
    m = re.sub(r'\bROGUE\b', 'Rogue', m)
    m = re.sub(r'\bALTIMA\b', 'Altima', m)
    m = re.sub(r'\bFRONTIER\b', 'Frontier', m)
    m = re.sub(r'\bTITAN\b', 'Titan', m)
    m = re.sub(r'\bPATHFINDER\b', 'Pathfinder', m)
    m = re.sub(r'\bARMADA\b', 'Armada', m)
    m = re.sub(r'\bMURANO\b', 'Murano', m)
    m = re.sub(r'\bSENTRA\b', 'Sentra', m)
    m = re.sub(r'\bVERSA\b', 'Versa', m)
    m = re.sub(r'\bCUBE\b', 'Cube', m)
    m = re.sub(r'\bJUKE\b', 'Juke', m)
    m = re.sub(r'\bKICKS\b', 'Kicks', m)
    m = re.sub(r'\bMAXIMA\b', 'Maxima', m)
    m = re.sub(r'\b370Z\b', '370Z', m)
    m = re.sub(r'\b350Z\b', '350Z', m)
    m = re.sub(r'\bGT-R\b', 'GT-R', m)
    m = re.sub(r'\bNV\s*\d+\b', 'NV', m)
    m = re.sub(r'\bQUEST\b', 'Quest', m)
    m = re.sub(r'\bXTERRA\b', 'Xterra', m)
    m = re.sub(r'\bXTRAIL\b', 'X-Trail', m)
    
    # Jeep
    m = re.sub(r'\bWRANGLER\b', 'Wrangler', m)
    m = re.sub(r'\bGRAND\s*CHEROKEE\b', 'Grand Cherokee', m)
    m = re.sub(r'\bCHEROKEE\b', 'Cherokee', m)
    m = re.sub(r'\bCOMPASS\b', 'Compass', m)
    m = re.sub(r'\bRENEGADE\b', 'Renegade', m)
    m = re.sub(r'\bGLADIATOR\b', 'Gladiator', m)
    m = re.sub(r'\bPATRIOT\b', 'Patriot', m)
    m = re.sub(r'\bCOMMANDER\b', 'Commander', m)
    m = re.sub(r'\bLIBERTY\b', 'Liberty', m)
    m = re.sub(r'\bWRANGLER\s*JL\b', 'Wrangler', m)
    m = re.sub(r'\bWRANGLER\s*JK\b', 'Wrangler', m)
    m = re.sub(r'\bWRANGLER\s*TJ\b', 'Wrangler', m)
    
    # Hyundai / Kia
    m = re.sub(r'\bSANTA\s*FE\b', 'Santa Fe', m)
    m = re.sub(r'\bTUCSON\b', 'Tucson', m)
    m = re.sub(r'\bELANTRA\b', 'Elantra', m)
    m = re.sub(r'\bSONATA\b', 'Sonata', m)
    m = re.sub(r'\bPALISADE\b', 'Palisade', m)
    m = re.sub(r'\bTELLURIDE\b', 'Telluride', m)
    m = re.sub(r'\bSORENTO\b', 'Sorento', m)
    m = re.sub(r'\bSPORTAGE\b', 'Sportage', m)
    m = re.sub(r'\bSELTOS\b', 'Seltos', m)
    m = re.sub(r'\bFORTE\b', 'Forte', m)
    m = re.sub(r'\bK5\b', 'K5', m)
    m = re.sub(r'\bOPTIMA\b', 'Optima', m)
    m = re.sub(r'\bRIO\b', 'Rio', m)
    m = re.sub(r'\bSOUL\b', 'Soul', m)
    m = re.sub(r'\bCARNIVAL\b', 'Carnival', m)
    m = re.sub(r'\bSEDONA\b', 'Sedona', m)
    m = re.sub(r'\bNIRO\b', 'Niro', m)
    m = re.sub(r'\bKONA\b', 'Kona', m)
    m = re.sub(r'\bIONIQ\b', 'Ioniq', m)
    m = re.sub(r'\bNEXO\b', 'Nexo', m)
    m = re.sub(r'\bVENUE\b', 'Venue', m)
    m = re.sub(r'\bVELOSTER\b', 'Veloster', m)
    m = re.sub(r'\bAZERA\b', 'Azera', m)
    m = re.sub(r'\bGENESIS\b', 'Genesis', m)  # as a model
    m = re.sub(r'\bEQUUS\b', 'Equus', m)
    m = re.sub(r'\bSTINGER\b', 'Stinger', m)
    m = re.sub(r'\bCADENZA\b', 'Cadenza', m)
    
    # Subaru
    m = re.sub(r'\bOUTBACK\b', 'Outback', m)
    m = re.sub(r'\bFORESTER\b', 'Forester', m)
    m = re.sub(r'\bCROSSTREK\b', 'Crosstrek', m)
    m = re.sub(r'\bLEGACY\b', 'Legacy', m)
    m = re.sub(r'\bIMPREZA\b', 'Impreza', m)
    m = re.sub(r'\bASCENT\b', 'Ascent', m)
    m = re.sub(r'\bWRX\b', 'WRX', m)
    m = re.sub(r'\bBRZ\b', 'BRZ', m)
    m = re.sub(r'\bTRIBECA\b', 'Tribeca', m)
    m = re.sub(r'\bBAJA\b', 'Baja', m)
    
    # Dodge
    m = re.sub(r'\bDURANGO\b', 'Durango', m)
    m = re.sub(r'\bGRAND\s*CARAVAN\b', 'Grand Caravan', m)
    m = re.sub(r'\bCARAVAN\b', 'Grand Caravan', m)
    m = re.sub(r'\bCHARGER\b', 'Charger', m)
    m = re.sub(r'\bCHALLENGER\b', 'Challenger', m)
    m = re.sub(r'\bJOURNEY\b', 'Journey', m)
    m = re.sub(r'\bNITRO\b', 'Nitro', m)
    m = re.sub(r'\bAVENGER\b', 'Avenger', m)
    m = re.sub(r'\bCALIBER\b', 'Caliber', m)
    m = re.sub(r'\bVIPER\b', 'Viper', m)
    m = re.sub(r'\bDAKOTA\b', 'Dakota', m)
    m = re.sub(r'\bRAM\s*\d+\b', 'Ram', m)
    m = re.sub(r'\bRAM\b', 'Ram 1500', m)
    
    # BMW
    m = re.sub(r'\bX1\b', 'X1', m)
    m = re.sub(r'\bX3\b', 'X3', m)
    m = re.sub(r'\bX5\b', 'X5', m)
    m = re.sub(r'\bX7\b', 'X7', m)
    m = re.sub(r'\b3[- ]?SERIES\b', '3 Series', m)
    m = re.sub(r'\b5[- ]?SERIES\b', '5 Series', m)
    m = re.sub(r'\b7[- ]?SERIES\b', '7 Series', m)
    
    # Mercedes
    m = re.sub(r'\bGLC\b', 'GLC', m)
    m = re.sub(r'\bGLE\b', 'GLE', m)
    m = re.sub(r'\bGLS\b', 'GLS', m)
    m = re.sub(r'\bC[- ]?CLASS\b', 'C-Class', m)
    m = re.sub(r'\bE[- ]?CLASS\b', 'E-Class', m)
    m = re.sub(r'\bS[- ]?CLASS\b', 'S-Class', m)
    m = re.sub(r'\bSPRINTER\b', 'Sprinter', m)
    m = re.sub(r'\bMETRIS\b', 'Metris', m)
    
    # VW
    m = re.sub(r'\bJETTA\b', 'Jetta', m)
    m = re.sub(r'\bPASSAT\b', 'Passat', m)
    m = re.sub(r'\bTIGUAN\b', 'Tiguan', m)
    m = re.sub(r'\bATLAS\b', 'Atlas', m)
    m = re.sub(r'\bGOLF\b', 'Golf', m)
    m = re.sub(r'\bBEETLE\b', 'Beetle', m)
    m = re.sub(r'\bROUTAN\b', 'Routan', m)
    m = re.sub(r'\bTOUAREG\b', 'Touareg', m)
    m = re.sub(r'\bID\.\s*4\b', 'ID.4', m)
    
    # Tesla
    m = re.sub(r'\bMODEL\s*3\b', 'Model 3', m)
    m = re.sub(r'\bMODEL\s*S\b', 'Model S', m)
    m = re.sub(r'\bMODEL\s*X\b', 'Model X', m)
    m = re.sub(r'\bMODEL\s*Y\b', 'Model Y', m)
    m = re.sub(r'\bCYBERTRUCK\b', 'Cybertruck', m)
    
    # Mazda
    m = re.sub(r'\bCX-5\b', 'CX-5', m)
    m = re.sub(r'\bCX5\b', 'CX-5', m)
    m = re.sub(r'\bCX-9\b', 'CX-9', m)
    m = re.sub(r'\bCX9\b', 'CX-9', m)
    m = re.sub(r'\bCX-3\b', 'CX-3', m)
    m = re.sub(r'\bCX3\b', 'CX-3', m)
    m = re.sub(r'\bCX-30\b', 'CX-30', m)
    m = re.sub(r'\bCX30\b', 'CX-30', m)
    m = re.sub(r'\bCX-50\b', 'CX-50', m)
    m = re.sub(r'\bCX50\b', 'CX-50', m)
    m = re.sub(r'\bCX-70\b', 'CX-70', m)
    m = re.sub(r'\bCX70\b', 'CX-70', m)
    m = re.sub(r'\bCX-90\b', 'CX-90', m)
    m = re.sub(r'\bCX90\b', 'CX-90', m)
    m = re.sub(r'\bMAZDA3\b', 'Mazda3', m)
    m = re.sub(r'\bMAZDA6\b', 'Mazda6', m)
    m = re.sub(r'\bMX-5\b', 'MX-5 Miata', m)
    m = re.sub(r'\bMIATA\b', 'MX-5 Miata', m)
    m = re.sub(r'\bRX-8\b', 'RX-8', m)
    m = re.sub(r'\bRX8\b', 'RX-8', m)
    
    # Lexus
    m = re.sub(r'\bRX\s*\d{3}\b', 'RX', m)
    m = re.sub(r'\bRX\b', 'RX', m)
    m = re.sub(r'\bNX\b', 'NX', m)
    m = re.sub(r'\bES\s*\d{3}\b', 'ES', m)
    m = re.sub(r'\bES\b', 'ES', m)
    m = re.sub(r'\bGX\b', 'GX', m)
    m = re.sub(r'\bLX\b', 'LX', m)
    m = re.sub(r'\bIS\b', 'IS', m)
    m = re.sub(r'\bLS\b', 'LS', m)
    m = re.sub(r'\bTX\b', 'TX', m)
    m = re.sub(r'\bRZ\b', 'RZ', m)
    
    # Acura
    m = re.sub(r'\bMDX\b', 'MDX', m)
    m = re.sub(r'\bRDX\b', 'RDX', m)
    m = re.sub(r'\bTLX\b', 'TLX', m)
    m = re.sub(r'\bINTEGRA\b', 'Integra', m)
    m = re.sub(r'\bZDX\b', 'ZDX', m)
    
    # Cadillac
    m = re.sub(r'\bESCALADE\b', 'Escalade', m)
    m = re.sub(r'\bESCALADE\s*ESV\b', 'Escalade ESV', m)
    m = re.sub(r'\bXT4\b', 'XT4', m)
    m = re.sub(r'\bXT5\b', 'XT5', m)
    m = re.sub(r'\bXT6\b', 'XT6', m)
    m = re.sub(r'\bSRX\b', 'SRX', m)
    m = re.sub(r'\bCTS\b', 'CTS', m)
    m = re.sub(r'\bATS\b', 'ATS', m)
    
    # Lincoln
    m = re.sub(r'\bNAVIGATOR\b', 'Navigator', m)
    m = re.sub(r'\bNAVIGATOR\s*L\b', 'Navigator L', m)
    m = re.sub(r'\bAVIATOR\b', 'Aviator', m)
    m = re.sub(r'\bCORSAIR\b', 'Corsair', m)
    m = re.sub(r'\bN AUTILUS\b', 'Nautilus', m)
    m = re.sub(r'\bMKC\b', 'MKC', m)
    m = re.sub(r'\bMKX\b', 'MKX', m)
    m = re.sub(r'\bMKT\b', 'MKT', m)
    m = re.sub(r'\bMKZ\b', 'MKZ', m)
    m = re.sub(r'\bTOWN\s*CAR\b', 'Town Car', m)
    m = re.sub(r'\bCONTINENTAL\b', 'Continental', m)
    
    # Buick
    m = re.sub(r'\bENCLAVE\b', 'Enclave', m)
    m = re.sub(r'\bENVISION\b', 'Envision', m)
    m = re.sub(r'\bENVISTA\b', 'Envista', m)
    m = re.sub(r'\bENCORE\b', 'Encore', m)
    m = re.sub(r'\bLACROSSE\b', 'LaCrosse', m)
    m = re.sub(r'\bREGAL\b', 'Regal', m)
    m = re.sub(r'\bLUCERNE\b', 'Lucerne', m)
    m = re.sub(r'\bRAINIER\b', 'Rainier', m)
    m = re.sub(r'\bTERRAZA\b', 'Terraza', m)
    m = re.sub(r'\bRENDEZVOUS\b', 'Rendezvous', m)
    m = re.sub(r'\bVERANO\b', 'Verano', m)
    
    # Chrysler
    m = re.sub(r'\bPACIFICA\b', 'Pacifica', m)
    m = re.sub(r'\bTOWN\s*&\s*COUNTRY\b', 'Town & Country', m)
    m = re.sub(r'\b300\b', '300', m)
    m = re.sub(r'\b200\b', '200', m)
    m = re.sub(r'\bASPEN\b', 'Aspen', m)
    m = re.sub(r'\bSEBRING\b', 'Sebring', m)
    
    # Infiniti
    m = re.sub(r'\bQX56\b', 'QX56', m)
    m = re.sub(r'\bQX60\b', 'QX60', m)
    m = re.sub(r'\bQX80\b', 'QX80', m)
    m = re.sub(r'\bQX50\b', 'QX50', m)
    m = re.sub(r'\bQ50\b', 'Q50', m)
    m = re.sub(r'\bQ60\b', 'Q60', m)
    m = re.sub(r'\bFX\b', 'FX', m)
    m = re.sub(r'\bEX\b', 'EX', m)
    m = re.sub(r'\bJX\b', 'JX', m)
    m = re.sub(r'\bM\b', 'M', m)
    m = re.sub(r'\bG\s*\d{2}\b', 'G', m)
    
    # Volvo
    m = re.sub(r'\bXC90\b', 'XC90', m)
    m = re.sub(r'\bXC60\b', 'XC60', m)
    m = re.sub(r'\bXC40\b', 'XC40', m)
    m = re.sub(r'\bS60\b', 'S60', m)
    m = re.sub(r'\bS90\b', 'S90', m)
    m = re.sub(r'\bV90\b', 'V90', m)
    m = re.sub(r'\bV60\b', 'V60', m)
    
    # Land Rover
    m = re.sub(r'\bRANGE\s*ROVER\s*SPORT\b', 'Range Rover Sport', m)
    m = re.sub(r'\bRANGE\s*ROVER\b', 'Range Rover', m)
    m = re.sub(r'\bRANGE\s*ROVER\s*VELAR\b', 'Range Rover Velar', m)
    m = re.sub(r'\bRANGE\s*ROVER\s*EVOQUE\b', 'Range Rover Evoque', m)
    m = re.sub(r'\bDISCOVERY\s*SPORT\b', 'Discovery Sport', m)
    m = re.sub(r'\bDISCOVERY\b', 'Discovery', m)
    m = re.sub(r'\bDEFENDER\b', 'Defender', m)
    m = re.sub(r'\bFREELANDER\b', 'Freelander', m)
    m = re.sub(r'\bLR\s*\d+\b', 'LR', m)
    
    # Now strip common trim suffixes
    for pat in TRIM_PATTERNS:
        m = re.sub(pat, '', m)
    
    # Clean up extra spaces, dashes
    m = re.sub(r'\s+', ' ', m).strip()
    m = re.sub(r'\s*-\s*', '-', m)
    
    return m


# ===== Process Models =====

# Build normalized model list from main sheet
normalized = {}
for item in models:
    make = normalize_make(item["make"])
    model = normalize_model(item["model"])
    key = f"{make}|{model}"
    
    if key not in normalized:
        normalized[key] = {
            "make": make, "model": model,
            "dev_status": item["dev"],
            "notes": item["notes"],
            "count_in_sheet": 1,
            "original_names": set([item["model"].strip()])
        }
    else:
        normalized[key]["count_in_sheet"] += 1
        normalized[key]["original_names"].add(item["model"].strip())
        # Keep non-empty dev status
        if item["dev"] and not normalized[key]["dev_status"]:
            normalized[key]["dev_status"] = item["dev"]

# Count submissions per normalized model
sub_counts = defaultdict(int)
for s in submissions:
    make = normalize_make(s["make"])
    model = normalize_model(s["model"])
    key = f"{make}|{model}"
    sub_counts[key] += s["count"]

# Merge submission counts into normalized data
for key in normalized:
    normalized[key]["people_count"] = sub_counts.get(key, 0)

# Sort by people count
for k in normalized: normalized[k]["original_names"] = list(normalized[k]["original_names"])
sorted_models = sorted(normalized.values(), key=lambda x: -x["people_count"])

# Add rank
for i, m in enumerate(sorted_models):
    m["rank"] = i + 1

# Build output
result = {
    "updated_at": "2026/5/29",
    "total_models": len(sorted_models),
    "total_people": sum(m["people_count"] for m in sorted_models),
    "total_makes": len(set(m["make"] for m in sorted_models)),
    "models": sorted_models
}

# Save
with open("/home/ecs-user/.openclaw/workspace/competitor-data/3w_dashboard_data.json", "w") as f:
    json.dump(result, f, ensure_ascii=False, indent=2)

print(f"\n✅ Processed!")
print(f"  Unique models (normalized): {result['total_models']}")
print(f"  Total people count: {result['total_people']}")
print(f"  Unique makes: {result['total_makes']}")
print(f"\nTop 20 by people count:")
for m in sorted_models[:20]:
    print(f"  #{m['rank']} {m['make']} {m['model']} - {m['people_count']}人 (dev: {m['dev_status'] or '待处理'})")

# Show models with multiple original names
print("\n\nModels with merged duplicates:")
for m in sorted_models:
    if len(m["original_names"]) > 1:
        print(f"  {m['make']} {m['model']}: {m['count_in_sheet']} rows → {', '.join(sorted(m['original_names']))}")
