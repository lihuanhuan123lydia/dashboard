#!/usr/bin/env node
/**
 * Lasfit 新品自动监控脚本
 * 检查 dashboard 数据，如有 Lasfit 新品则通知到群里
 * 状态保存在 lasfit_monitor_state.json
 */

const fs = require('fs');
const path = require('path');

const STATE_FILE = path.join(__dirname, 'lasfit_monitor_state.json');
const DATA_URL = 'https://dashboard.dmdmnow.com/new_products_data.js?_t=' + Date.now();

async function main() {
  // 读取状态
  let state = { last_date: '2026-05-27' };
  try {
    state = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
  } catch(e) {
    // 首次运行，默认上次看到 5/27
  }

  // 获取最新数据
  const resp = await fetch(DATA_URL);
  const text = await resp.text();
  const jsonStr = text.substring(text.indexOf('['), text.lastIndexOf(']')+1);
  const products = JSON.parse(jsonStr);

  // 筛选 Lasfit 新品（日期 > last_date）
  const lasfit = products.filter(p => p.b === 'Lasfit');
  const newItems = lasfilter(p => p.d > state.last_date).sort((a,b) => a.d.localeCompare(b.d));

  const result = {
    newItems,
    last_product_date: lasfit.length > 0 ? lasfit.map(p => p.d).sort().pop() : state.last_date,
    checked_at: new Date().toISOString()
  };

  // 输出结果供外部使用
  console.log(JSON.stringify(result));
}

main().catch(e => {
  console.error(JSON.stringify({ error: e.message }));
  process.exit(1);
});
