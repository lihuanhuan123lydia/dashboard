#!/usr/bin/env python3
"""
LSTM 销量增长预测模型
基于 2023 年历史数据训练，预测 2026 年增长趋势
"""

import json, os, sys, numpy as np
from datetime import datetime

try:
    import torch
    import torch.nn as nn
    import torch.optim as optim
except ImportError:
    print("❌ 请先安装 PyTorch: pip install torch")
    sys.exit(1)

DATA_DIR = os.path.dirname(os.path.abspath(__file__))

def load_training_data():
    with open(os.path.join(DATA_DIR, 'training_data_2023.json')) as f:
        return json.load(f)

class SalesPredictor(nn.Module):
    def __init__(self, input_size=1, hidden_size=32, num_layers=2):
        super().__init__()
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_size, 1)
    
    def forward(self, x):
        out, _ = self.lstm(x)
        return self.fc(out[:, -1, :])

def train_model(data, epochs=200):
    models_data = data.get('models', {})
    months_ordered = ['2023-01','2023-02','2023-03','2023-04','2023-05','2023-06',
                      '2023-07','2023-08','2023-09','2023-10','2023-11','2023-12']
    
    results = {}
    for model_name, ts in models_data.items():
        sales = [ts[m].get('car_sales', 0) for m in months_ordered]
        if max(sales) == 0:
            results[model_name] = {'predicted_growth': 0, 'confidence': 'low', 'note': '无历史数据'}
            continue
        
        # Normalize
        arr = np.array(sales, dtype=np.float32)
        mean, std = arr.mean(), arr.std() + 1e-8
        arr_norm = (arr - mean) / std
        
        # Prepare sequences
        X, y = [], []
        for i in range(len(arr_norm) - 3):
            X.append(arr_norm[i:i+3])
            y.append(arr_norm[i+3])
        
        if len(X) < 3:
            results[model_name] = {'predicted_growth': 0, 'confidence': 'low', 'note': '数据不足'}
            continue
        
        X = torch.tensor(np.array(X), dtype=torch.float32).unsqueeze(-1)
        y = torch.tensor(np.array(y), dtype=torch.float32).unsqueeze(-1)
        
        # Train
        model = SalesPredictor()
        optimizer = optim.Adam(model.parameters(), lr=0.01)
        criterion = nn.MSELoss()
        
        for _ in range(min(epochs, 50)):
            optimizer.zero_grad()
            loss = criterion(model(X), y)
            loss.backward()
            optimizer.step()
        
        # Predict next 3 months
        last_seq = torch.tensor(arr_norm[-3:], dtype=torch.float32).view(1, 3, 1)
        pred_norm = model(last_seq).item()
        pred = pred_norm * std + mean
        
        # Calculate growth rate
        current = sales[-1] if sales[-1] > 0 else 1
        growth = (pred - current) / current * 100
        
        # Confidence based on training loss
        with torch.no_grad():
            final_loss = criterion(model(X), y).item()
        
        results[model_name] = {
            'predicted_growth': round(growth, 2),
            'confidence': 'high' if final_loss < 0.1 else 'medium' if final_loss < 0.3 else 'low',
            'predicted_sales': round(pred, 0),
            'current_sales': int(current),
            'loss': round(final_loss, 4)
        }
    
    return results

if __name__ == '__main__':
    data = load_training_data()
    print(f"📦 \u52a0\u8f7d {data['total_models']} \u8f66\u578b\u7684\u5386\u53f2\u6570\u636e")
    results = train_model(data)
    
    print(f"\n🚀 LSTM \u589e\u957f\u9884\u6d4b\u7ed3\u679c:")
    sorted_results = sorted(results.items(), key=lambda x: x[1]['predicted_growth'], reverse=True)
    for model, r in sorted_results[:15]:
        conf = {'high': '✅', 'medium': '🟡', 'low': '🔴'}
        print(f"  {model:30s} \u5f53\u524d={r['current_sales']:>4.0f} \u9884\u6d4b={r['predicted_sales']:>4.0f} \u589e\u957f={r['predicted_growth']:>+7.2f}% {conf.get(r['confidence'],'')}")
    
    # Save predictions
    output = {
        'model': 'LSTM',
        'trained_at': datetime.now().isoformat(),
        'training_period': data['period'],
        'predictions': results
    }
    with open(os.path.join(DATA_DIR, 'growth_predictions.json'), 'w') as f:
        json.dump(output, f, ensure_ascii=False, indent=2)
    print(f"\n✅ \u4fdd\u5b58\u9884\u6d4b\u7ed3\u679c\u5230 growth_predictions.json")
