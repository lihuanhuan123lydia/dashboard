#!/usr/bin/env python3
"""从飞书 Open API 读取数据 → 更新 analysis_data.json + 带样式的分析面板"""
import json, requests, sys, os, re
from datetime import datetime
from collections import Counter

APP_ID = "cli_a95e614746395cbd"
APP_SECRET = "ZTPbyJlJNK0utcjkqgTazh8JDnLFhK4X"
SPREADSHEET_TOKEN = "W8Dxsti3Vhvo2itAuYDcULXyneb"
DATA_DIR = os.path.dirname(os.path.abspath(__file__))
JSON_FILE = os.path.join(DATA_DIR, "analysis_data.json")

EXISTING_PRODUCTS = [
    "电动踏板","后侧踏","电动伸缩盖","车载摄像头",
    "侧踏板","后视镜","灯支架","越野灯","充气泵","货架"
]

# ===== 车型归一化（与 process_wolfbox_19.py 同口径）=====
NORM_MAKE = {
    'chevy': 'Chevy', 'chevrolet': 'Chevy', 'chev': 'Chevy', 'gm': 'GMC',
    'gmc': 'GMC', 'ram': 'Ram', 'dodge': 'Ram', 'chrysler': 'Ram',
    'jeep': 'Jeep', 'toyota': 'Toyota', 'lexus': 'Lexus',
    'honda': 'Honda', 'acura': 'Acura', 'hyundai': 'Hyundai', 'kia': 'Kia',
    'ford': 'Ford', 'lincoln': 'Lincoln', 'nissan': 'Nissan',
    'mazda': 'Mazda', 'subaru': 'Subaru', 'volkswagen': 'Volkswagen',
    'vw': 'Volkswagen', 'audi': 'Audi', 'bmw': 'BMW',
    'mercedes': 'Mercedes-Benz', 'mercedes-benz': 'Mercedes-Benz',
    'porsche': 'Porsche', 'volvo': 'Volvo', 'tesla': 'Tesla',
    'rivian': 'Rivian', 'cadillac': 'Cadillac', 'buick': 'Buick',
    'land rover': 'Land Rover', 'jaguar': 'Jaguar', 'mini': 'MINI',
    'genesis': 'Genesis', 'hummer': 'Hummer', 'h2': 'Hummer', 'sprinter': 'Mercedes-Benz',
    'gx': 'Lexus', 'nx': 'Lexus', 'rx': 'Lexus', 'lx': 'Lexus',
}

CAB_WORDS = ['crew cab', 'crewcab', 'crew', 'super cab', 'supercab',
             'extended cab', 'quad cab', 'mega cab', 'regular cab',
             'single cab', '2 door', '4 door', '4door', '2-door', '4-door',
             '4x4', '4wd', '2wd', 'awd', 'dually', 'short bed', 'long bed',
             'standard bed', '6.5 box', "6 1/2' bed", 'diesel', '5.3 liter',
             'v-8', 'v8', 'box']

def norm_make(raw):
    r = safe_str(raw)
    if not r: return ''
    l = r.lower().strip()
    if l in NORM_MAKE: return NORM_MAKE[l]
    for k, v in sorted(NORM_MAKE.items(), key=lambda x: -len(x[0])):
        if k in l: return v
    # 剥离年份前缀后重试（如 "2020f150 regular cab..."）
    m2 = re.sub(r'^(?:19|20)\d{2}\s*', '', l)
    if m2 != l:
        for k, v in sorted(NORM_MAKE.items(), key=lambda x: -len(x[0])):
            if k in m2: return v
    return ''

def norm_model(make, raw):
    m = safe_str(raw)
    m = re.sub(r'\s*\(.*?\)', ' ', m)
    m = re.sub(r'\s+', ' ', m).strip()
    if not m: return ''
    low = m.lower()
    if make == 'Ford':
        if 'raptor' in low and ('f150' in low or 'f-150' in low):
            return 'F-150 Raptor'
        if 'f450' in low or 'f-450' in low:
            return 'F-450 Super Duty'
        if 'f350' in low or 'f-350' in low:
            if 'and' in low and 'f250' in low:
                return 'F-350 Super Duty & F-250 Super Duty'
            return 'F-350 Super Duty'
        if 'f250' in low or 'f-250' in low or 'super duty' in low:
            return 'F-250 Super Duty'
        if 'f150' in low or 'f-150' in low or 'f160' in low or 'f-160' in low:
            return 'F-150'
        if 'bronco raptor' in low or 'raptor' in low: return 'Bronco Raptor'
        if 'bronco' in low: return 'Bronco'
        if 'ranger' in low: return 'Ranger'
        if 'maverick' in low: return 'Maverick'
        if 'transit' in low: return 'Transit'
        if 'excursion' in low: return 'Excursion'
        return m.title()
    if make == 'Chevy':
        if '2500' in low: return 'Silverado 2500 HD'
        if '3500' in low: return 'Silverado 3500 HD'
        if '1500' in low: return 'Silverado 1500'
        if 'silverado' in low: return 'Silverado'
        if 'colorado' in low: return 'Colorado'
        if 'tahoe' in low: return 'Tahoe'
        if 'suburban' in low: return 'Suburban'
        if 'traverse' in low: return 'Traverse'
        if 'blazer' in low: return 'Blazer'
        if 'avalanche' in low: return 'Avalanche'
        if 'k10' in low: return 'K10'
        if 'camaro' in low: return 'Camaro'
        return m.title()
    if make == 'GMC':
        if '3500' in low: return 'Sierra 3500 HD'
        if '2500' in low: return 'Sierra 2500 HD'
        if 'sierra' in low:
            if 'ev' in low: return 'Sierra EV'
            return 'Sierra 1500' if '1500' in low else 'Sierra'
        if 'yukon' in low: return 'Yukon XL' if 'xl' in low else 'Yukon'
        if 'canyon' in low: return 'Canyon'
        if 'hummer' in low: return 'Hummer EV'
        return m.title()
    if make == 'Hummer':
        return 'H2' if 'h2' in low else m.title()
    if make == 'Ram':
        if 'promaster' in low: return 'Promaster'
        if 'dakota' in low: return 'Dakota'
        for n in ('5500', '3500', '2500', '1500'):
            if n in low: return n
        if 'dodge' in low: return 'Dodge'
        return m.title()
    if make == 'Jeep':
        if 'wrangler' in low or 'jk' in low or 'jku' in low: return 'Wrangler'
        if 'gladiator' in low: return 'Gladiator'
        if 'grand cherokee' in low: return 'Grand Cherokee'
        if 'liberty' in low: return 'Liberty'
        return m.title()
    if make == 'Toyota':
        if 'landcruiser' in low or 'land cruiser' in low: return 'Land Cruiser'
        if 'tundra' in low: return 'Tundra'
        if 'tacoma' in low: return 'Tacoma'
        if 'highlander' in low: return 'Highlander'
        if 'sequoia' in low: return 'Sequoia'
        if 'fj cruiser' in low: return 'FJ Cruiser'
        return m.title()
    if make == 'Lexus':
        if 'nx' in low: return 'NX 300'
        if 'gx' in low: return 'GX 550'
        if 'rx' in low: return 'RX 350'
        return m.title()
    if make == 'Rivian':
        return 'R1T' if 'r1t' in low else 'R1S' if 'r1s' in low else m.title()
    if make == 'Honda':
        if 'ridgeline' in low: return 'Ridgeline'
        if 'pilot' in low: return 'Pilot'
        return m.title()
    if make == 'Cadillac':
        if 'escalade' in low: return 'Escalade'
        return m.title()
    if make == 'Nissan':
        if 'frontier' in low: return 'Frontier'
        if 'titan' in low: return 'Titan'
        return m.title()
    if make == 'Kia':
        if 'sportage' in low: return 'Sportage'
        if 'telluride' in low: return 'Telluride'
        return m.title()
    for w in CAB_WORDS:
        m = re.sub(r'\b' + re.escape(w) + r'\b', ' ', m, flags=re.IGNORECASE)
    m = re.sub(r'\s+', ' ', m).strip()
    if not m: return ''
    return ' '.join(w.title() if not w.isupper() else w for w in m.split())

def nm_py(m):
    """与 analysis.html 的 nm() 保持一致（去 Super Duty / cab 后缀）"""
    s = re.sub(r'\s*Super\s*Duty', '', m, flags=re.I)
    s = re.sub(r'\s*SuperDuty', '', s, flags=re.I)
    s = re.sub(r'\s*SuperDury', '', s, flags=re.I)
    s = re.sub(r'^Dodge\s+ram\s+', '', s, flags=re.I)
    s = re.sub(r'\s+(quad|crew|extended|regular|super|king)\s*cab\b', '', s, flags=re.I)
    return s.strip() or (m or '')

def parse_dt(v):
    s = safe_str(v)
    m = re.match(r'(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):?(\d{2})?', s)
    if m:
        try:
            return datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)),
                           int(m.group(4)), int(m.group(5)), int(m.group(6) or 0))
        except Exception:
            return None
    m = re.match(r'^(\d{4})-(\d{2})-(\d{2})$', s)
    if m:
        try:
            return datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except Exception:
            return None
    # Excel 序列号 (1900 日期系统)
    try:
        from datetime import timedelta
        return datetime(1899, 12, 30) + timedelta(days=float(s))
    except Exception:
        return None

def build_trends(src_rows):
    """从源表-车型聚合每个车型的年份分布 + 近期热度"""
    from collections import defaultdict
    agg = defaultdict(lambda: {'total': 0, 'years': defaultdict(int), 'dates': []})
    for row in src_rows:
        if not row or not any(row): continue
        raw_make = safe_str(row[9]) if len(row) > 9 else ''
        raw_model = safe_str(row[10]) if len(row) > 10 else ''
        if not raw_model: continue
        # make 为空时尝试从 model 提取
        mk = norm_make(raw_make)
        if not mk:
            for token in raw_model.split():
                nm2 = norm_make(token)
                if nm2:
                    mk = nm2
                    break
        if not mk: continue
        mo = norm_model(mk, raw_model)
        if not mo: continue
        key = mk.lower() + '|' + nm_py(mo).lower()
        agg[key]['total'] += 1
        yr = safe_str(row[8]) if len(row) > 8 else ''
        ym = re.search(r'\b(19\d{2}|20\d{2})\b', yr)
        agg[key]['years'][ym.group(1) if ym else '未知'] += 1
        dt = parse_dt(row[13]) if len(row) > 13 else None
        if dt: agg[key]['dates'].append(dt)

    from datetime import timedelta
    now = datetime.now()
    trends = {}
    for key, a in agg.items():
        dates = a['dates']
        r14 = sum(1 for d in dates if d >= now - timedelta(days=14))
        p14 = sum(1 for d in dates if now - timedelta(days=28) <= d < now - timedelta(days=14))
        r7 = sum(1 for d in dates if d >= now - timedelta(days=7))
        p7 = sum(1 for d in dates if now - timedelta(days=14) <= d < now - timedelta(days=7))
        spike = round(r14 / p14, 1) if p14 else (r14 if r14 else 0)
        growth = round(r7 / p7, 1) if p7 else (r7 if r7 else 0)
        total_y = sum(a['years'].values()) or 1
        years = [{'year': y, 'count': c, 'pct': round(c / total_y * 100)}
                 for y, c in sorted(a['years'].items(), key=lambda x: -x[1])]
        trends[key] = {
            'total': a['total'],
            'recent_14d': r14,
            'spike_ratio': spike,
            'growth_ratio': growth,
            'years': years,
        }
    return trends

def get_token():
    r = requests.post("https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
                      json={"app_id": APP_ID, "app_secret": APP_SECRET}, timeout=10)
    data = r.json()
    if data.get("code") != 0:
        raise Exception(f"Token error: {data}")
    return data["tenant_access_token"]

def read_sheet(token, range_val):
    url = f"https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SPREADSHEET_TOKEN}/values/{range_val}"
    r = requests.get(url, headers={"Authorization": f"Bearer {token}"}, timeout=15)
    data = r.json()
    if data.get("code") != 0:
        raise Exception(f"Sheet read error ({range_val}): {data}")
    return data["data"]["valueRange"]["values"]

def safe_str(v):
    if v is None: return ""
    if isinstance(v, list): return ""
    return str(v)

def parse_vehicle_data(rows):
    if not rows or len(rows) < 2: return []
    headers = rows[0]
    col_map = {h: i for i, h in enumerate(headers)}
    vehicle_data = []
    for row in rows[1:]:
        if not row or not any(row): continue
        cat = safe_str(row[col_map.get("产品分类", 6)] if col_map.get("产品分类", 6) < len(row) else "")
        if not cat: continue
        year = safe_str(row[col_map.get("Year", 0)] if col_map.get("Year", 0) < len(row) else "")
        make = safe_str(row[col_map.get("Make", 1)] if col_map.get("Make", 1) < len(row) else "")
        model = safe_str(row[col_map.get("Model", 2)] if col_map.get("Model", 2) < len(row) else "")
        product = safe_str(row[col_map.get("Product", 4)] if col_map.get("Product", 4) < len(row) else "")
        dscr = safe_str(row[col_map.get("Dscription", 5)] if col_map.get("Dscription", 5) < len(row) else "")
        trim = safe_str(row[col_map.get("销售版本", 3)] if col_map.get("销售版本", 3) < len(row) else "")
        date = safe_str(row[col_map.get("处理时间", 8)] if col_map.get("处理时间", 8) < len(row) else "")
        entry = {"cat": cat, "make": make, "model": model, "product": product, "detail": dscr[:80] if dscr else ""}
        if year: entry["year"] = year
        if trim: entry["trim"] = trim
        if date: entry["date"] = date
        vehicle_data.append(entry)
    return vehicle_data

def parse_new_product_data(rows):
    if not rows or len(rows) < 2: return []
    headers = rows[0]
    col_map = {h: i for i, h in enumerate(headers)}
    new_data = []
    for row in rows[1:]:
        if not row or not any(row): continue
        title = safe_str(row[col_map.get("Title", 0)] if col_map.get("Title", 0) < len(row) else "")
        if not title: continue
        cat = safe_str(row[col_map.get("产品分类", 3)] if col_map.get("产品分类", 3) < len(row) else "")
        desc = safe_str(row[col_map.get("Description", 1)] if col_map.get("Description", 1) < len(row) else "")
        trans = safe_str(row[col_map.get("中文译文", 5)] if col_map.get("中文译文", 5) < len(row) else "")
        # 读取是否独家（Have you shared this idea with any other brands? = No → 独家）
        exclusive_val = safe_str(row[col_map.get("Have you shared this idea with any other truck/off-road accessory brands?", 2)] if col_map.get("Have you shared this idea with any other truck/off-road accessory brands?", 2) < len(row) else "")
        exclusive = exclusive_val.lower() in ("no", "false", "n", "0", "")
        new_data.append({"title": title, "cat": cat or "未分类", "detail": desc if desc else "", "translation": trans, "exclusive": exclusive})
    return new_data

def build_json(vehicle_data, new_product_data):
    today = datetime.now().strftime("%Y/%-m/%-d")
    
    # Build new_product_analysis
    np = new_product_data or []
    cats = Counter(p.get("cat", "") for p in np)
    
    kt = []
    cat_counts_map = {c: n for c, n in cats.most_common()}
    
    # Count by trend type
    step_count = sum(1 for p in np if p.get("cat", "").find("踏板") >= 0 or p.get("cat", "").find("踏") >= 0)
    bed_count = sum(1 for p in np if p.get("cat", "").find("后斗") >= 0 or p.get("title", "").find("Rack") >= 0 or p.get("cat", "").find("货架") >= 0)
    brand_count = sum(1 for p in np if "tie" in p.get("detail", "").lower() or "logo" in p.get("detail", "").lower())
    cyber_count = sum(1 for p in np if "cybertruck" in p.get("detail", "").lower())
    
    if step_count:
        kt.append({"name": "踏板延展需求", "count": step_count, "desc": "保险杠折叠/全轮间踏板是核心品类，用户希望从现有电动踏板延伸到更多上下车场景"})
    if bed_count:
        kt.append({"name": "后斗场景拓展", "count": bed_count, "desc": "宠物仓、货架等后斗使用场景延伸，用户希望最大化利用后斗空间"})
    if brand_count:
        kt.append({"name": "品牌配件化", "count": brand_count, "desc": "带Logo的捆扎带/车尾网，用户期待品牌生活方式化"})
    if cyber_count:
        kt.append({"name": "Cybertruck专属", "count": cyber_count, "desc": "特斯拉Cybertruck特有前备箱搁脚板，新兴小众市场"})
    
    pain_points = [
        "上下车不便（高龄/残障/升高改装）",
        "后斗取物困难（需要后保险杠折叠踏板）",
        "后斗空间利用率低（宠物仓/货架）",
        
        "前备箱/休息场景未被覆盖（Cybertruck）"
    ]
    
    return {
        "existing_products": EXISTING_PRODUCTS,
        "vehicle_data": vehicle_data,
        "new_product_data": new_product_data,
        "new_product_analysis": {
            "total": len(np),
            "exclusive_count": sum(1 for p in np if p.get("exclusive")),
            "categories": dict(cat_counts_map),
            "key_trends": kt,
            "pain_points": pain_points
        },
        "updated_at": today
    }

def backup_current():
    """备份当前数据，防止飞书数据丢失导致回滚"""
    if os.path.exists(JSON_FILE):
        import shutil
        bak = JSON_FILE.replace('.json', f'.bak.{datetime.now().strftime("%Y%m%d_%H%M%S")}.json')
        shutil.copy2(JSON_FILE, bak)
        # 只保留最近30个备份
        backups = sorted([f for f in os.listdir(DATA_DIR) if f.startswith('analysis_data.bak.') and f.endswith('.json')])
        while len(backups) > 30:
            os.remove(os.path.join(DATA_DIR, backups.pop(0)))
        print(f"  ✓ 已备份: {os.path.basename(bak)}")

def main():
    print(f"🔄 正在从飞书读取数据...")
    backup_current()
    token = get_token()

    try:
        vehicle_rows = read_sheet(token, f"53652a!A1:J800")
        print(f"  ✓ 车型需求: {len(vehicle_rows)-1 if len(vehicle_rows)>1 else 0} 条")
    except Exception as e:
        print(f"  ✗ 车型需求读取失败: {e}")
        vehicle_rows = []

    try:
        new_product_rows = read_sheet(token, f"VeNjAU!A1:F200")
        print(f"  ✓ 创意产品需求: {len(new_product_rows)-1 if len(new_product_rows)>1 else 0} 条")
    except Exception as e:
        print(f"  ✗ 创意产品需求读取失败: {e}")
        new_product_rows = []

    vehicle_data = parse_vehicle_data(vehicle_rows)
    new_product_data = parse_new_product_data(new_product_rows)

    data = build_json(vehicle_data, new_product_data)
    
    # 数据完整性检查：如果数据大幅缩水，警告但不阻止
    old_count = 0
    if os.path.exists(JSON_FILE):
        try:
            with open(JSON_FILE) as f:
                old = json.load(f)
            old_vehicle = len(old.get('vehicle_data', []))
            old_new = len(old.get('new_product_data', []))
            old_count = old_vehicle + old_new
            new_vehicle = len(vehicle_data)
            new_new = len(new_product_data)
            new_count = new_vehicle + new_new
            if new_count < old_count and new_count < old_count * 0.8:
                print(f"  ⚠️⚠️⚠️ 数据量严重减少: 旧{old_vehicle}条车型+{old_new}条新品 → 新{new_vehicle}条车型+{new_new}条新品")
                print(f"  ⚠️ 建议检查飞书表格是否有误，必要时从备份恢复")
        except:
            pass
    
    with open(JSON_FILE, "w") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print(f"✅ JSON 已更新: {JSON_FILE}")
    print(f"✅ 全部完成！")

if __name__ == "__main__":
    main()
