#!/usr/bin/env python3
"""竞品新品监控系统 - 基于 Shopify JSON API"""
import requests
import sqlite3
import json
import os
from datetime import datetime, timezone
from pathlib import Path

DB_PATH = Path(__file__).parent / "competitor_monitor.db"
API_RESULTS_PATH = Path(__file__).parent / "latest_products.json"

# 竞品 Shopify 域名
SHOPIFY_BRANDS = {
    "3W": "3wliners.com",
    "Lasfit": "lasfit.com",
    "TuxMat": "tuxmat.com",
    "Smartliner": "smartliner-usa.com",
}

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    'Accept': 'application/json'
}

def init_db():
    conn = sqlite3.connect(str(DB_PATH))
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS variants (
            variant_id TEXT PRIMARY KEY,
            brand TEXT,
            product_id TEXT,
            product_title TEXT,
            variant_title TEXT,
            price REAL,
            published_at TEXT,
            variant_created_at TEXT,
            sku TEXT,
            product_type TEXT,
            first_seen_at TEXT DEFAULT (datetime('now'))
        )
    ''')
    c.execute('''
        CREATE TABLE IF NOT EXISTS scan_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            brand TEXT,
            scanned_at TEXT DEFAULT (datetime('now')),
            products_found INTEGER,
            variants_found INTEGER,
            new_variants INTEGER
        )
    ''')
    conn.commit()
    conn.close()

def scan_brand(brand_name, domain):
    """扫描单个 Shopify 品牌的所有产品+变体"""
    page = 1
    total_products = 0
    total_variants = 0
    new_variants = []
    
    conn = sqlite3.connect(str(DB_PATH))
    c = conn.cursor()
    
    while True:
        url = f"https://{domain}/products.json?limit=250&page={page}"
        try:
            r = requests.get(url, headers=HEADERS, timeout=20)
            if r.status_code != 200:
                break
            data = r.json()
            products = data.get('products', [])
            if not products:
                break
            
            for prod in products:
                total_products += 1
                pid = str(prod['id'])
                title = prod['title']
                pub = prod.get('published_at', '')
                ptype = prod.get('product_type', '')
                
                for var in prod.get('variants', []):
                    total_variants += 1
                    vid = str(var['id'])
                    vt = var.get('title', '')
                    price = float(var.get('price', 0))
                    vca = var.get('created_at', '')
                    sku = var.get('sku', '')
                    
                    c.execute("SELECT 1 FROM variants WHERE variant_id=?", (vid,))
                    if not c.fetchone():
                        c.execute('''
                            INSERT INTO variants (variant_id, brand, product_id, product_title,
                            variant_title, price, published_at, variant_created_at, sku, product_type)
                            VALUES (?,?,?,?,?,?,?,?,?,?)
                        ''', (vid, brand_name, pid, title, vt, price, pub, vca, sku, ptype))
                        new_variants.append({
                            "brand": brand_name,
                            "product_id": pid,
                            "variant_id": vid,
                            "title": f"{title} ({vt})",
                            "price": price,
                            "date": vca[:10] if vca else '',
                            "sku": sku,
                            "type": ptype,
                            "variant_title": vt,
                            "product_title": title
                        })
            
            page += 1
        except Exception as e:
            print(f"[{brand_name}] Error: {e}")
            break
    
    conn.commit()
    c.execute("INSERT INTO scan_log (brand, products_found, variants_found, new_variants) VALUES (?,?,?,?)",
              (brand_name, total_products, total_variants, len(new_variants)))
    conn.commit()
    conn.close()
    
    return new_variants

def run_full_scan():
    """全量扫描所有竞品"""
    init_db()
    all_new = []
    for brand, domain in SHOPIFY_BRANDS.items():
        print(f"Scanning {brand} ({domain})...")
        new = scan_brand(brand, domain)
        all_new.extend(new)
        print(f"  {len(new)} new variants found")
    
    # 保存最新结果供前端读取
    # 获取最近30天的所有新品
    conn = sqlite3.connect(str(DB_PATH))
    c = conn.cursor()
    c.execute('''
        SELECT brand, product_title, variant_title, price, variant_created_at, variant_id, product_id, sku, product_type
        FROM variants 
        ORDER BY variant_created_at DESC
        LIMIT 200
    ''')
    rows = c.fetchall()
    conn.close()
    
    results = []
    for r in rows:
        results.append({
            "brand": r[0],
            "product": r[1],
            "variant": r[2],
            "price": r[3],
            "date": r[4][:10] if r[4] else '',
            "variant_id": r[5],
            "product_id": r[6],
            "sku": r[7],
            "type": r[8],
            "url": f"https://{SHOPIFY_BRANDS.get(r[0], '')}/products/{r[6]}?variant={r[5]}" if r[0] in SHOPIFY_BRANDS else ''
        })
    
    with open(str(API_RESULTS_PATH), 'w') as f:
        json.dump({"products": results, "scanned_at": datetime.now().isoformat()}, f)
    
    print(f"\nTotal: {len(all_new)} new variants, {len(results)} in DB")

if __name__ == "__main__":
    run_full_scan()
