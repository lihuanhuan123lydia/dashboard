#!/usr/bin/env python3
"""
EU-EVs 爬虫 — UK + EU 市场 EV 数据 & 月度趋势
数据源: https://eu-evs.com

输出:
- uk_ev_reference.json   (UK EV 最新月数据 + 参考卡片用)
- eu_ev_reference.json   (EU 15国 EV 最新月数据 + 参考卡片用)
- uk_ev_trend.json       (UK EV 月度环比趋势 → 增长模型用)
- eu_ev_trend.json       (EU 15国 EV 月度环比趋势 → 增长模型用)
"""

import json
import os
import sys
import requests
from datetime import datetime, timezone
from bs4 import BeautifulSoup

DATA_DIR = os.path.dirname(os.path.abspath(__file__))
# Output to both data dir and 3w-eu-dashboard for panel serving
EU_DIRS = [DATA_DIR, os.path.join(DATA_DIR, '..', '3w-eu-dashboard')]

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Accept-Language": "en-GB,en;q=0.9",
}

JOBS = [
    {"code": "GB",  "label": "UK"},
    {"code": "ALL", "label": "EU (15国)"},
]


def fetch_monthly_models(country_code, year, month):
    """获取指定国家/月份的全部 EV 车型注册数据"""
    url = f"https://eu-evs.com/bestSellers/{country_code}/Models/Month/{year}/{month}"
    try:
        resp = requests.get(url, timeout=20, headers=HEADERS)
        if resp.status_code != 200:
            return {}, 0
    except Exception as e:
        print(f"  ⚠ {url}: {e}")
        return {}, 0

    soup = BeautifulSoup(resp.text, "html.parser")
    tables = soup.find_all("table")
    models = {}
    total = 0

    for table in tables:
        headers = [th.get_text(strip=True) for th in table.find_all("th")]
        if "MAKE" in headers and "MODEL" in headers and "#" in headers:
            rows = table.find_all("tr")
            for row in rows[1:]:
                cells = row.find_all("td")
                if len(cells) >= 3:
                    try:
                        make = cells[0].get_text(strip=True)
                        model_name = cells[1].get_text(strip=True)
                        count = int(cells[2].get_text(strip=True).replace(",", ""))
                        if model_name not in ("UNKNOWN", "Other"):
                            key = f"{make} {model_name}"
                            models[key] = {
                                "make": make,
                                "model": model_name,
                                "count": count,
                            }
                            total += count
                    except (ValueError, IndexError):
                        continue
            break

    return models, total


def main():
    now = datetime.now()
    cur_year, cur_month = now.year, now.month

    # Determine latest complete month: use (current month - 1)
    # For the trend, also fetch (current month - 2)
    latest_month = cur_month - 1
    latest_year = cur_year
    if latest_month == 0:
        latest_month = 12
        latest_year -= 1

    prev_month = latest_month - 1
    prev_year = latest_year
    if prev_month == 0:
        prev_month = 12
        prev_year -= 1

    print(f"🚀 EU-EVs 爬虫启动 — {now.isoformat()}")
    print(f"   最新月: {latest_year}/{latest_month:02d}")
    print(f"   上月:   {prev_year}/{prev_month:02d}")
    print("-" * 60)

    for job in JOBS:
        code = job["code"]
        label = job["label"]
        print(f"\n📡 [{label}] 拉取中...")

        # Fetch latest month
        m_latest, t_latest = fetch_monthly_models(code, latest_year, latest_month)
        if not m_latest:
            print(f"  ⚠ 最新月无数据，跳过")
            continue
        print(f"  ✓ {latest_year}/{latest_month:02d}: {len(m_latest)} 车型, {t_latest:,} 辆")

        # Fetch previous month
        m_prev, t_prev = fetch_monthly_models(code, prev_year, prev_month)
        if m_prev:
            print(f"  ✓ {prev_year}/{prev_month:02d}: {len(m_prev)} 车型, {t_prev:,} 辆")
        else:
            print(f"  ⚠ 上月无数据，跳过趋势计算")
            m_prev = {}

        # Compute MoM trends
        trend_data = []
        for key, item in m_latest.items():
            prev_item = m_prev.get(key, {})
            prev_count = prev_item.get("count", 0) if prev_item else 0
            mom_pct = (
                round(((item["count"] - prev_count) / max(prev_count, 1)) * 100, 1)
                if prev_count > 0
                else 0
            )
            # Clamp extreme values
            mom_pct = max(min(mom_pct, 500), -100)

            trend_data.append({
                "make": item["make"],
                "model": item["model"],
                "latest_count": item["count"],
                "prev_count": prev_count,
                "mom_pct": mom_pct,
            })

        trend_data.sort(key=lambda x: -x["latest_count"])

        # --- Save reference JSON (for EV 参考卡片) ---
        ref_file = f"{code.lower()}_ev_reference.json"
        if code == "ALL":
            ref_file = "eu_ev_reference.json"
        elif code == "GB":
            ref_file = "uk_ev_reference.json"

        ref_output = {
            "source": "EU-EVs",
            "country": code,
            "country_name": label,
            "period_year": latest_year,
            "period_month": latest_month,
            "scraped_at": datetime.now(timezone.utc).isoformat(),
            "total_registrations": t_latest,
            "brands_count": len(set(i["make"] for i in m_latest.values())),
            "models_count": len(m_latest),
            "models": [{"make": v["make"], "model": v["model"], "count": v["count"]}
                       for v in sorted(m_latest.values(), key=lambda x: -x["count"])],
        }
        for out_dir in [DATA_DIR, os.path.join(DATA_DIR, '..', '3w-eu-dashboard')]:
            out_dir_abs = os.path.abspath(out_dir)
            os.makedirs(out_dir_abs, exist_ok=True)
            ref_path = os.path.join(out_dir_abs, ref_file)
            with open(ref_path, "w") as f:
                json.dump(ref_output, f, ensure_ascii=False, indent=2)
        print(f"  ✅ {ref_file}")

        # --- Save trend JSON (for 增长模型) ---
        trend_file = f"{code.lower()}_ev_trend.json"
        if code == "ALL":
            trend_file = "eu_ev_trend.json"
        elif code == "GB":
            trend_file = "uk_ev_trend.json"

        trend_output = {
            "source": "EU-EVs",
            "country": code,
            "country_name": label,
            "latest_period": f"{latest_year}/{latest_month:02d}",
            "previous_period": f"{prev_year}/{prev_month:02d}",
            "scraped_at": datetime.now(timezone.utc).isoformat(),
            "trends": trend_data,
        }
        for out_dir in [DATA_DIR, os.path.join(DATA_DIR, '..', '3w-eu-dashboard')]:
            out_dir_abs = os.path.abspath(out_dir)
            os.makedirs(out_dir_abs, exist_ok=True)
            trend_path = os.path.join(out_dir_abs, trend_file)
            with open(trend_path, "w") as f:
                json.dump(trend_output, f, ensure_ascii=False, indent=2)
        print(f"  ✅ {trend_file}  ({len(trend_data)} 车型趋势)")

        # Print top movers
        by_growth = sorted(trend_data, key=lambda x: -x["mom_pct"])
        print(f"\n   📈 上涨 Top 5:")
        for t in by_growth[:5]:
            print(f"      {t['make']:15s} {t['model']:30s} MoM={t['mom_pct']:>+7.1f}% ({t['prev_count']}→{t['latest_count']})")
        print(f"   📉 下跌 Top 5:")
        for t in by_growth[-5:]:
            print(f"      {t['make']:15s} {t['model']:30s} MoM={t['mom_pct']:>+7.1f}% ({t['prev_count']}→{t['latest_count']})")

    print(f"\n✅ 全部完成")


if __name__ == "__main__":
    main()
