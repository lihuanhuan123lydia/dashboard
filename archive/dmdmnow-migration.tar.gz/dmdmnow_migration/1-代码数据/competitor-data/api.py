"""Simple API server for competitor monitoring data"""
import json
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path

DB_PATH = Path(__file__).parent / "competitor_monitor.db"
RESULTS_PATH = Path(__file__).parent / "latest_products.json"

class APIHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        
        if self.path == '/api/products.json' or self.path == '/api/newest':
            # Return newest products from latest scan
            if RESULTS_PATH.exists():
                data = json.loads(RESULTS_PATH.read_text())
                self.wfile.write(json.dumps(data).encode())
            else:
                self.wfile.write(json.dumps({"products": [], "scanned_at": ""}).encode())
        else:
            self.wfile.write(json.dumps({"status": "ok", "message": "API running"}).encode())
    
    def log_message(self, format, *args):
        pass  # Suppress logs

if __name__ == '__main__':
    port = 18901
    server = HTTPServer(('0.0.0.0', port), APIHandler)
    print(f"API server on port {port}")
    server.serve_forever()
