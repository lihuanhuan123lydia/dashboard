#!/usr/bin/env python3
"""
TuxMat 新品通知脚本
- 读 check_tuxmat_new.sh 产出的 /tmp/tuxmat_cron_result.json
- 通过飞书 Bot API 发到「车型匹配&新品下单」群
"""
import json, os, sys, re, time, urllib.request, urllib.error

# ===== 配置 =====
GROUP_CHAT_ID = "oc_2afdd5b5db7e64c93b0066b85a87cc2a"
APP_ID = "cli_a95e614746395cbd"
APP_SECRET = "ZTPbyJlJNK0utcjkqgTazh8JDnLFhK4X"
RESULT_FILE = "/tmp/tuxmat_cron_result.json"

# ===== 商品 URL 修复（数字ID -> handle，确保链接可点击触达落地页） =====
HANDLE_CACHE_TTL = 6 * 3600  # 缓存 6 小时
_handle_cache = None
_handle_cache_ts = 0


def _fetch_products_json():
    """拉取 tuxmat 产品列表（products.json 按创建时间倒序），建立 id -> handle 映射"""
    mapping = {}
    page_info = None
    # 拉取前 10 页（约 2500 条），覆盖 TuxMat 全站产品
    for _ in range(10):
        url = "https://tuxmat.com/products.json?limit=250"
        if page_info:
            url += "&page_info=" + page_info
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        props = json.loads(urllib.request.urlopen(req, timeout=20).read())
        prods = props.get("products", []) or []
        for p in prods:
            if p.get("id") and p.get("handle"):
                mapping[str(p["id"])] = p["handle"]
        page_info = props.get("page_info", "") or ""
        if not page_info:
            break
    return mapping


def get_handle_cache():
    global _handle_cache, _handle_cache_ts
    now = time.time()
    if _handle_cache is None or now - _handle_cache_ts > HANDLE_CACHE_TTL:
        try:
            _handle_cache = _fetch_products_json()
            _handle_cache_ts = now
        except Exception as e:
            print(f"⚠️ 拉取 handle 映射失败，使用原链接: {e}", file=sys.stderr)
            _handle_cache = _handle_cache or {}
            _handle_cache_ts = now
    return _handle_cache


def resolve_url(url):
    """把 /products/{数字ID}?variant=... 转成可访问的 handle 落地页链接；失败则原样返回"""
    if not url:
        return url
    m = re.search(r'/products/(\d+)', url)
    if not m:
        return url
    pid = m.group(1)
    handle = get_handle_cache().get(pid)
    if not handle:
        return url
    # 保留原 URL 尾部参数（variant 等）
    qs = url.split('?', 1)[1] if '?' in url else ''
    new = f"https://tuxmat.com/products/{handle}"
    if qs:
        new += "?" + qs
    return new


def extract_vehicle_and_type(title):
    """从 TuxMat 标题提取车型和产品类型"""
    tl = title[:80]
    # TuxMat 标题格式: "Audi Q3 | Black / Trunk Mats Only / ..."
    parts = tl.split(" | ")
    vehicle = parts[0].strip() if len(parts) > 0 else ""
    rest = parts[1] if len(parts) > 1 else ""
    
    # 提取产品类型
    ptype = ""
    if "Trunk" in rest or "trunk" in rest:
        ptype = "尾箱垫"
    elif "Floor" in rest or "floor" in rest:
        ptype = "脚垫"
    if "SuperTrunk" in rest:
        ptype = "超级尾箱垫（含后排椅背）"
    if "1st" in rest and "2nd" in rest and "3rd" in rest:
        ptype += " 全车三排"
    elif "1st" in rest and "2nd" in rest:
        ptype += " 前两排"
    elif "1st" in rest:
        ptype += " 前排"
    elif "2nd" in rest:
        ptype += " 后排"
    
    return vehicle, ptype if ptype else rest[:30]

def get_tenant_token():
    """获取飞书 tenant_access_token"""
    url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
    data = json.dumps({
        "app_id": APP_ID,
        "app_secret": APP_SECRET
    }).encode()
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    resp = urllib.request.urlopen(req)
    result = json.loads(resp.read())
    if "tenant_access_token" not in result:
        print(f"❌ 获取 token 失败: {result}", file=sys.stderr)
        sys.exit(1)
    return result["tenant_access_token"]

def send_feishu_msg(token, content_json):
    """发送消息到群"""
    url = f"https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=chat_id"
    data = json.dumps({
        "receive_id": GROUP_CHAT_ID,
        "msg_type": "interactive",
        "content": json.dumps(content_json, ensure_ascii=False)
    }).encode()
    req = urllib.request.Request(url, data=data, headers={
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    })
    try:
        resp = urllib.request.urlopen(req)
        result = json.loads(resp.read())
        if result.get("code") != 0:
            print(f"❌ 发送失败: {result}", file=sys.stderr)
            return False
        return True
    except urllib.error.HTTPError as e:
        print(f"❌ HTTP 错误: {e.code} {e.read().decode()}", file=sys.stderr)
        return False

def build_card(new_items):
    """构建飞书消息卡片 - TuxMat 版本"""
    elements = []
    today = time.strftime("%m/%d")
    
    # 使用实际产品的上架日期范围
    dates = sorted(set(i.get("d","") for i in new_items if i.get("d")))
    date_range = f"{dates[0]} ~ {dates[-1]}" if len(dates) >= 2 else (dates[0] if len(dates) == 1 else today)
    elements.append({"tag": "markdown", "content": f"**📅 {date_range} | TuxMat 新品上架**"})
    
    lines = []
    for item in new_items:
        title = item.get("t", "")
        price = item.get("p", 0)
        url = item.get("u", "")
        product_date = item.get("d", "")
        
        vehicle, ptype = extract_vehicle_and_type(title)
        url = resolve_url(url)
        
        price_str = f"${price:.2f}" if price else ""
        link_text = f"🔗 [查看链接]({url})" if url else ""
        
        d = item.get("d", "")
        lines.append(f"• **{vehicle}** | {ptype} | {d} | {price_str} {link_text}")
    
    if lines:
        elements.append({
            "tag": "markdown",
            "content": f"**🚗 新品详情**\n" + "\n".join(lines)
        })
    
    elements.append({"tag": "hr"})
    elements.append({
        "tag": "note",
        "element": {"tag": "plain_text", "content": f"共 {len(new_items)} 条新品 · 每日自动检测 · 数据源: Shopify API"}
    })
    
    return {
        "config": {"wide_screen_mode": True},
        "header": {
            "title": {"tag": "plain_text", "content": f"🆕 TuxMat 上架 {len(new_items)} 款新品"},
            "template": "indigo"
        },
        "elements": elements
    }

def main():
    if not os.path.exists(RESULT_FILE):
        print(f"❌ 结果文件不存在: {RESULT_FILE}", file=sys.stderr)
        sys.exit(1)
    
    with open(RESULT_FILE) as f:
        data = json.load(f)
    
    if not data.get("has_new"):
        print("ℹ️ 无 TuxMat 新品，跳过通知")
        return
    
    new_items = data.get("new_items", [])
    if not new_items:
        print("ℹ️ TuxMat 新品列表为空，跳过通知")
        return
    
    print(f"ℹ️ 发现 {len(new_items)} 条 TuxMat 新品")
    for item in new_items:
        print(f"   {item.get('t', '')[:70]}")
    
    token = get_tenant_token()
    card = build_card(new_items)
    success = send_feishu_msg(token, card)
    
    if success:
        print("✅ TuxMat 通知已发送到群")
    else:
        print("❌ 通知发送失败", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
