#!/usr/bin/env python3
"""WOLFBOX 分析面板后端 - 从飞书实时拉取数据"""
import json, os, subprocess, re
from flask import Flask, jsonify, send_from_directory

app = Flask(__name__)
DATA_DIR = os.path.dirname(os.path.abspath(__file__))

# WOLFBOX Gear 已有品类
EXISTING_PRODUCTS = [
    '电动踏板', '后侧踏', '电动后斗盖',
    '车载摄像头', '侧踏板', '后视镜', '灯光', '越野灯', '充气泵', '货架'
]

def run_feishu_cmd(action, **kwargs):
    """Use openclaw's feishu_sheet tool via subprocess - fallback to direct API"""
    # Direct API approach - read the sheet via web_fetch equivalent
    # Actually we need a different approach since we can't call the tool from Python
    # Let's use cached data + periodic update script
    
    # For now, return empty and let the HTML use embedded data
    return None

@app.route('/')
def index():
    return send_from_directory(DATA_DIR, 'analysis.html')

@app.route('/api/data')
def api_data():
    """Return current analysis data from Feishu sheets"""
    try:
        # Read 车型需求 sheet
        result = subprocess.run([
            'python3', '-c', f'''
import json, sys
# This is a stub - the real data fetching happens via the update script
# Read the local cached data
try:
    with open("{DATA_DIR}/analysis_data.json") as f:
        print(f.read())
except:
    print(json.dumps({{"error": "no cached data"}}))
'''
        ], capture_output=True, text=True, timeout=10)
        
        data = json.loads(result.stdout.strip() or '{}')
        return jsonify(data)
    except Exception as e:
        return jsonify({'error': str(e), 'vehicle_data': [], 'new_product_data': [], 'existing_products': EXISTING_PRODUCTS})

@app.route('/api/refresh')
def api_refresh():
    """Trigger data refresh from Feishu"""
    result = subprocess.run(['python3', f'{DATA_DIR}/update_analysis.py'], 
                          capture_output=True, text=True, timeout=30)
    return jsonify({'status': 'ok', 'output': result.stdout, 'error': result.stderr})

if __name__ == '__main__':
    print(f"面板后端启动: http://localhost:8902")
    print(f"API: http://localhost:8902/api/data")
    app.run(host='0.0.0.0', port=8902)
