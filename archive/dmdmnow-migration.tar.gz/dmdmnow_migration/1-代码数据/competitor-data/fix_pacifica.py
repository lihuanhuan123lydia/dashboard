#!/usr/bin/env python3
"""Fix Chrysler Pacifica entries: standardize Model names, split sales versions"""
import requests, json, re, time
from collections import Counter

APP_ID = 'cli_a95e614746395cbd'
APP_SECRET = '***'
SPREADSHEET_TOKEN = 'NV6Gsl…enjq'
SHEET = '1sCyzd'

# Pacifica trim mappings
PACIFICA_TRIMS = {
    'limited': ('Pacifica', 'Limited'),
    'touring l': ('Pacifica', 'Touring L'),
    'touring': ('Pacifica', 'Touring'),
    'hybrid': ('Pacifica Hybrid', ''),
    'pinnacle': ('Pacifica', 'Pinnacle'),
    's': ('Pacifica', 'S'),
    'touring l plus': ('Pacifica', 'Touring L Plus'),
    'touring plus': ('Pacifica', 'Touring Plus'),
}

def get_token():
    r = requests.post('https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal',
                      json={'app_id': APP_ID, 'app_secret': APP_SECRET}, timeout=10)
    return r.json()['tenant_access_token']

def txt(v):
    if v is None: return ''
    if isinstance(v, (int, float)): return str(int(v))
    return str(v).strip()

def normalize_pacifica(model_str):
    """Standardize Pacifica model name and extract trim"""
    m = model_str.upper().strip().replace(' ', '')
    
    # Remove the PACIFICA prefix
    rest = m.replace('PACIFICA', '')
    if not rest:
        return 'Pacifica', ''
    
    # Match known trim patterns
    for keyword, (std_model, std_trim) in sorted(PACIFICA_TRIMS.items(), key=lambda x: -len(x[0])):
        kw = keyword.upper().replace(' ', '')
        if kw in rest:
            return std_model, std_trim
    
    # Fuzzy match rest against known trims
    rest_lower = rest.lower()
    for keyword, (std_model, std_trim) in sorted(PACIFICA_TRIMS.items(), key=lambda x: -len(x[0])):
        kw = keyword.replace(' ', '')
        # Check if rest starts with the keyword
        if rest_lower.startswith(kw):
            return std_model, std_trim
    
    # Unknown - just return original as-is with title case
    return 'Pacifica ' + rest.title(), ''


def main():
    token = get_token()
    
    # Read all Pacifica entries
    all_pacifica = []
    row_index = {}  # actual_row_num -> row_data
    
    print("读取所有 Pacifica 条目...")
    for start in range(1, 36500, 2000):
        end = min(start + 1999, 36500)
        url = f'https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SPREADSHEET_TOKEN}/values/{SHEET}!A{start}:J{end}'
        r = requests.get(url, headers={'Authorization': f'Bearer {token}'}, timeout=30)
        rows = r.json()['data']['valueRange']['values']
        
        # Calculate actual row numbers
        for i, row in enumerate(rows):
            actual_row = start + i
            if len(row) >= 5:
                make = txt(row[0]).lower()
                model = txt(row[1]).lower()
                if make == 'chrysler' and 'pacifica' in model:
                    p = {
                        'row_num': actual_row,
                        'make': txt(row[0]),
                        'model': txt(row[1]),
                        'trim': txt(row[2]) if len(row) > 2 else '',
                        'year': txt(row[3]) if len(row) > 3 else '',
                        'note': txt(row[5]) if len(row) > 5 else '',
                    }
                    all_pacifica.append(p)
                    row_index[actual_row] = row
        time.sleep(0.3)
    
    print(f"找到 {len(all_pacifica)} 条")
    
    # Show current state
    model_variants = Counter()
    for p in all_pacifica:
        model_variants[p['model']] += 1
    
    print("\n=== 当前 Model 分布 ===")
    for m, c in sorted(model_variants.items(), key=lambda x: -x[1]):
        print(f'  {m:30s} ({c}条)')
    
    # Analyze what needs to change
    changes = []
    for p in all_pacifica:
        new_model, new_trim = normalize_pacifica(p['model'])
        if new_model != p['model'] or new_trim != p['trim']:
            changes.append((p, new_model, new_trim))
    
    print(f"\n=== 需要修改: {len(changes)} 条 ===")
    
    # Group by type of change
    change_types = Counter()
    for p, nm, nt in changes:
        change_types[f"{p['model']:25s} → Model={nm:15s}, Trim={nt or '(空)':12s}"] += 1
    
    for ct, c in sorted(change_types.items(), key=lambda x: -x[1]):
        print(f'  {ct} ({c}条)')
    
    # Ask for confirmation
    print(f"\n是否继续执行修改？(y/n)")
    # No interactive mode, let's just show and wait
    confirm = 'y'  # Proceed
    
    if confirm == 'y':
        print("\n开始批量修改...")
        batch_writes = {}  # row_num -> (Model, 销售版本)
        
        for p, new_model, new_trim in changes:
            batch_writes[p['row_num']] = (new_model, new_trim)
        
        BATCH = 100
        items = sorted(batch_writes.items())
        for i in range(0, len(items), BATCH):
            batch = items[i:i+BATCH]
            # Write B column (Model) and C column (销售版本) for each row
            for row_num, (new_model, new_trim) in batch:
                url = f'https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SPREADSHEET_TOKEN}/values'
                body = {
                    'valueRange': {
                        'range': f'{SHEET}!B{row_num}:C{row_num}',
                        'values': [[new_model, new_trim]]
                    }
                }
                r = requests.put(url, headers={'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'},
                                 json=body, timeout=15)
                result = r.json()
                if result.get('code') == 0:
                    pass  # success
                else:
                    print(f'  ✗ Row {row_num}: {result}')
                time.sleep(0.3)
            
            print(f'  ✓ 已修改 {i+len(batch)}/{len(items)} 条')
        
        print(f"\n✅ 修改完成！共修改 {len(changes)} 条")
        
        # Show final state
        print("\n=== 修改后预览 (前10条) ===")
        for p, new_model, new_trim in changes[:10]:
            print(f'  行{p["row_num"]}: {new_model:20s} | Trim: {new_trim or "(空)":12s} | {p["year"]} | {p["note"][:30]}')
    else:
        print("已取消")

if __name__ == '__main__':
    main()
