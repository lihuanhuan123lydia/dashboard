#!/usr/bin/env python3
"""批量修复所有车型 - 从 Model 提取销售版本"""
import os, requests, json, re, time, sys
from collections import Counter

SECRET = os.environ['FEISHU_SECRET']
SPREADSHEET_TOKEN = os.environ['FEISHU_TOKEN']
APP_ID = 'cli_a95e614746395cbd'
SHEET = '1sCyzd'

def txt(v):
    if v is None: return ''
    if isinstance(v, (int, float)): return str(int(v))
    if isinstance(v, list): return ''
    return str(v).strip()

def get_token():
    r = requests.post('https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal',
                      json={'app_id': APP_ID, 'app_secret': SECRET}, timeout=10)
    return r.json()['tenant_access_token']

# Fix rules: (make_lower, model_part, trim_part, new_model, trim_display)
FIX = []
def add(make, model_has, trim_word, new_model=None, trim_display=None):
    FIX.append((make.lower(), model_has.lower().strip(), trim_word.lower().strip(),
                (new_model or model_has).strip(), (trim_display or trim_word).strip()))

# === FORD ===
for t in ['XLT','XL','Lariat','Platinum','Limited','KingRanch','STX']:
    add('Ford','F-150',t,'F-150',t)
    add('Ford','F150',t,'F-150',t)
for t in ['XLT','XL','Lariat','Platinum','Limited']:
    add('Ford','F-250',t,'F-250',t)
    add('Ford','F250',t,'F-250',t)
    add('Ford','F-350',t,'F-350',t)
    add('Ford','F350',t,'F-350',t)
    add('Ford','F-450',t,'F-450',t)
    add('Ford','F450',t,'F-450',t)
    add('Ford','SuperDuty',t,'Super Duty',t)
for t in ['XLT','Limited','Platinum','KingRanch']:
    add('Ford','Expedition',t)
for t in ['XLT','Limited','Platinum','ST']:
    add('Ford','Explorer',t)
for t in ['XLT','Lariat']:
    add('Ford','Ranger',t)
    add('Ford','Maverick',t)
for t in ['SE','SEL','Titanium','ST-Line','S-Line']:
    add('Ford','Escape',t)
add('Ford','Mustang','GT')
add('Ford','Mustang','EcoBoost')

# === CHEVROLET ===
for m in ['Silverado1500','Silverado2500','Silverado3500','Silverado2500HD']:
    for t in ['LT','LTZ','LS','RST','Z71','TrailBoss','HighCountry','WT','Custom','Premier','LTD']:
        add('Chevrolet',m,t,m,t)
        add('Chevy',m,t,m,t)
for m in ['Tahoe','Suburban']:
    for t in ['LS','LT','LTZ','RST','Premier','HighCountry','Z71','Premiere']:
        add('Chevrolet',m,t)
        add('Chevy',m,t)
for m in ['Traverse','Equinox','Blazer']:
    for t in ['LS','LT','LTZ','Premier','RS','RST']:
        add('Chevrolet',m,t)
        add('Chevy',m,t)
for m in ['Colorado']:
    for t in ['LT','ZR2','Z71','TrailBoss','WT']:
        add('Chevrolet',m,t)

# === GMC ===
for m in ['Sierra1500','Sierra2500','Sierra3500','Sierra2500HD']:
    for t in ['Denali','SLT','SLE','Elevation','AT4','AT4X']:
        add('GMC',m,t,m,t)
for m in ['Yukon','Acadia','Terrain']:
    for t in ['Denali','SLT','SLE','Elevation','AT4']:
        add('GMC',m,t)

# === RAM ===
for m in ['1500','2500','3500']:
    for t in ['BigHorn','Laramie','Limited','Longhorn','Tradesman','Sport','Rebel']:
        add('Ram','Ram'+m,t,'Ram '+m,t)
        add('Dodge',m,t,'Ram '+m,t)
add('Dodge','Durango','GT'); add('Dodge','Durango','R/T'); add('Dodge','Durango','SXT')
add('Dodge','Durango','Plus'); add('Dodge','Durango','Citadel')

# === TOYOTA ===
for t in ['Limited','Platinum','SR5','1794','TRDPro','Capstone','TRDSport']:
    add('Toyota','Tundra',t)
for t in ['Limited','SR5','TRDPro','TRDSport','TRDOff-Road','Premium','Trailhunter']:
    add('Toyota','Tacoma',t)
for t in ['Limited','SR5','TRDPro','Premium','Venture']:
    add('Toyota','4Runner',t)
for t in ['LE','XLE','Limited','Platinum']:
    add('Toyota','Highlander',t); add('Toyota','Sienna',t)
    add('Toyota','Camry',t); add('Toyota','Corolla',t); add('Toyota','RAV4',t)
    add('Toyota','GrandHighlander',t,'Grand Highlander',t)

# === HONDA ===
for t in ['LX','EX','EX-L','EXL','Touring','Sport','Elite']:
    add('Honda','CR-V',t); add('Honda','CRV',t)
    add('Honda','Civic',t); add('Honda','Accord',t)
    add('Honda','Pilot',t); add('Honda','Odyssey',t)

# === JEEP ===
for t in ['Laredo','Limited','Trailhawk','Overland','Summit','Altitude','HighAltitude']:
    add('Jeep','GrandCherokee',t,'Grand Cherokee',t)
for t in ['Latitude','Limited','Trailhawk','Altitude','Sport','Upland']:
    add('Jeep','Cherokee',t)
add('Jeep','Wagoneer','L')
add('Jeep','GrandCherokee','L','Grand Cherokee','L')

# === NISSAN ===
for m in ['Frontier','Rogue','Pathfinder','Armada','Titan']:
    for t in ['S','SV','SL','Platinum']:
        add('Nissan',m,t)
add('Nissan','Frontier','Pro-4X','Frontier','Pro-4X')
add('Nissan','Frontier','Pro4X','Frontier','Pro-4X')

# === HYUNDAI ===
for m in ['Tucson','SantaFe','Palisade','Sonata','Elantra','Kona']:
    for t in ['SE','SEL','Limited','Calligraphy','Sport']:
        add('Hyundai',m,t)

# === KIA ===
for m in ['Telluride','Sorento','Sportage','Carnival']:
    for t in ['LX','S','EX','SX','Prestige','X-Line','XLine','SX-Prestige','SXP']:
        add('Kia',m,t)
add('Kia','Telluride','SX-Prestige','Telluride','SX Prestige')

# === CHRYSLER (already fixed but for completeness) ===
for t in ['Limited','Touring','TouringL','TouringLPlus','Pinnacle','Select','Plus','LaunchEdition']:
    add('Chrysler','Pacifica',t)
add('Chrysler','Pacifica','L')

# === SUBARU ===
for m in ['Outback','Forester','Crosstrek','Ascent']:
    for t in ['Premium','Limited','Touring','Wilderness','Sport','Onyx']:
        add('Subaru',m,t)

# === MAZDA ===
for m in ['CX-5','CX5','CX-9','CX9','CX-30','CX30','CX-90','CX90','Mazda3','Mazda6']:
    for t in ['Sport','Touring','GrandTouring','Signature','Premium','Turbo']:
        add('Mazda',m,t,m,t)

# === LINCOLN ===
add('Lincoln','Navigator','L')
add('Lincoln','Aviator','Reserve')

# === VW ===
for m in ['Atlas','Tiguan','Jetta']:
    for t in ['S','SE','SEL']:
        add('Volkswagen',m,t)
    add('Volkswagen',m,'R-Line',m,'R-Line')

# === LEXUS ===
for m in ['RX','NX','GX','ES']:
    for t in ['Premium','Luxury','FSport']:
        add('Lexus',m,t)

# === AUDI ===
for m in ['Q5','Q3','Q7','A3','A4','A5','A6']:
    for t in ['Premium','PremiumPlus','Prestige']:
        add('Audi',m,t)

# === BMW ===
for m in ['X3','X5','X1','X7']:
    for t in ['xDrive','sDrive']:
        add('BMW',m,t)

# === BUICK ===
for m in ['Enclave','Envision','Encore']:
    for t in ['Preferred','Essence','Premium','Avenir','ST']:
        add('Buick',m,t)

print(f"✅ 加载 {len(FIX)} 条修复规则")

def main():
    token = get_token()
    print("✅ Token OK")
    
    print("📖 读取所有数据...")
    all_data = []
    for start in range(1, 36500, 2000):
        end = min(start + 1999, 36500)
        url = f'https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SPREADSHEET_TOKEN}/values/{SHEET}!A{start}:D{end}'
        r = requests.get(url, headers={'Authorization': f'Bearer {token}'}, timeout=30)
        try:
            rows = r.json()['data']['valueRange']['values']
            for i, row in enumerate(rows):
                all_data.append((start+i, row))
        except:
            print(f'  ⚠ Error at {start}')
        time.sleep(0.3)
    
    print(f"  读取 {len(all_data)} 行")
    
    # Find fixes by building lookup
    to_fix = {}
    
    for row_num, row in all_data:
        if len(row) < 4: continue
        make = txt(row[0]).strip()
        model = txt(row[1]).strip()
        cur_trim = txt(row[2]) if len(row) > 2 else ''
        if not make or not model: continue
        
        ml = model.lower().replace('-','').replace(' ','')
        kl = make.lower().strip()
        
        for fix_make, fix_model, fix_trim, new_model, trim_display in FIX:
            if kl != fix_make: continue
            if fix_model not in ml: continue
            
            # The model string contains the base model. Check if trim is also there
            rest = ml.replace(fix_model, '', 1).strip()
            if fix_trim in rest:
                if not cur_trim or cur_trim.lower() != trim_display.lower():
                    final_model = new_model
                    # Preserve Hybrid/EV powertrain in model name
                    if 'HYBRID' in ml.upper() and 'HYBRID' not in final_model.upper():
                        final_model = new_model + ' Hybrid'
                    elif 'EV' in ml.upper() and 'EV' not in final_model.upper():
                        final_model = new_model + ' EV'
                    to_fix[row_num] = (final_model, trim_display)
                    break
    
    # Summary
    fix_summary = Counter()
    for _, (nm, nt) in to_fix.items():
        fix_summary[f'{nm} → {nt}'] += 1
    
    print(f"🔍 发现 {len(to_fix)} 条需要修复")
    print("=== 修复明细 (Top 40) ===")
    for s, c in sorted(fix_summary.items(), key=lambda x: -x[1])[:40]:
        print(f'  {s:40s} × {c}')
    
    if not to_fix:
        print("✅ 无需修复")
        return
    
    print(f"✍️ 写入 {len(to_fix)} 条...")
    items = sorted(to_fix.items())
    for i, (row_num, (nm, nt)) in enumerate(items):
        url = f'https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SPREADSHEET_TOKEN}/values'
        body = {'valueRange': {'range': f'{SHEET}!B{row_num}:C{row_num}', 'values': [[nm, nt]]}}
        r = requests.put(url, headers={'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'},
                         json=body, timeout=15)
        if r.json().get('code') != 0:
            print(f'  ✗ 行{row_num}')
        if (i+1) % 100 == 0:
            print(f'  ✓ {i+1}/{len(to_fix)}')
        time.sleep(0.08)
    
    print(f"\n✅ 完成！修复 {len(to_fix)} 条")
    
    # Brand summary
    print("\n=== 按品牌 ===")
    brand_fix = Counter()
    for rn, (nm, nt) in to_fix.items():
        for rn2, row2 in all_data:
            if rn2 == rn:
                brand_fix[txt(row2[0])] += 1
                break
    for b, c in brand_fix.most_common(15):
        print(f'  {b:15s} × {c}')

if __name__ == '__main__':
    main()
