#!/bin/bash
# 3W EU/UK 车型需求 数据同步脚本

BASE="/home/ecs-user/.openclaw/workspace"
LOG="$BASE/3w-eu-dashboard/sync.log"
echo "===== $(date) =====" >> "$LOG"

cd "$BASE/3w-eu-dashboard"
python3 process_eu_uk.py >> "$LOG" 2>&1

if [ $? -eq 0 ]; then
    echo "✅ EU/UK 面板数据已更新" >> "$LOG"
else
    echo "⚠️ EU/UK 面板数据更新失败" >> "$LOG"
fi
