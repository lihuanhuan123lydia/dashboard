#!/usr/bin/env python3
"""Process EU/UK 3W floor mats data → normalize + aggregate + generate dashboard JSON"""
import requests, json, re
from collections import defaultdict, Counter
from time import sleep

APP_ID = "cli_a95e614746395cbd"
APP_SECRET = "ZTPbyJlJNK0utcjkqgTazh8JDnLFhK4X"
SP = "XBEVsb2wthdpIVtvotKcsKuVnQb"

def get_token():
    r = requests.post("https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
        json={"app_id": APP_ID, "app_secret": APP_SECRET}, timeout=10)
    return r.json()["tenant_access_token"]

def safe(v):
    if v is None: return ""
    return str(v).strip()

# Make normalization
MAKE_MAP = {
    "FORD":"Ford","CHEVROLET":"Chevrolet","TOYOTA":"Toyota","HONDA":"Honda",
    "NISSAN":"Nissan","KIA":"Kia","HYUNDAI":"Hyundai","JEEP":"Jeep","SUBARU":"Subaru",
    "MAZDA":"Mazda","BMW":"BMW","MERCEDES":"Mercedes-Benz","AUDI":"Audi",
    "VOLKSWAGEN":"Volkswagen","VW":"Volkswagen","OPEL":"Opel","VAUXHALL":"Vauxhall",
    "PEUGEOT":"Peugeot","RENAULT":"Renault","CITROEN":"Citroen","FIAT":"Fiat",
    "VOLVO":"Volvo","SKODA":"Skoda","SEAT":"Seat","CUPRA":"Cupra","POLESTAR":"Polestar",
    "LAND ROVER":"Land Rover","JAGUAR":"Jaguar","TESLA":"Tesla","PORSCHE":"Porsche",
    "LEXUS":"Lexus","MITSUBISHI":"Mitsubishi","SUZUKI":"Suzuki","MINI":"Mini",
    "SMART":"Smart","DACIA":"Dacia","ALFA ROMEO":"Alfa Romeo","MASERATI":"Maserati",
    "BENTLEY":"Bentley","ROLLS-ROYCE":"Rolls-Royce","LAMBORGHINI":"Lamborghini",
    "FERRARI":"Ferrari","LOTUS":"Lotus","ASTON MARTIN":"Aston Martin",
    "MG":"MG","BYD":"BYD","RIVIAN":"Rivian",
}

MODEL_STD = {
    "XC90":"XC90","XC60":"XC60","XC40":"XC40","S60":"S60","S90":"S90","V60":"V60","V90":"V90",
    "KODIAQ":"Kodiaq","ENYAQ":"Enyaq","OCTAVIA":"Octavia","SUPERB":"Superb","FABIA":"Fabia",
    "FORMENTOR":"Formentor","ATECA":"Ateca","LEON":"Leon","BORN":"Born",
    "CR-V":"CR-V","CRV":"CR-V","CIVIC":"Civic","ACCORD":"Accord","HR-V":"HR-V","HRV":"HR-V",
    "JAZZ":"Jazz","ODYSSEY":"Odyssey","PILOT":"Pilot",
    "GOLF":"Golf","PASSAT":"Passat","TIGUAN":"Tiguan","TOUAREG":"Touareg",
    "ID.3":"ID.3","ID.4":"ID.4","ID": "ID.4","ID.5":"ID.5","ID.7":"ID.7",
    "T-CROSS":"T-Cross","T-ROC":"T-Roc","TAIGO":"Taigo","TAOS":"Taos",
    "JETTA":"Jetta","POLO":"Polo","BEETLE":"Beetle","TRANSPORTER":"Transporter",
    "CRAFTER":"Crafter","CADDY":"Caddy","MULTIVAN":"Multivan",
    "Q3":"Q3","Q5":"Q5","Q7":"Q7","Q8":"Q8","Q4":"Q4","Q2":"Q2",
    "A3":"A3","A4":"A4","A5":"A5","A6":"A6","A7":"A7","A8":"A8",
    "E-TRON":"e-tron","E TRON":"e-tron","Q4 E-TRON":"Q4 e-tron",
    "X1":"X1","X3":"X3","X5":"X5","X6":"X6","X7":"X7",
    "3 SERIES":"3 Series","5 SERIES":"5 Series","7 SERIES":"7 Series",
    "1 SERIES":"1 Series","2 SERIES":"2 Series","4 SERIES":"4 Series",
    "I3":"i3","I4":"i4","IX3":"iX3","IX":"iX",
    "GLC":"GLC","GLE":"GLE","GLS":"GLS","GLA":"GLA","GLB":"GLB","GLK":"GLK",
    "C-CLASS":"C-Class","E-CLASS":"E-Class","S-CLASS":"S-Class","A-CLASS":"A-Class",
    "CLS":"CLS","CLA":"CLA","V-CLASS":"V-Class","VITO":"Vito","SPRINTER":"Sprinter",
    "X3":"X3","X5":"X5","X1":"X1","X2":"X2",
    "RANGE ROVER":"Range Rover","RANGE ROVER SPORT":"Range Rover Sport",
    "RANGE ROVER VELAR":"Range Rover Velar","RANGE ROVER EVOQUE":"Range Rover Evoque",
    "DISCOVERY":"Discovery","DISCOVERY SPORT":"Discovery Sport",
    "DEFENDER":"Defender","FREELANDER":"Freelander",
    "XF":"XF","XE":"XE","F-PACE":"F-Pace","E-PACE":"E-Pace",
    "I-PACE":"I-Pace","F-TYPE":"F-Type","XJ":"XJ",
    "3008":"3008","5008":"5008","2008":"2008","208":"208","308":"308","508":"508",
    "PARTNER":"Partner","EXPERT":"Expert","TRAVELLER":"Traveller","RIFTER":"Rifter",
    "C3":"C3","C4":"C4","C5":"C5","C1":"C1","C2":"C2",
    "BERLINGO":"Berlingo","JUMPY":"Jumpy","SPACETOURER":"Spacetourer",
    "CAPTUR":"Captur","CLIO":"Clio","MEGANE":"Megane","SCENIC":"Scenic",
    "TALISMAN":"Talisman","KOLEOS":"Koleos","ESPACE":"Espace",
    "CORSA":"Corsa","ASTRA":"Astra","INSIGNIA":"Insignia","MOKKA":"Mokka","GRANDLAND":"Grandland",
    "CROSSLAND":"Crossland","VIVARO":"Vivaro","COMBO":"Combo","ZAFIRA":"Zafira",
    "PANDA":"Panda","500":"500","500X":"500X","500L":"500L",
    "PUNTO":"Punto","TIPO":"Tipo","DUCATO":"Ducato","DOBLO":"Doblo",
    "MODEL 3":"Model 3","MODEL Y":"Model Y","MODEL S":"Model S","MODEL X":"Model X",
    "CYBERTRUCK":"Cybertruck",
    "FABIA":"Fabia","SCALA":"Scala","KAMIQ":"Kamiq","KAROQ":"Karoq",
    "ENYAQ IV":"Enyaq",
    "IBIZA":"Ibiza","ARONA":"Arona","TARRACO":"Tarracp",
    "OUTLANDER":"Outlander","ASX":"ASX","ECLIPSE":"Eclipse Cross",
    "SWIFT":"Swift","VITARA":"Vitara","S-CROSS":"S-Cross","IGNIS":"Ignis",
    "COUNTRYMAN":"Countryman","COOPER":"Cooper","CLUBMAN":"Clubman",
    "FORTWO":"Fortwo","FORFOUR":"Forfour",
    "SANDERO":"Sandero","DUSTER":"Duster","LOGAN":"Logan",
    "GIULIA":"Giulia","STELVIO":"Stelvio","TONALE":"Tonale",
    "LEVANTE":"Levante","GHIBLI":"Ghibli","QUATTROPORTE":"Quattroporte",
    "CONTINENTAL":"Continental","FLYING SPUR":"Flying Spur","BENTAYGA":"Bentayga",
    "URUS":"Urus","HURACAN":"Huracan",
    "EMIRA":"Emira","EVORA":"Evora","ELISE":"Elise",
}

def norm_make(m):
    key = m.strip().upper()
    return MAKE_MAP.get(key, m.strip().title() if m.strip() else "")

def norm_model(model_str):
    m = model_str.strip().upper()
    if not m: return model_str.strip()
    # Try exact match
    if m in MODEL_STD:
        return MODEL_STD[m]
    # Try partial match
    for orig, std in sorted(MODEL_STD.items(), key=lambda x: -len(x[0])):
        pat = r'\b' + re.escape(orig) + r'\b'
        if re.search(pat, m):
            m = re.sub(pat, std, m)
            break
    m = re.sub(r'\s+', ' ', m).strip()
    return m if m else model_str.strip()

token = get_token()

# Read all sheets
for key, sid in [("EU_main","1YjxjO"), ("UK_main","0KbTPv"), ("EU_raw","3mIFpc"), ("UK_raw","2POenS")]:
    r = requests.get(f"https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SP}/values/{sid}!A:I",
        headers={"Authorization": f"Bearer {token}"}, timeout=60)
    d = r.json()
    rows = d["data"]["valueRange"]["values"]
    exec(f'{key}_rows = rows')
    print(f"{key}: {len(rows)} rows")

# Process raw submissions to count per standardized model per store
eu_counts = Counter()
uk_counts = Counter()
eu_make_models = defaultdict(set)
uk_make_models = defaultdict(set)

for row in EU_raw_rows[1:]:
    if len(row) < 3: continue
    mk = norm_make(safe(row[1]) if len(row) > 1 else "")
    md = norm_model(safe(row[2]) if len(row) > 2 else "")
    cnt = 1
    if len(row) > 8 and row[8]:
        try: cnt = int(float(str(row[8])))
        except: pass
    if mk and md:
        key = f"{mk}|{md}"
        eu_counts[key] += cnt
        eu_make_models[mk].add(md)

for row in UK_raw_rows[1:]:
    if len(row) < 3: continue
    mk = norm_make(safe(row[1]) if len(row) > 1 else "")
    md = norm_model(safe(row[2]) if len(row) > 2 else "")
    cnt = 1
    if len(row) > 7 and row[7]:
        try: cnt = int(float(str(row[7])))
        except: pass
    if mk and md:
        key = f"{mk}|{md}"
        uk_counts[key] += cnt
        uk_make_models[mk].add(md)

# Process main sheets for dev status
def process_main(srows):
    result = {}
    for row in srows[1:]:
        if len(row) < 2: continue
        mk = norm_make(safe(row[0]) if len(row) > 0 else "")
        md = norm_model(safe(row[1]) if len(row) > 1 else "")
        if not mk or not md: continue
        key = f"{mk}|{md}"
        if key not in result:
            result[key] = {"dev": "", "notes": ""}
        if len(row) > 3 and row[3] and not result[key]["dev"]:
            result[key]["dev"] = safe(row[3])
        if len(row) > 4 and row[4]:
            result[key]["notes"] = safe(row[4])
    return result

eu_dev = process_main(EU_main_rows)
uk_dev = process_main(UK_main_rows)

# Build unified model list
all_keys = set(list(eu_counts.keys()) + list(uk_counts.keys()) + list(eu_dev.keys()) + list(uk_dev.keys()))
models = []
for key in all_keys:
    mk, md = key.split("|", 1)
    eu_c = eu_counts.get(key, 0)
    uk_c = uk_counts.get(key, 0)
    ed = eu_dev.get(key, {}).get("dev", "")
    ud = uk_dev.get(key, {}).get("dev", "")
    en = eu_dev.get(key, {}).get("notes", "")
    un = uk_dev.get(key, {}).get("notes", "")
    models.append({
        "make": mk, "model": md,
        "eu_count": eu_c, "uk_count": uk_c,
        "total": eu_c + uk_c,
        "eu_dev": ed, "uk_dev": ud,
        "eu_notes": en, "uk_notes": un,
    })

models.sort(key=lambda x: -x["total"])
for i, m in enumerate(models): m["rank"] = i + 1

# Build makes index for EU, UK, combined
def make_stats(m_counts, m_models):
    result = {}
    for key, cnt in m_counts.items():
        mk, md = key.split("|", 1)
        if mk not in result:
            result[mk] = {"count": 0, "people": 0, "models": set()}
        result[mk]["count"] += 1
        result[mk]["people"] += cnt
        result[mk]["models"].add(md)
    return result

eu_makes = make_stats(eu_counts, eu_make_models)
uk_makes = make_stats(uk_counts, uk_make_models)

combined_makes = defaultdict(lambda: {"count": 0, "people": 0, "eu": 0, "uk": 0, "models": set()})
for mk, st in eu_makes.items():
    combined_makes[mk] = {"count": st["count"], "people": st["people"], "eu": st["people"], "uk": 0, "models": st["models"]}
for mk, st in uk_makes.items():
    if mk in combined_makes:
        combined_makes[mk]["count"] += st["count"]
        combined_makes[mk]["people"] += st["people"]
        combined_makes[mk]["uk"] = st["people"]
        combined_makes[mk]["models"] |= st["models"]
    else:
        combined_makes[mk] = {"count": st["count"], "people": st["people"], "eu": 0, "uk": st["people"], "models": st["models"]}

result = {
    "updated_at": "2026/5/29",
    "total_eu": sum(eu_counts.values()),
    "total_uk": sum(uk_counts.values()),
    "total_all": sum(eu_counts.values()) + sum(uk_counts.values()),
    "total_models": len(models),
    "total_makes": len(combined_makes),
    "eu_makes": len(eu_makes),
    "uk_makes": len(uk_makes),
    "makes": {mk: {k: (list(v) if k == "models" else v) for k, v in st.items()}
              for mk, st in combined_makes.items()},
    "models": [m for m in models if m["total"] >= 1][:500],
}

output_path = "/home/ecs-user/.openclaw/workspace/3w-eu-dashboard/dashboard_data.json"
with open(output_path, "w") as f:
    json.dump(result, f, ensure_ascii=False, indent=2)

print(f"\n✅ Done!")
print(f"  EU total: {result['total_eu']} submissions")
print(f"  UK total: {result['total_uk']} submissions")
print(f"  Combined total: {result['total_all']}")
print(f"  Unique models: {result['total_models']}")
print(f"  EU makes: {result['eu_makes']}, UK makes: {result['uk_makes']}")
print(f"\nTop 10 combined:")
for m in models[:10]:
    print(f"  #{m['rank']} {m['make']} {m['model']}: EU={m['eu_count']} UK={m['uk_count']} total={m['total']}")
