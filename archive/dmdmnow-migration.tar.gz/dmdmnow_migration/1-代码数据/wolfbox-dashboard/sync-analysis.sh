#!/bin/bash
# 同步 analysis_data.json 到 Wolfbox 仪表盘
SRC="/home/ecs-user/.openclaw/workspace/competitor-data/analysis_data.json"
DST="/home/ecs-user/.openclaw/workspace/wolfbox-dashboard/analysis_data.json"
if [ -f "$SRC" ]; then
  cp "$SRC" "$DST"
  echo "$(date): Synced analysis_data.json"
fi
